<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Показ  ошибок
if ( ! function_exists('error'))
{
    function error($error = NULL)
    {
        if ($error === NULL)
        {
            return;
        }
        
        if (!empty($error))
        {
            return '<div class="error">' . (is_array($error) ? implode('<br />', $error) : $error) . '</div>';
        }
	}
}

// Показ  успешных действия
if ( ! function_exists('notice'))
{
    function notice($notice = NULL)
    {
        if ($notice === NULL)
        {
            return;
        }
        
        if (!empty($notice))
        {
            return '<div class="notice">' . (is_array($notice) ? implode('<br />', $notice) : $notice) . '</div>';
        }
	}
}

// Отображаем часы в главном меню
if ( ! function_exists('show_display_time'))
{
    function show_display_time()
    {
        $CI =& get_instance();
        
        // Системное время
        $array = $CI->doc->by_default();
        
        // Контрольная метка 
        $shift = ($array['time_zone'] + $CI->user->time_zone()) * 3600;
        return date("H:i", now() + $shift);
    }
}

// Показываем дату с учетом сдвига времени
if ( ! function_exists('show_display_date'))
{
    function show_display_date($time = '')
    {
        $CI = &get_instance();
        
        if ($time === '')
        {
            $time = now();
        }
        
        // Системное время
        $array = $CI->doc->by_default();
        
        // Контрольная метка 
        $shift = ($array['time_zone'] + $CI->user->time_zone()) * 3600;
        if (date('Y', $time) == date('Y', time())) {
            if (date('z', $time + $shift) == date('z', time() + $shift))
                return 'Сегодня ' . date("H:i", $time + $shift);
            if (date('z', $time + $shift) == date('z', time() + $shift) - 1)
                return 'Вчера ' . date("H:i", $time + $shift);
        }
        return date("d.m.Y / H:i", $time + $shift);
    }
}

// Обработка BB-Codes
if ( ! function_exists('highlight_bb'))
{
    function highlight_bb($bb)
    {
        // Список поиска
        $search = array(
            '#\[b](.+?)\[/b]#is',                                               // Жирный
            '#\[i](.+?)\[/i]#is',                                               // Курсив
            '#\[u](.+?)\[/u]#is',                                               // Подчеркнутый
            '#\[s](.+?)\[/s]#is',                                               // Зачеркнутый
            '#\[small](.+?)\[/small]#is',                                       // Маленький шрифт
            '#\[big](.+?)\[/big]#is',                                           // Большой шрифт
            '#\[red](.+?)\[/red]#is',                                           // Красный
            '#\[green](.+?)\[/green]#is',                                       // Зеленый
            '#\[blue](.+?)\[/blue]#is',                                         // Синий
            '#\[(quote|c)](.+?)\[/(quote|c)]#is',                               // Цитата
            '!\[color=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/color]!is',  // Цвет шрифта
            '!\[bg=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/bg]!is'         // Цвет фона
            );
            
        // Список замены
        $replace = array(
            '<span style="font-weight: bold">$1</span>',                        // Жирный
            '<span style="font-style:italic">$1</span>',                        // Курсив
            '<span style="text-decoration:underline">$1</span>',                // Подчеркнутый
            '<span style="text-decoration:line-through">$1</span>',             // Зачеркнутый
            '<span style="font-size:x-small">$1</span>',                        // Маленький шрифт
            '<span style="font-size:large">$1</span>',                          // Большой шрифт
            '<span style="color:red">$1</span>',                                // Красный
            '<span style="color:green">$1</span>',                              // Зеленый
            '<span style="color:blue">$1</span>',                               // Синий
            '<span class="quote" style="display:block">$2</span>',              // Цитата
            '<span style="color:$1">$2</span>',                                 // Цвет шрифта
            '<span style="background-color:$1">$2</span>'                       // Цвет фона
            );
        return preg_replace($search, $replace, $bb);
    }  
}

// Удаляем теги
if ( ! function_exists('delete_tags'))
{
    function delete_tags($var = '')
    {
        $var = preg_replace('#\[color=(.+?)\](.+?)\[/color]#si', '$2', $var);
        $var = preg_replace('!\[bg=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/bg]!is', '$2', $var);
        $replace = array(
            '[small]' => '',
            '[/small]' => '',
            '[big]' => '',
            '[/big]' => '',
            '[green]' => '',
            '[/green]' => '',
            '[red]' => '',
            '[/red]' => '',
            '[blue]' => '',
            '[/blue]' => '',
            '[b]' => '',
            '[/b]' => '',
            '[i]' => '',
            '[/i]' => '',
            '[u]' => '',
            '[/u]' => '',
            '[s]' => '',
            '[/s]' => '',
            '[quote]' => '',
            '[/quote]' => '',
            '[c]' => '',
            '[/c]' => '',
            '[*]' => '',
            '[/*]' => '');
        return strtr($var, $replace);
    }
}

// Обработка смайлов
if ( ! function_exists('show_smileys'))
{
    function show_smileys($smileys)
    {
        $dir = opendir('images/smileys/');
        while ($file = readdir($dir)) {
            if (preg_match("/\.gif$/", $file)) {
                $s = str_replace(".gif", "", $file);
                $smileys = str_replace(':' . $s . ':', '<img src="/images/smileys/' . $file . '" alt="s" />', $smileys);
            }
        }
        closedir($dir);
        return $smileys;
    }
}

// Обработка ссылок
if ( ! function_exists('get_url'))
{
    function get_url($arr)
    {
        return '<a href="' . htmlspecialchars($arr[1]) . '">' . $arr[2] . '</a>';
    }
}

if ( ! function_exists('get_http'))
{
    function get_http($arr)
    {
        return $arr[1] . '<a href="' . htmlspecialchars($arr[2]) . '">' . $arr[2] . '</a>' . $arr[4];
    }
}

// Подсветка кода PHP
function highlight_code($var)
{
    if (!function_exists('process_code')) {
        function process_code($php)
        {
            $php = strtr($php, array('<br />' => '', '\\' => 'slash_CI'));
            $php = html_entity_decode(trim($php), ENT_QUOTES, 'UTF-8');
            $php = substr($php, 0, 2) != "<?" ? "<?php\n" . $php . "\n?>" : $php;
            $php = highlight_string(stripslashes($php), true);
            $php = strtr($php, array('slash_CI' => '&#92;', ':' => '&#58;', '[' => '&#91;'));
            return '' . $php . '';
        }
    }
    return preg_replace(array('#\[php\](.+?)\[\/php\]#se'), array("''.process_code('$1').''"), str_replace("]\n", "]", $var));
}

// Вывод текста в браузер
if ( ! function_exists('show_text'))
{
    function show_text($str = '')
    {
        $CI =& get_instance();
        $data = $CI->user->authorization();
        
        if (is_array($data))
        {
            $view_smileys = $data['view_smileys'];
            $view_tags = $data['view_tags'];
            $view_http = $data['view_http'];
        }
        else
        {
            $view_smileys = 1;
            $view_tags = 1;
            $view_http = 1;
        }
        
        $str = htmlspecialchars($str);
        $str = nl2br($str);
        
        // Отображаем теги
        if ($view_tags == 1)
        {
            $str = highlight_bb($str);
            $str = highlight_code($str);
        }
            
        // Удаляем теги
        elseif ($view_tags == 0)
            $str = delete_tags($str);
            
        // Отображаем смайлы
        if ($view_smileys == 1)
            $str = show_smileys($str);

        if ($view_http == 1)
        {
            $str = auto_link($str);
            $str = preg_replace_callback('/\[url=(.+)\](.+)\[\/url\]/isU', 'get_url', $str);
            $str = preg_replace_callback('~(^|\s)([a-z]+://([^ \r\n\t`\'"]+))(\s|$)~iu', 'get_http', $str);
        }  
        
        return trim($str);
    }
}

// Иконка пола
if ( ! function_exists('gender'))
{
    function gender($data = array())
    {
        if (element('gender', $data)) 
        {
            if ($data['level'] > 0)
            {
                return img('images/icons/' . $data['gender'] . '.gif');
            }
            else
            {
                return img('images/icons/' . $data['gender'] . '.png');
            }
        } 
    }
}

// отображает иконку онлайна
if ( ! function_exists('online'))
{
    function online($data = array())
    {
        if (element('date_login', $data)) 
        {
            if (now() > $data['date_login'] + 600) 
            {
                return img('images/icons/qip_offline.png');
            } 
            else 
            {
                return img('images/icons/qip_online.png');
            }
        } 
        return img('images/icons/qip_offline.png');
    }
}

// Отображаем ссылку пользователя
if ( ! function_exists('data_user'))
{
    function data_user($data = array(), $url = 'page/profile')
    {
        if (is_array($data)) 
        {
            return gender($data) . nbs() . '<a href="' . base_url() . 'index.php/' . $url . '/' . $data['id'] . '">' . ($data['name'] === '' ? $data['login'] : $data['name']) . '</a>' . nbs() . online($data);
        } 
        else 
        {
            return anchor(current_url(), 'СИСТЕМА');
        }
    }
}

if ( ! function_exists('data_user2'))
{
    function data_user2($data = array(), $url = 'page/profile', $atributes = '')
    {
        if (is_array($data)) 
        {
            return '<a href="' . base_url() . 'index.php/' . $url . '/' . $data['id'] . '">' . gender($data) . nbs() . ($data['name'] === '' ? $data['login'] : $data['name']) . nbs() . online($data) . ($atributes ? nbs() . $atributes : '') . '</a>';
        } 
        else 
        {
            return anchor(current_url(), 'СИСТЕМА');
        }
    }
}

// Функция подсветки результатов поиска
if ( ! function_exists('ReplaceKeywords'))
{
    function ReplaceKeywords($search, $text)
    {
        $search = str_replace('*', '', $search);
        return mb_strlen($search) < 3 ? $text : preg_replace('|(' . preg_quote($search, '/') . ')|siu', '<span style="background-color: #FFFF33">$1</span>', $text);
    }
}
// Возраст
if ( ! function_exists('birt'))
{
    function birt($data) 
    {
        if (is_array($data)) 
        {
            $day = $data['day'];
            $month = $data['month'];
            $year = $data['year'];
            if ($day > 0 AND $month > 0 AND $year > 0)
            {
                $birthdate_unix = mktime(0, 0, 0, $month, $day, $year);
                $current_unix = now();
                $period_unix = $current_unix - $birthdate_unix;
                $age_in_years = floor($period_unix / (365 * 24 * 60 * 60));
                if ($age_in_years > 0)
                {
                    return $age_in_years;
                }
            }
            else
            {
                return FALSE;
            }
        } 
        else
        {
            return FALSE;
        }
    }
}

// Знак зодиака
if ( ! function_exists('zodiak'))
{
    function zodiak($data)
    {
        if (is_array($data))
        {
            $day = $data['day'];
            $month = $data['month'];
                        
            $d = sprintf('%02d',$day);
            $m = sprintf('%02d',$month);

            if ($day > 0 AND $month > 0)
            {
                if (($m=='03' AND $d>20) OR ($m=='04' AND $d<21)) 
                    return 'Овен';
                if (($m=='04' AND $d>20) OR ($m=='05' AND $d<22)) 
                    return 'Телец';
                if (($m=='05' AND $d>21) OR ($m=='06' AND $d<22)) 
                    return 'Близнецы';
                if (($m=='06' AND $d>21) OR ($m=='07' AND $d<23)) 
                    return 'Рак';
                if (($m=='07' AND $d>22) OR ($m=='08' AND $d<24)) 
                    return 'Лев';
                if (($m=='08' AND $d>23) OR ($m=='09' AND $d<24)) 
                    return 'Дева';
                if (($m=='09' AND $d>23) OR ($m=='10' AND $d<24)) 
                    return 'Весы';
                if (($m=='10' AND $d>23) OR ($m=='11' AND $d<23)) 
                    return 'Скорпион';
                if (($m=='11' AND $d>22) OR ($m=='12' AND $d<22)) 
                    return 'Стрелец';
                if (($m=='12' AND $d>21) OR ($m=='01' AND $d<19)) 
                    return 'Козерог';
                if (($m=='01' AND $d>20) OR ($m=='02' AND $d<19)) 
                    return 'Водолей';
                if (($m=='02' AND $d>18) OR ($m=='03' AND $d<21)) 
                    return 'Рыбы';
                return FALSE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
}

// Отображаем города
if ( ! function_exists('city'))
{
    function city($data)
    {
        if (is_array($data))
        {
            $country = $data['country'];
            $id_country = $data['id_country'];
            $region = $data['region'];
            $city = $data['city'];
            
            if ($country AND $id_country AND $region AND $city)
            {
                return show_flag($id_country) . nbs() . trim($city);
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
}

// Отображаем иконку страны
if ( ! function_exists('show_flag'))
{
    function show_flag($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif (file_exists(APPPATH . '../images/flags/' . trim($id) . '.gif'))
        {
            return img('images/flags/' . $id . '.gif') . nbs();
        }
        else
        {
            return FALSE;
        }
    }
}

// Отображаем аватар
if ( ! function_exists('show_avatar'))
{
    function show_avatar($data)
    {
        if (is_array($data))
        {
            if (file_exists(APPPATH . '../files/avatars/' . $data['hash_avatar'] . '.png'))
            {
                return anchor('page/download_file/' . $data['hash_avatar'], img('files/avatars/thumbs/' . $data['hash_avatar'] . '_thumb.png'));
            }
            else
            {
                return img('images/icons/avatar.gif');
            }
        }
        else
        {
            return img('images/icons/avatar.gif');
        }
    }
}