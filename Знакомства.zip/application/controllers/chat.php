<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Chat extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->library('library_bots', NULL, 'bot');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_chat', 'chat', FALSE);
    }
    
    // Главная страница чата
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/chat/index/pages/';
            $config['total_rows'] = $this->db->count_all('chat_room');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->chat->get_room($config['per_page'], $this->uri->segment(4));
            
            // Удаляем пользователя с комнаты
            $this->chat->delete_who_room_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->chat->delete_who_room();
            
            $this->template->page('chat/main', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Правила сата
    public function rules()
    {
        $this->template->page('chat/rules', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat')));
    }
    
    // Создание комнаты
    public function add_room()
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['bot'] = array('0' => 'Без ботов', '1' => $doc['config']['bot_nerd'], '2' => $doc['config']['bot_nerd2']);
            $doc['access'] = array('name' => 'access', 'value' => 1, 'checked' => TRUE);
            $doc['pc_answers'] = array('name' => 'pc_answers', 'value' => 1, 'checked' => TRUE);
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]|is_unique[chat_room.title]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[255]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    $bot = $this->function->abs($this->input->post('bot'));
                    $access = $this->function->abs($this->input->post('access'));
                    $pc_answers = $this->function->abs($this->input->post('pc_answers'));
                    
                    if ($pc_answers === FALSE) $pc_answers = 0;
                    if ($access === FALSE) $access = 0;
                    
                    if ($bot != 0 AND $bot != 1 AND $bot != 2)
                        $doc['error'][] = 'Режим ботов указан некорректно.';
                    if ($access != 1 AND $access != 0) 
                        $doc['error'][] = 'Режим доступа к комнате указан некорректно.';
                    if ($pc_answers != 1 AND $pc_answers != 0) 
                        $doc['error'][] = 'Режим приёма ответов указан некорректно.';
                            
                    if (empty($doc['error']))
                    {
                        if ($bot == 0)
                        {
                            $nerd = 0;
                            $nerd2 = 0;
                        }
                        elseif ($bot == 1)
                        {
                            $nerd = 1;
                            $nerd2 = 0;
                        }
                        elseif ($bot == 2)
                        {
                            $nerd = 0;
                            $nerd2 = 1;
                        }
                        else
                        {
                            $nerd = 0;
                            $nerd2 = 0;
                        }
                        
                        if ($this->chat->add_room(array('title' => $title, 'description' => $description, 'access' => $access, 'nerd' => $nerd, 'nerd2' => $nerd2, 'pc_answers' => $pc_answers, 'sort' => $this->chat->sort_room())))
                        {
                            $this->session->set_userdata(array('notice' => 'Комната успешно создана.'));
                            redirect('chat/index');
                            exit();
                        }
                    }    
                }
            }
            $this->template->page('chat/add_room', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Переход в комнату
    public function room($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            
            
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '10000', 'style' => 'width:99%', 'class' => 'form');

            $config['base_url'] =  base_url() . 'index.php/chat/room/' . $doc['room_data']['id'] . '/pages/';
            $config['total_rows'] = $this->chat->count_all_post_id($doc['room_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->chat->get_post($doc['room_data']['id'], $config['per_page'], $this->uri->segment(5));

            if ($this->input->post('submit') AND $this->user->is_user() AND $doc['room_data']['access'] == 1)
            {
                $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[1]|max_length[1000]');
                
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($antiflood_time = $this->chat->antiflood_time())
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    
                    elseif ($doc['room_data']['pc_answers'] == 0 AND (strpos($this->input->user_agent(), "Opera") !== FALSE OR strpos($this->input->user_agent(), "M3Gate") !== FALSE OR strpos($this->input->user_agent(), "emulator") !== FALSE OR strpos($this->input->user_agent(), "WinWAP") !== FALSE OR strpos($this->input->user_agent(), "Wapsilon") !== FALSE OR strpos($this->input->user_agent(), "Mozilla") !== FALSE OR strpos($this->input->user_agent(), "M3GATE") !== FALSE))
                        $doc['error'][] = 'Ответы с ПК не принимаются в данной комнате';
                    
                    if (empty($doc['error']))
                    {
                        if ($this->chat->add_post(array('id_room' => $doc['room_data']['id'], 'id_user' => $this->user->id(), 'description' => $description, 'time' => now())))
                        {
                            $this->session->set_userdata(array('notice' => 'Сообщение успешно добавлено.'));
                            $this->user->balls($doc['config']['balls']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
                
            // Подключение ботов если нужно
            if ($doc['room_data']['nerd'] == 1) 
            {
                $this->bot->nerd($doc['room_data'], $doc['config']);
                $this->chat->auto_trunce_room($doc['room_data']['id']);
            }
            elseif ($doc['room_data']['nerd2'] == 1) 
            {
                $this->bot->nerd2($doc['room_data'], $doc['config']);
                $this->chat->auto_trunce_room($doc['room_data']['id']);
            }
            
            // Автоматическое обновление
            if ($doc['config']['autoupdate'] > 0) header('Refresh: ' . $doc['config']['autoupdate'] . '; url=' . current_url());
            
            // Удаляем пользователя с комнаты
            $this->chat->delete_who_room_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->chat->delete_who_room();
            
            // Запишем всех кто в комнате
            $this->chat->add_who_room(array('id_room' => $doc['room_data']['id'], 'id_user' => $this->user->id(), 'time' => now()));
            
            $this->template->page('chat/room', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Перемещаем комнату на позицию выше
    public function up_room($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            if ($this->chat->up_room($doc['room_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Комната успешно перемещена на позицию выше.'));
                redirect('chat/index');
                exit();
            }
            else
            {
                redirect('chat/index');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Перемещаем комнату на позицию ниже
    public function down_room($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            if ($this->chat->down_room($doc['room_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Комната успешно перемещена на позицию ниже.'));
                redirect('chat/index');
                exit();
            }
            else
            {
                redirect('chat/index');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Удаление отдельного поста
    public function delete_post($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->chat->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404(); 
            }
            
            if (is_array($doc['post_data']))
            {
                if ($this->chat->delete_post($doc['post_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Сообщение успешно удалено.'));
                    redirect('chat/room/' . $doc['post_data']['id_room']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Отвечаем на пост
    public function reply_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->chat->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404(); 
            }
            
            if ($room_data = $this->chat->check_room($doc['post_data']['id_room']))
            {
                $doc['room_data'] =$room_data;
            }
            else
            {
                show_404();
            }
            
            if ($this->user->id() == $doc['post_data']['id_user'])
            {
                show_404();
            }
            
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '10000', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit') AND $this->user->is_user() AND $doc['room_data']['access'] == 1)
            {
                $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[1]|max_length[1000]');
                
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($antiflood_time = $this->chat->antiflood_time())
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    
                    elseif ($doc['room_data']['pc_answers'] == 0 AND (strpos($this->input->user_agent(), "Opera") !== FALSE OR strpos($this->input->user_agent(), "M3Gate") !== FALSE OR strpos($this->input->user_agent(), "emulator") !== FALSE OR strpos($this->input->user_agent(), "WinWAP") !== FALSE OR strpos($this->input->user_agent(), "Wapsilon") !== FALSE OR strpos($this->input->user_agent(), "Mozilla") !== FALSE OR strpos($this->input->user_agent(), "M3GATE") !== FALSE))
                        $doc['error'][] = 'Ответы с ПК не принимаются в данной комнате';
                    
                    if (empty($doc['error']))
                    {
                        if ($this->chat->add_post(array('id_room' => $doc['room_data']['id'], 'id_user' => $this->user->id(), 'id_reply' => $doc['post_data']['id_user'], 'description' => $description, 'time' => now())))
                        {
                            $this->session->set_userdata(array('notice' => 'Сообщение успешно добавлено.'));
                            $this->user->balls($doc['config']['balls']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect('chat/room/' . $doc['room_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            // Удаляем пользователя с комнаты
            $this->chat->delete_who_room_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->chat->delete_who_room();
            
            $this->template->page('chat/reply_post', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Приватное сообщение
    public function private_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->chat->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404(); 
            }
            
            if ($room_data = $this->chat->check_room($doc['post_data']['id_room']))
            {
                $doc['room_data'] =$room_data;
            }
            else
            {
                show_404();
            }
            
            if ($this->user->id() == $doc['post_data']['id_user'])
            {
                show_404();
            }
            
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '10000', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit') AND $this->user->is_user() AND $doc['room_data']['access'] == 1)
            {
                $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[1]|max_length[1000]');
                
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($antiflood_time = $this->chat->antiflood_time())
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    
                    elseif ($doc['room_data']['pc_answers'] == 0 AND (strpos($this->input->user_agent(), "Opera") !== FALSE OR strpos($this->input->user_agent(), "M3Gate") !== FALSE OR strpos($this->input->user_agent(), "emulator") !== FALSE OR strpos($this->input->user_agent(), "WinWAP") !== FALSE OR strpos($this->input->user_agent(), "Wapsilon") !== FALSE OR strpos($this->input->user_agent(), "Mozilla") !== FALSE OR strpos($this->input->user_agent(), "M3GATE") !== FALSE))
                        $doc['error'][] = 'Ответы с ПК не принимаются в данной комнате';
                    
                    if (empty($doc['error']))
                    {
                        if ($this->chat->add_post(array('id_room' => $doc['room_data']['id'], 'id_user' => $this->user->id(), 'id_private' => $doc['post_data']['id_user'], 'description' => $description, 'time' => now())))
                        {
                            $this->session->set_userdata(array('notice' => 'Сообщение успешно добавлено.'));
                            $this->user->balls($doc['config']['balls']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect('chat/room/' . $doc['room_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            // Удаляем пользователя с комнаты
            $this->chat->delete_who_room_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->chat->delete_who_room();
            
            $this->template->page('chat/private_post', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Кто в комнате
    
    public function who_room($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            
            
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            
            $config['base_url'] =  base_url() . 'index.php/chat/who_room/' . $doc['room_data']['id'] . '/pages/';
            $config['total_rows'] = $this->chat->count_all_who_room($doc['room_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->chat->get_who_room($doc['room_data']['id'], $config['per_page'], $this->uri->segment(5));
            // Удаляем пользователя с комнаты
            $this->chat->delete_who_room_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->chat->delete_who_room();
            
            $this->template->page('chat/who_room', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Очистка комнаты
    public function trunce_room($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['room_data']))
            {
                if ($this->chat->trunce_room($doc['room_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Комната успешно очищена.'));
                    redirect('chat/room/' . $doc['room_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем комнату
    public function edit_room($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['room_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['room_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['bot'] = array('0' => 'Без ботов', '1' => $doc['config']['bot_nerd'], '2' => $doc['config']['bot_nerd2']);
            $doc['access'] = array('name' => 'access', 'value' => 1, 'checked' => $doc['room_data']['access']);
            $doc['pc_answers'] = array('name' => 'pc_answers', 'value' => 1, 'checked' => $doc['room_data']['pc_answers']);
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[255]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    $bot = $this->function->abs($this->input->post('bot'));
                    $access = $this->function->abs($this->input->post('access'));
                    $pc_answers = $this->function->abs($this->input->post('pc_answers'));
                    
                    if ($pc_answers === FALSE) $pc_answers = 0;
                    if ($access === FALSE) $access = 0;
                    
                    if ($bot != 0 AND $bot != 1 AND $bot != 2)
                        $doc['error'][] = 'Режим ботов указан некорректно.';
                    if ($access != 1 AND $access != 0) 
                        $doc['error'][] = 'Режим доступа к комнате указан некорректно.';
                    if ($pc_answers != 1 AND $pc_answers != 0) 
                        $doc['error'][] = 'Режим приёма ответов указан некорректно.';
                            
                    if (empty($doc['error']))
                    {
                        if ($bot == 0)
                        {
                            $nerd = 0;
                            $nerd2 = 0;
                        }
                        elseif ($bot == 1)
                        {
                            $nerd = 1;
                            $nerd2 = 0;
                        }
                        elseif ($bot == 2)
                        {
                            $nerd = 0;
                            $nerd2 = 1;
                        }
                        else
                        {
                            $nerd = 0;
                            $nerd2 = 0;
                        }
                        
                        if ($this->chat->edit_room($doc['room_data']['id'], array('title' => $title, 'description' => $description, 'access' => $access, 'nerd' => $nerd, 'nerd2' => $nerd2, 'pc_answers' => $pc_answers)))
                        {
                            $this->session->set_userdata(array('notice' => 'Комната успешно отредактирована.'));
                            redirect('chat/index');
                            exit();
                        }
                    }    
                }
            }
            $this->template->page('chat/edit_room', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Полное удаление комнаты
    public function delete_room($id = '')
    {
        if ($this->user->is_admin(array(2, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($room_data = $this->chat->check_room($id))
            {
                $doc['room_data'] = $room_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['room_data']))
            {
                if ($this->chat->delete_room($doc['room_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Комната успешно удалена.'));
                    redirect('chat/index');
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Рейтинг умников
    public function iq_rating()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->chat->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/chat/iq_rating/pages/';
            $config['total_rows'] = $this->db->count_all('users');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->chat->get_iq($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('chat/iq_rating', $this->doc->by_default(array('title' => 'Чат', 'page' => 'chat'), $doc));

        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}