<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blog extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_blog', 'blog', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    public function index($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                $id = $this->user->id();
            }
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            if (is_array($doc['user_data']))
            {
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'photo')));
                }
                else
                {
                    $config['base_url'] =  base_url() . 'index.php/blog/index/' . $doc['user_data']['id'] . '/pages/';
                    $config['total_rows'] = $this->blog->count_all_blog_id_user($doc['user_data']['id']);
                    $config['per_page'] = $this->user->per_page();
                    $config['full_tag_open'] = '<div class="page">';
                    $config['full_tag_close'] = '</div>';
                    $config['uri_segment'] = 5;
                    $config['num_links'] = 2;
                    $config['first_link'] = '&laquo; В начало';
                    $config['next_link'] = 'Далее';
                    $config['prev_link'] = 'Назад';
                    $config['last_link'] = 'В конец &raquo;';

                    $this->pagination->initialize($config);

                    $doc['foreach'] = $this->blog->get_blog_id_user($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
                    
                    $this->template->page('blog/main', $this->doc->by_default(array('title' => 'Дневники', 'page' => 'blog'), $doc));
                    $this->session->unset_userdata('notice');
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Создаем блог
    public function add_blog()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '3000', 'class' => 'form');
            
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->blog->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('title', 'Заголовок', 'required|xss_clean|min_length[3]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        if ($this->blog->add_blog(array('id_user' => $this->user->id(), 'title' => $title, 'description' => $description, 'time' => now(), 'gender' => $this->user->gender(), 'rating' => '0', 'moder' => '1')))
                        {
                            $this->session->set_userdata(array('notice' => 'Запись успешно добавлена.'));
                            $this->user->balls($doc['config']['balls_blog']);
                            redirect('blog/index');
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('blog/add_blog', $this->doc->by_default(array('title' => 'Дневники', 'page' => 'blog'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактируем блог
    public function edit_blog($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']))
            {
                $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['blog_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['blog_data']['description'], 'maxlength' => '3000', 'class' => 'form');
       
                if ($this->user->id() != $doc['blog_data']['id_user'])
                {
                    show_404();
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE)
                    {
                        $this->form_validation->set_rules('title', 'Заголовок', 'required|xss_clean|min_length[3]|max_length[255]');
                        $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                        
                        if ($this->form_validation->run())
                        {
                            $title = $this->function->variables($this->input->post('title'));
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if (empty($doc['error']))
                            {
                                if ($this->blog->edit_blog($doc['blog_data']['id'], array('title' => $title, 'description' => $description)))
                                {
                                    $this->session->set_userdata(array('notice' => 'Запись успешно отредактирована.'));
                                    redirect('blog/index');
                                    exit();
                                }
                            }
                        }
                    }
                    
                    $this->template->page('blog/edit_blog', $this->doc->by_default(array('title' => 'Дневники', 'page' => 'blog'), $doc));
                    $this->session->unset_userdata('notice');
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Загрузка картинок
    public function add_image($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']))
            {
                if ($this->user->id() != $doc['blog_data']['id_user'])
                {
                    show_404();
                }
                else
                {
                    $doc['upload_photo'] = array('name' => 'upload_photo');
                    $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
        
                    if ( ! is_dir(APPPATH . './../files/blogs/' . $doc['blog_data']['id'] . '/'))
                    {
                        @mkdir(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/', 0777);
                        @mkdir(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/thumbs/', 0777);
                    }
                    
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->user->id() == $doc['user_data']['id'])
                    {
                        $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if (empty($doc['error']))
                            {
                                // Генерация нового хеша для аватара
                                $hash_photo = random_string('unique');
                                
                                $config['upload_path'] = './files/blogs/' . $doc['blog_data']['id'];
                                $config['allowed_types'] = 'gif|jpg|png';
                                $config['max_size']	= '7000';
                                $config['max_width']  = '4608';
                                $config['max_height']  = '3456';
                                $config['remove_spaces'] = TRUE;
                                $config['overwrite'] = TRUE;
                                $config['file_name'] = $hash_photo . '.png';
                                $this->load->library('upload', $config);
                                
                                if ( ! $this->upload->do_upload('upload_photo')) 
                                {
                                    $doc['error'][] = $this->upload->display_errors();
                        		} 
                                else 
                                {
                        		  $upload_photo = $this->upload->data();
                        		  $config['image_library'] = 'gd2';
                                  $config['source_image'] = $upload_photo['full_path'];
                                  $config['new_image'] = APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/thumbs/' . $hash_photo . '.png';
                                  $config['create_thumb'] = TRUE;
                                  $config['maintain_ratio'] = TRUE;
                                  $config['width'] = 128;
                                  $config['height'] = 128;
                                  $this->load->library('image_lib', $config);   
                                  $this->image_lib->resize();
                                  $this->image_lib->clear(); 
                                  $this->blog->add_files(array('id_blog' => $doc['blog_data']['id'], 'id_user' => $this->user->id(), 'hash_file' => $hash_photo, 'description' => $description, 'time' => now(), 'file_size' => $upload_photo['file_size']));
                                  $this->session->set_userdata(array('notice' => 'Файл успешно добавлен.'));
                                  redirect(current_url());
                                  exit();
                        		}
                            }
                        }
                    }
                    
                    $this->template->page('blog/add_image', $this->doc->by_default(array('title' => 'Дневники', 'page' => 'blog'), $doc));
                    $this->session->unset_userdata('notice');
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Голосуем за блог
    public function vote_blog($id = '', $vote = 'plus')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($vote === '' OR $vote === FALSE OR $vote === NULL)
            {
                show_404();
            }
            
            if ($vote != 'plus' AND $vote != 'minus')
            {
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
            }
            
            if (is_array($doc['blog_data']))
            {
                if ($this->user->check_ignore($doc['blog_data']['id_user']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'blog')));
                }
                else
                {
                    if ($vote == 'plus')
                    {
                        $rating = $doc['blog_data']['rating'] + 1;
                        $ocenka = '+';
                    }
                    elseif ($vote == 'minus')
                    {
                        $rating = $doc['blog_data']['rating'] - 1;
                        $ocenka = '-';
                    }
                    
                    if ($this->blog->check_vote_blog($doc['blog_data']['id']) === FALSE)
                    {
                        if ($this->blog->add_vote_blog($doc['blog_data']['id']))
                        {
                            $this->blog->edit_blog($doc['blog_data']['id'], array('rating' => $rating));
                            $this->session->set_userdata(array('notice' => 'Ваш голос успешно принят.'));
                            if ($this->user->id() != $doc['blog_data']['id_user'])
                            {
                                 $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['blog_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], оценил ваш [url=' . base_url() . 'index.php/blog/comments/' . $doc['blog_data']['id'] . ']дневник[/url]. Оценка ' . $ocenka . ' 1.', 'time' => now(), 'read' => '1'));
                            }
                            redirect('blog/index/' . $doc['blog_data']['id_user']);
                            exit();
                        }
                        else
                        {
                            redirect('blog/index/' . $doc['blog_data']['id_user']);
                            exit();
                        }
                    }
                    else
                    {
                        redirect('blog/index/' . $doc['blog_data']['id_user']);
                        exit();
                    }
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Комментарии к дневнику
    public function comments($id = '', $word = 'word_limiter')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
        
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']) AND is_array($doc['user_data']))
            {
                $config['base_url'] =  base_url() . 'index.php/blog/comments/' . $doc['blog_data']['id'] . '/pages/';
                $config['total_rows'] = $this->blog->count_all_blog_comments($doc['blog_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';

                $this->pagination->initialize($config);

                $doc['foreach'] = $this->blog->get_blog_commments($doc['blog_data']['id'], $config['per_page'], $this->uri->segment(5));
           
                if ($word == 'word_limiter')
                {
                    $doc['word'] = 'word_limiter';
                }
                elseif ($word == 'word')
                {
                    $doc['word'] = 'word';
                }
                else
                {
                    $doc['word'] = 'word_limiter';
                }
            
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'blog')));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_blog'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('blog/error_comments_friends', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_blog'] == 2))
                {
                    $this->template->page('blog/access_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->blog->quarantine_time() === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if ($antiflood_time = $this->blog->antiflood_time())
                            {
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                            }
                            
                            if (empty($doc['error']))
                            {
                                if ($this->blog->add_comments(array('id_blog' => $doc['blog_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id())))
                                {
                                    if ($this->user->id() != $doc['blog_data']['id_user'])
                                    {
                                         $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['blog_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], оставил новый комментарий к вашему [url=' . base_url() . 'index.php/blog/comments/' . $doc['blog_data']['id'] . ']дневнику[/url].', 'time' => now(), 'read' => '1'));
                                    }
                                    $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                                    $this->user->balls($doc['config']['balls_comments']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                    }
                    
                    $this->template->page('blog/comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Ответ на комментарий
    public function reply_comments($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
        
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($post_data = $this->blog->check_comments($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($doc['post_data']['id_blog']))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']) AND is_array($doc['post_data']) AND is_array($doc['user_data']))
            {
                $config['base_url'] =  base_url() . 'index.php/blog/comments/' . $doc['blog_data']['id'] . '/pages/';
                $config['total_rows'] = $this->blog->count_all_blog_comments($doc['blog_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';

                $this->pagination->initialize($config);

                $doc['foreach'] = $this->blog->get_blog_commments($doc['blog_data']['id'], $config['per_page'], $this->uri->segment(5));
                
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'blog')));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_blog'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('blog/error_comments_friends', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_blog'] == 2))
                {
                    $this->template->page('blog/access_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
                elseif ($this->user->id() == $doc['post_data']['id_user'])
                {
                    show_404();
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if ($antiflood_time = $this->blog->antiflood_time())
                            {
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                            }
                            if (empty($doc['error']))
                            {
                                if ($this->blog->add_comments(array('id_blog' => $doc['blog_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id(), 'id_reply' => $doc['post_data']['id_user'])))
                                {
                                    if ($this->user->id() != $doc['post_data']['id_user'])
                                    {
                                         $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['post_data']['id_user'], 'description' => '[b]' . $this->user->login() . '[/b] дал ответ на ваш [url=' . base_url() . 'index.php/blog/comments/' . $doc['blog_data']['id'] . ']комментарий[/url].', 'time' => now(), 'read' => '1'));
                                    }
                                    $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                                    $this->user->balls($doc['config']['balls_comments']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect('blog/comments/' . $doc['blog_data']['id']);
                                    exit();
                                }
                            }
                        }
                    }
                    $this->template->page('blog/reply_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'blog'), $doc));
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление комментария
    public function delete_comments($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'style' => 'width:99%', 'class' => 'form');
        
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($post_data = $this->blog->check_comments($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($doc['post_data']['id_blog']))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']) AND is_array($doc['post_data']) AND is_array($doc['user_data']))
            {
                
                if ($this->user->id() == $doc['blog_data']['id_user'])
                {
                    if ($this->blog->delete_comments($doc['post_data']['id']))
                    {
                        $this->session->set_userdata(array('notice' => 'Комментарий успешно удален.'));
                        redirect('blog/comments/' . $doc['blog_data']['id']);
                        exit();
                    }
                    else
                    {
                        redirect('blog/comments/' . $doc['blog_data']['id']);
                        exit();
                    }
                }
                else
                {
                    show_404();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Файлы блога
    public function files($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']) AND is_array($doc['user_data']))
            {
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'blog')));
                }
                else
                {
                    $config['base_url'] =  base_url() . 'index.php/blog/files/' . $doc['blog_data']['id'] . '/pages/';
                    $config['total_rows'] = $this->blog->count_all_blog_files($doc['blog_data']['id']);
                    $config['per_page'] = $this->user->per_page();
                    $config['full_tag_open'] = '<div class="page">';
                    $config['full_tag_close'] = '</div>';
                    $config['uri_segment'] = 5;
                    $config['num_links'] = 2;
                    $config['first_link'] = '&laquo; В начало';
                    $config['next_link'] = 'Далее';
                    $config['prev_link'] = 'Назад';
                    $config['last_link'] = 'В конец &raquo;';

                    $this->pagination->initialize($config);

                    $doc['foreach'] = $this->blog->get_blog_files($doc['blog_data']['id'], $config['per_page'], $this->uri->segment(5));
                    
                    if ($this->input->post('submit'))
                    {
                        $this->form_validation->set_rules('id_file', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                        if ($this->form_validation->run())
                        {
                            $id_file = $this->function->abs($this->input->post('id_file'));
                    
                            if ($id_file === '' OR $id_file === FALSE OR $id_file === NULL OR $id_file == 0)
                                $doc['error'][] = 'ID файла указан некорректно.';
                            if (empty($doc['error']))
                            {
                                if ($logo_file = $this->blog->check_file_id_user($id_file))
                                {
                                    if ($this->blog->edit_blog($doc['blog_data']['id'], array('hash_file' => $logo_file['hash_file'])))
                                    {
                                        $this->session->set_userdata(array('notice' => 'Логотип успешно установлен.'));
                                        redirect(current_url());
                                        exit();
                                    }
                                }
                                else
                                {
                                    $doc['error'][] = 'Файл не найден.';
                                }
                            }
                        }
                    }
                    
                    if ($this->input->post('delete'))
                    {
                        $this->form_validation->set_rules('id_file', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                        if ($this->form_validation->run())
                        {
                            $id_file = $this->function->abs($this->input->post('id_file'));
                    
                            if ($id_file === '' OR $id_file === FALSE OR $id_file === NULL OR $id_file == 0)
                                $doc['error'][] = 'ID файла указан некорректно.';
                            if (empty($doc['error']))
                            {
                                if ($del_file = $this->blog->check_file_id_user($id_file))
                                {
                                    if ($this->blog->delete_file($del_file['id']))
                                    {
                                        @unlink(APPPATH . '../files/blogs/' . $del_file['id_blog'] . '/' . $del_file['hash_file'] . '.png');
                                        @unlink(APPPATH . '../files/blogs/' . $del_file['id_blog'] . '/thumbs/' . $del_file['hash_file'] . '_thumb.png');
                                        $this->session->set_userdata(array('notice' => 'Файл успешно удален.'));
                                        redirect(current_url());
                                        exit();
                                    }
                                }
                                else
                                {
                                    $doc['error'][] = 'Файл не найден.';
                                }
                            }
                        }
                    }
                    
                    $this->template->page('blog/files', $this->doc->by_default(array('title' => 'Файлы', 'page' => 'blog'), $doc));
                }
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Скачка файла
    public function download_file($id = '', $hash = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            if ($id === '' AND $id === NULL AND $id === FALSE AND $id == 0)
            {
                show_404();
            }
            elseif ($hash === '' AND $hash === FALSE AND $hash === NULL AND $hash == 0)
            {
                show_error('Запрашиваемый файл не найден на сервере.');
            }
            elseif (file_exists(APPPATH . '../files/blogs/' . $id . '/' . $this->function->htmlspecialchars($hash) . '.png'))
            {
                $data = file_get_contents(APPPATH . '../files/blogs/' . $id . '/' . $this->function->htmlspecialchars($hash) . '.png'); // Считываем содержимое файла
                $name = 'wapdoza.ru.' . $hash . '.png';
                force_download($name, $data); 
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Полное удаление блога
    public function delete_blog($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($blog_data = $this->blog->check_blog($id))
            {
                $doc['blog_data'] = $blog_data;
            }
            else
            {
                $doc['blog_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['blog_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['blog_data']) AND is_array($doc['user_data']))
            {
                if ($this->user->id() == $doc['user_data']['id'])
                {
                    if ($this->blog->delete_blog($doc['blog_data']['id']))
                    {
                        delete_files('./files/blogs/' . $doc['blog_data']['id'] . '/', TRUE); 
                        @unlink(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/');
                        @rmdir(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/');
                        $this->session->set_userdata(array('notice' => 'Дневник успешно удален.'));
                        redirect('blog/index/' . $this->user->id());
                        exit();
                    }
                }
                else
                {
                    show_404();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Дневы
    public function gender()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $this->template->page('blog/gender', $this->doc->by_default(array('title' => 'Дневники пользователей', 'page' => 'blog'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Модерация
    public function moderations()
    {
        if ($this->user->is_admin(array(4, 10)))
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('id', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id = $this->function->abs($this->input->post('id'));
                    
                    if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
                        $doc['error'][] = 'ID дневника указан некорректно.';
                    
                    if ($blog_data = $this->blog->check_blog($id))
                    {
                        $doc['blog_data'] = $blog_data;
                        if ($this->blog->edit_blog($doc['blog_data']['id'], array('moder' => '0')))
                        {
                            $this->session->set_userdata(array('notice' => 'Дневник успешно промодерирован.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Дневник не найден.';
                    }
                }
            }
            
            if ($this->input->post('delete'))
            {
                $this->form_validation->set_rules('id', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id = $this->function->abs($this->input->post('id'));
                    
                    if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
                        $doc['error'][] = 'ID дневника указан некорректно.';
                    
                    if ($blog_data = $this->blog->check_blog($id))
                    {
                        $doc['blog_data'] = $blog_data;
                        if ($this->blog->delete_blog($doc['blog_data']['id']))
                        {
                            // Удаляем старые аватары
                            delete_files('./files/blogs/' . $doc['blog_data']['id'] . '/', TRUE); 
                            @unlink(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/');
                            @rmdir(APPPATH . '../files/blogs/' . $doc['blog_data']['id'] . '/');
                            $this->session->set_userdata(array('notice' => 'Дневник успешно удален.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Фото не найдено.';
                    }
                }
            }
            
            $config['base_url'] =  base_url() . 'index.php/blog/moderations/pages/';
            $config['total_rows'] = $this->blog->count_all_blog_moderations();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->blog->get_blog_moderations($config['per_page'], $this->uri->segment(4));
        
            $this->template->page('blog/moderations', $this->doc->by_default(array('title' => 'Модерация дневников', 'page' => 'blog'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Популярные
    public function chart()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/blog/chart/pages/';
            $config['total_rows'] = $this->blog->count_all_blog();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->blog->get_blog_chart($config['per_page'], $this->uri->segment(4));
            $this->template->page('blog/chart', $this->doc->by_default(array('title' => 'Дневники пользователей | Популярные', 'page' => 'photo'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Парни
    public function boy()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/blog/boy/pages/';
            $config['total_rows'] = $this->blog->count_all_blog_moder('m');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->blog->get_blog_boy($config['per_page'], $this->uri->segment(4));
            $this->template->page('blog/boy', $this->doc->by_default(array('title' => 'Дневники пользователей', 'page' => 'blog'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Девушки
    public function girl()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->blog->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/blog/girl/pages/';
            $config['total_rows'] = $this->blog->count_all_blog_moder('w');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->blog->get_blog_girl($config['per_page'], $this->uri->segment(4));
            $this->template->page('blog/girl', $this->doc->by_default(array('title' => 'Дневники пользователей', 'page' => 'blog'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}