<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Wall extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_wall', 'wall', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->wall->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
            
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->wall->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[3]|max_length[1024]');
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                            
                    if ($antiflood_time = $this->wall->antiflood_time())
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->wall->add_wall(array('id_user' => $this->user->id(), 'description' => $description, 'time' => now())))
                        {
                            $this->session->set_userdata(array('notice' => 'Сообщение успешно добавлено.'));
                            $this->user->balls($doc['config']['balls_comments']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect(current_url());
                            exit();
                        }
                    }
                }    
            }
            
            // Удаляем пользователя с комнаты
            $this->wall->delete_who_wall_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->wall->delete_who_wall();
            
            // Запишем всех кто в комнате
            $this->wall->add_who_wall(array('id_user' => $this->user->id(), 'time' => now()));
      
            $config['base_url'] =  base_url() . 'index.php/wall/index/pages/';
            $config['total_rows'] = $this->db->count_all('wall');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->wall->get_wall($config['per_page'], $this->uri->segment(4));
           
            $this->template->page('wall/main', $this->doc->by_default(array('title' => 'Стена сообщений', 'page' => 'wall'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // ОТВЕТ
    public function reply_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            $doc['config'] = $this->wall->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
            
            // Удаляем пользователя с комнаты
            $this->wall->delete_who_wall_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->wall->delete_who_wall();
            
            // Запишем всех кто в комнате
            $this->wall->add_who_wall(array('id_user' => $this->user->id(), 'time' => now()));
            
            if ($post_data = $this->wall->check_comments($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
                show_404();
            }
            
            if ($user_data =$this->user->parse_id($doc['post_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if (is_array($doc['post_data']) AND is_array($doc['user_data']))
            {
                if ($this->user->id() == $doc['user_data']['id'])
                {
                    $this->template->page('wall/error_reply_post', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'wall'), $doc));
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->wall->quarantine_time() === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[3]|max_length[1024]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                                    
                            if ($antiflood_time = $this->wall->antiflood_time())
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                                
                            if (empty($doc['error']))
                            {
                                if ($this->wall->add_wall(array('id_user' => $this->user->id(), 'id_reply' => $doc['user_data']['id'], 'description' => $description, 'time' => now())))
                                {
                                    $this->session->set_userdata(array('notice' => 'Сообщение успешно добавлено.'));
                                    $this->user->balls($doc['config']['balls_comments']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect('wall/index');
                                    exit();
                                }
                            }
                        }    
                    }
                    $this->template->page('wall/reply_post', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'wall'), $doc));
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Загрузка файла
    public function add_image()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->wall->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
            $doc['upload_photo'] = array('name' => 'upload_photo');
            
            if ( ! is_dir(APPPATH . './../files/walls/thumbs/'))
            {
                @mkdir(APPPATH . '../files/walls/', 0777);
                @mkdir(APPPATH . '../files/walls/thumbs/', 0777);
            }
            
            // Удаляем пользователя с комнаты
            $this->wall->delete_who_wall_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->wall->delete_who_wall();
            
            // Запишем всех кто в комнате
            $this->wall->add_who_wall(array('id_user' => $this->user->id(), 'time' => now()));
            
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->wall->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[3]|max_length[1024]');
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        // Генерация нового хеша для аватара
                        $hash_photo = random_string('unique');
                        $config['upload_path'] = './files/walls/';
                        $config['allowed_types'] = 'gif|jpg|png|jpeg';
                        $config['max_size']	= '7000';
                        $config['remove_spaces'] = TRUE;
                        $config['overwrite'] = TRUE;
                        $config['file_name'] = $hash_photo . '.png';
                        $this->load->library('upload', $config);
                                
                        if ( ! $this->upload->do_upload('upload_photo')) 
                        {
                            $doc['error'][] = $this->upload->display_errors();
                  		}
                        else 
                        {
                            $upload_photo = $this->upload->data();
                		    $config['image_library'] = 'gd2';
                            $config['source_image'] = $upload_photo['full_path'];
                            $config['new_image'] = APPPATH . '../files/walls/thumbs/' . $hash_photo . '.png';
                            $config['create_thumb'] = TRUE;
                            $config['maintain_ratio'] = TRUE;
                            $config['width'] = 128;
                            $config['height'] = 128;
                            $this->load->library('image_lib', $config);   
                            $this->image_lib->resize();
                            $this->image_lib->clear(); 
                            $this->wall->add_wall(array('hash_file' => $hash_photo, 'id_user' => $this->user->id(), 'description' => $description, 'time' => now(), 'file_size' => $upload_photo['file_size']));
                            $this->user->balls($doc['config']['balls_comments']);
                            $this->user->update(array('date_last_post' => now()));
                            $this->session->set_userdata(array('notice' => 'Файл успешно добавлен.'));
                            redirect('wall/index');
                            exit();
                  		}
                    }
                }       
            }   
                 
            $this->template->page('wall/add_image', $this->doc->by_default(array('title' => 'Загрузка файла', 'page' => 'wall'), $doc));  
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление поста
    public function delete_post($id = '')
    {
        if ($this->user->is_admin(array(2, 5, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($post_data = $this->wall->check_comments($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
                show_404();
            }
            
            if (is_array($doc['post_data']))
            {
                if ($this->wall->delete_wall_post($doc['post_data']['id']))
                {
                    @unlink(APPPATH . '../files/walls/' . $doc['post_data']['hash_file'] . '.png');
                    @unlink(APPPATH . '../files/walls//thumbs/' . $doc['post_data']['hash_file'] . '_thumb.png');
                    $this->session->set_userdata(array('notice' => 'Сообщение успешно удалено.'));
                    redirect('wall/index');
                }
                else
                {
                    show_404();
                }                     
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Скачка файла
    public function download_file($hash = '')
    {
        if ($this->user->is_user())
        {
            if ($hash === '' AND $hash === FALSE AND $hash === NULL AND $hash == 0)
            {
                show_error('Запрашиваемый файл не найден на сервере.');
            }
            elseif (file_exists(APPPATH . '../files/walls/' . $this->function->htmlspecialchars($hash) . '.png'))
            {
                $data = file_get_contents(APPPATH . '../files/walls/' . $this->function->htmlspecialchars($hash) . '.png'); // Считываем содержимое файла
                $name = 'wapdoza.ru.' . $hash . '.png';
                force_download($name, $data); 
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Кто здесь
    public function who_wall()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->wall->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            // Удаляем пользователя с комнаты
            $this->wall->delete_who_wall_id_user($this->user->id());
            
            // Удаляем все с комнаты по истечению 10 минут
            $this->wall->delete_who_wall();
            
            // Запишем всех кто в комнате
            $this->wall->add_who_wall(array('id_user' => $this->user->id(), 'time' => now()));
      
            $config['base_url'] =  base_url() . 'index.php/wall/who_wall/pages/';
            $config['total_rows'] = $this->db->count_all('wall_who');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->wall->get_who_wall($config['per_page'], $this->uri->segment(4));
           
            $this->template->page('wall/who_wall', $this->doc->by_default(array('title' => 'Кто здесь?', 'page' => 'wall'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}