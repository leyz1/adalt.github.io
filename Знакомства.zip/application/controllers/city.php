<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class City extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_city', 'city', FALSE);
    }
    
    public function index()
    {
        redirect(base_url() . 'index.php/city/country/');
        exit();
    }
    
    // Выбор страны
    public function country($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['search_city'] = $this->session->userdata('search_city') ? $this->session->userdata('search_city') : '';
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['search_city'], 'maxlength' => '10', 'style' => 'width:99%', 'class' => 'form');
            
            if ($id > 0)
            {
                if ($country_data = $this->city->check_country($id))
                {
                    $newdata = array('id_country' => $this->function->abs($country_data['id']));
                    $this->session->set_userdata($newdata);
                    redirect(base_url() . 'index.php/city/region/');
                    exit();
                }
                else
                {
                    $doc['error'][] = 'Страна выбранна некорректно.';
                }
            } 
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название города', 'required|xss_clean|min_length[3]|max_length[10]');
  
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    
                    if ($title)
                    {
                        $this->session->set_userdata(array('search_city' => $title));
                        redirect(base_url() . 'index.php/city/search');
                        exit();
                    }
                }
            }
            
            $config['base_url'] =  base_url() . 'index.php/city/country/pages/';
            $config['total_rows'] = $this->db->count_all('country_');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->city->get_country($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('city/country', $this->doc->by_default(array('title' => 'Город поживания', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Выбор рнгиона
    public function region($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            
            if ($id > 0)
            {
                if ($region_data = $this->city->check_region($id, $this->session->userdata('id_country')))
                {
                    $this->session->set_userdata(array('id_region' => $this->function->abs($region_data['id'])));
                    redirect(base_url() . 'index.php/city/home/');
                    exit();
                }
                else
                {
                    $doc['error'][] = 'Регион выбран некорректно.';
                }
            } 
            
            $config['base_url'] =  base_url() . 'index.php/city/region/pages/';
            $config['total_rows'] = $this->city->count_all_region($this->function->abs($this->session->userdata('id_country')));
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->city->get_region($this->function->abs($this->session->userdata('id_country')), $config['per_page'], $this->uri->segment(4));
            
            $this->template->page('city/region', $this->doc->by_default(array('title' => 'Город поживания', 'page' => 'my_profie'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Выбор города проживания
    public function home($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id > 0)
            {
                // Проверяем данные сессий
                if ($country_arr = $this->city->check_country($this->session->userdata('id_country')))
                {
                    $doc['country_arr'] = $country_arr;
                }
                else
                {
                    redirect(base_url() . 'index.php/city/country/');
                    exit();
                }
                
                if ($region_arr = $this->city->check_region($this->session->userdata('id_region'), $doc['country_arr']['id']))
                {
                    $doc['region_arr'] = $region_arr;
                }
                else
                {
                    redirect(base_url() . 'index.php/city/country/');
                    exit();
                }
                
                if ($city_data = $this->city->check_city($id, $doc['region_arr']['id'], $doc['country_arr']['id']))
                {
                    if ($this->user->update(array('country' => $this->function->variables($country_arr['country_name_ru']), 'id_country' => $doc['country_arr']['oid'], 'region' => $this->function->variables($region_arr['region_name_ru']), 'city' => $this->function->variables($city_data['city_name_ru']))))
                    {
                        $this->session->set_userdata(array('notice' => 'Город проживания успешно сохранен.'));
                        redirect(base_url() . 'index.php/city/index');
                        exit();
                    }
                }
                else
                {
                    $doc['error'][] = 'Город выбран некорректно. Повторите процедуру выбора своего города заново.';
                }
            } 
            
            $config['base_url'] =  base_url() . 'index.php/city/home/pages/';
            $config['total_rows'] = $this->city->count_all_city($this->function->abs($this->session->userdata('id_region')), $this->function->abs($this->session->userdata('id_country')));
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->city->get_city($this->function->abs($this->session->userdata('id_region')), $this->function->abs($this->session->userdata('id_country')), $config['per_page'], $this->uri->segment(4));
            
            $this->template->page('city/city', $this->doc->by_default(array('title' => 'Город поживания', 'page' => 'my_profie'), $doc));

        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Результаты поиска
    public function search($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->session->userdata('search_city'))
            {
                $search_city = $this->function->htmlspecialchars($this->session->userdata('search_city'));
            }
            else
            {
                $search_city = '';
            }
            
            if ($id > 0)
            {
                if ($search_data = $this->city->check_search_city($id))
                {
                    $search_country = $this->city->check_country($search_data['id_country']);
                    $search_region = $this->city->check_region($search_data['id_region'], $search_data['id_country']);

                    // Общая проверка
                    if ($city_data = $this->city->check_city($search_data['id'], $search_region['id'], $search_country['id']))
                    {
                        if ($this->user->update(array('country' => $this->function->variables($search_country['country_name_ru']), 'id_country' => $search_country['oid'], 'region' => $this->function->variables($search_region['region_name_ru']), 'city' => $this->function->variables($city_data['city_name_ru']))))
                        {
                            $this->session->set_userdata(array('notice' => 'Город проживания успешно сохранен.'));
                            redirect(base_url() . 'index.php/city/index');
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Город выбран некорректно. Повторите процедуру выбора своего города заново.';
                    }
                }
                else
                {
                    $doc['error'][] = 'Город выбран некорректно. Повторите процедуру выбора своего города заново.';
                }
            }
            $config['base_url'] =  base_url() . 'index.php/city/search/pages/';
            $config['total_rows'] = $this->city->count_all_search($search_city);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->city->get_search($search_city, $config['per_page'], $this->uri->segment(4));
            
            $this->template->page('city/search', $this->doc->by_default(array('title' => 'Город поживания', 'page' => 'my_profie'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}