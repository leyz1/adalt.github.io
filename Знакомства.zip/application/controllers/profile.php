<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Настройки профиля

class Profile extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    // Главная страница
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $this->template->page('profile/main', $this->doc->by_default(array('title' => 'Мой профиль', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Изменяем пароль
    public function edit_pass()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'size' => '40', 'class' => 'form');
            $doc['new_password'] = array('name' => 'new_password', 'maxlength' => '40', 'size' => '40', 'class' => 'form');
            $doc['repeat_password'] = array('name' => 'repeat_password', 'maxlength' => '40', 'size' => '40', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('password', 'Текущий пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
                $this->form_validation->set_rules('new_password', 'Новый пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
                $this->form_validation->set_rules('repeat_password', 'Повтор нового пароля', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
                
                if ($this->form_validation->run())
                {
                    $password = $this->input->post('password');
                    $new_password = $this->input->post('new_password');
                    $repeat_password = $this->input->post('repeat_password');
                    if ($new_password != $repeat_password)
                    {
                        $doc['error'][] = 'Пароли не совпадают.';
                    }
                    elseif ($this->user->check_password($this->encrypt->sha1($this->encrypt->sha1($password))))
                    {
                        if ($this->user->update(array('password' => $this->encrypt->sha1($this->encrypt->sha1($new_password)))))
                        {
                            $this->session->set_userdata(array('notice' => 'Вы успешно сменили пароль.'));
                            redirect(base_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Старый пароль введен неверно.';
                    }
                }
            }
            
            $this->template->page('profile/edit_pass', $this->doc->by_default(array('title' => 'Изменить пароль', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Изменяем мыло
    public function edit_e_mail()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['real_mail'] = array('name' => 'real_mail', 'value' => $this->input->post('real_mail') ? $this->function->htmlspecialchars($this->input->post('real_mail')) : NULL, 'maxlength' => '128', 'size' => 128, 'class' => 'form');
              
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('real_mail', 'E-mail', 'required|xss_clean|valid_email|is_unique[users.email]'); 
                if ($this->form_validation->run())
                {
                    $real_mail = $this->input->post('real_mail');
                    if ($this->user->update(array('email' => $real_mail)))
                    {
                        $this->session->set_userdata(array('notice' => 'E-mail успешно установлен.'));
                        redirect(current_url());
                        exit();
                    }
                }
            }
            
            $this->template->page('profile/edit_e_mail', $this->doc->by_default(array('title' => 'Настройки E-mail', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Изменяем часовой пояс
    public function edit_time()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['time_zone'] = array(
                '0' => 'Системное время',
                '+1' => '+ 1', 
                '+2' => '+ 2', 
                '+3' => '+ 3', 
                '+4' => '+ 4', 
                '+5' => '+ 5', 
                '+6' => '+ 6', 
                '+7' => '+ 7', 
                '+8' => '+ 8', 
                '+9' => '+ 9', 
                '+10' => '+ 10', 
                '+11' => '+ 11', 
                '+12' => '+ 12',
                '-1' => '- 1', 
                '-2' => '- 2', 
                '-3' => '- 3', 
                '-4' => '- 4', 
                '-5' => '- 5', 
                '-6' => '- 6', 
                '-7' => '- 7', 
                '-8' => '- 8', 
                '-9' => '- 9', 
                '-10' => '- 10', 
                '-11' => '- 11', 
                '-12' => '- 12');
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('time_zone', 'Часовой пояс', 'required|xss_clean|min_length[1]|numeric'); 
                if ($this->form_validation->run())
                {
                    $time_zone = $this->function->variables($this->input->post('time_zone'));
                    
                    if ($time_zone > +12 OR $time_zone < -12)
                    {
                        $data['error'] = 'Поле Часовой пояс может содержать только числа (+- от 1 до 12).';
                    }
                    
                    if ($this->user->update(array('time_zone' => $time_zone)))
                    {
                        $this->session->set_userdata(array('notice' => 'Часовой пояс успешно установлен.'));
                        redirect(current_url());
                        exit();
                    }
                }
            }
            $this->template->page('profile/edit_time', $this->doc->by_default(array('title' => 'Время', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Настройки приватности
    public function edit_privacy()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['sent_msg'] = array('0' => 'Все пользователи', '1' => 'Только мои друзья', '2' => 'Никто');
            $doc['comment_photo'] = array('0' => 'Все пользователи', '1' => 'Только мои друзья', '2' => 'Никто');
            $doc['comment_blog'] = array('0' => 'Все пользователи', '1' => 'Только мои друзья', '2' => 'Никто');
            $doc['view_present'] = array('0' => 'Все пользователи', '1' => 'Только мои друзья', '2' => 'Никто');
            $doc['view_friends'] = array('0' => 'Все пользователи', '1' => 'Только мои друзья', '2' => 'Никто');
            $doc['add_friends'] = array('0' => 'Все пользователи', '1' => 'Никто');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('sent_msg', 'Кто может посылать мне личные сообщения?', 'required|xss_clean|exact_length[1]|numeric'); 
                $this->form_validation->set_rules('comment_photo', 'Кто может комментировать мои фото?', 'required|xss_clean|exact_length[1]|numeric');
                $this->form_validation->set_rules('comment_blog', 'Кто может комментировать записи в моих дневниках?', 'required|xss_clean|exact_length[1]|numeric');
                $this->form_validation->set_rules('view_friends', 'Кто может видеть список моих друзей?', 'required|xss_clean|exact_length[1]|numeric');
                $this->form_validation->set_rules('add_friends', 'Кто может отправлять мне запросы о добавлении в друзья?', 'required|xss_clean|exact_length[1]|numeric');
                $this->form_validation->set_rules('view_present', 'Кто может видеть список моих подарков?', 'required|xss_clean|exact_length[1]|numeric');
               
                if ($this->form_validation->run())
                {
                    $sent_msg = $this->function->abs($this->input->post('sent_msg'));
                    $sent_wall = $this->function->abs($this->input->post('sent_wall'));
                    $comment_photo = $this->function->abs($this->input->post('comment_photo'));
                    $comment_blog = $this->function->abs($this->input->post('comment_blog'));
                    $comment_status = $this->function->abs($this->input->post('comment_status'));
                    $view_friends = $this->function->abs($this->input->post('view_friends'));
                    $add_friends = $this->function->abs($this->input->post('add_friends'));
                    $view_present = $this->function->abs($this->input->post('view_present'));
                    
                    if ($sent_msg != 0 AND $sent_msg != 1 AND $sent_msg != 2)
                        $doc['error'][] = 'Поле Кто может посылать мне личные сообщения? указано некорректно.';
                    if ($sent_wall != 0 AND $sent_wall != 1 AND $sent_wall != 2)
                        $doc['error'][] = 'Поле Кто может оставлять записи на моей стене? указано некорректно.';
                    if ($comment_photo != 0 AND $comment_photo != 1 AND $comment_photo != 2)
                        $doc['error'][] = 'Поле Кто может комментировать мои фото? указано некорректно.';
                    if ($comment_blog != 0 AND $comment_blog != 1 AND $comment_blog != 2)
                        $doc['error'][] = 'Поле Кто может комментировать мои записи дневниках? указано некорректно.';
                    if ($comment_status != 0 AND $comment_status != 1 AND $comment_status != 2)
                        $doc['error'][] = 'Поле Кто может комментировать мой статус? указано некорректно.';
                    if ($view_present != 0 AND $view_present != 1 AND $view_present != 2)
                        $doc['error'][] = 'Поле Кто может видеть список моих подарков? указано некорректно.';
                    if ($view_friends != 0 AND $view_friends != 1 AND $view_friends != 2)
                        $doc['error'][] = 'Поле Кто может видеть список моих друзей? указано некорректно.';
                    if ($add_friends != 0 AND $add_friends != 1)
                        $doc['error'][] = 'Поле Кто может отправлять мне запросы о добавлении в друзья? указано некорректно.';
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('sent_msg' => $sent_msg, 'sent_wall' => $sent_wall, 'comment_photo' => $comment_photo, 'comment_blog' => $comment_blog, 'comment_status' => $comment_status, 'view_present' => $view_present, 'view_friends' => $view_friends, 'add_friends' => $add_friends)))
                        {
                            $this->session->set_userdata(array('notice' => 'Настройки приватности успешно сохранены.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('profile/edit_privacy', $this->doc->by_default(array('title' => 'Настройки приватности', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Номер телефона
    public function edit_mobile()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['mobile_number'] = array('name' => 'mobile_number', 'value' => $this->input->post('mobile_number') ? $this->function->htmlspecialchars($this->input->post('mobile_number')) : $this->user->mobile_phone(), 'maxlength' => '12', 'size' => '15', 'class' => 'form');
            $doc['country_code'] = array('name' => 'country_code', 'value' => $this->input->post('country_code') ? $this->function->htmlspecialchars($this->input->post('country_code')) : NULL, 'maxlength' => '10', 'size' => '10', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('country_code', 'Код страны', 'required|xss_clean|min_length[1]|max_length[10]|numeric'); 
                $this->form_validation->set_rules('mobile_number', 'Номер телефона', 'required|xss_clean|min_length[9]|max_length[12]|numeric|is_unique[users.mobile_phone]');
                if ($this->form_validation->run())
                {
                    $country_code = $this->function->abs($this->input->post('country_code'));
                    $mobile_number = $this->function->abs($this->input->post('mobile_number'));
                    if ($mc = $this->profile->check_country_phone_code($country_code))
                    {
                        if ($this->user->update(array('country_code' => $mc['PhoneCode'], 'mobile_phone' => $mobile_number)))
                        {
                            $this->session->set_userdata(array('notice' => 'Номер телефона успешно сохранен.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Код страны ненайден в базе данных.';
                    }
                    
                }
            }
            
            $this->template->page('profile/edit_mobile', $this->doc->by_default(array('title' => 'Номер телефона', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Выбор теми оформления
    public function edit_style()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('style', 'Тема оформления', 'required|xss_clean|min_length[1]|alpha_dash');
                if ($this->form_validation->run())
                {
                    $style = $this->function->variables($this->input->post('style'));
                    if (!is_dir(APPPATH . '../styles/' . $style))
                        $doc['error'][] = 'Тема оформления не найдена';
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('style' => $style)))
                        {
                            $this->session->set_userdata(array('notice' => 'Тема офориления успешно установлена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('profile/edit_style', $this->doc->by_default(array('title' => 'Тема оформления', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Черный список
    public function edit_ignore()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['id_user'] = array('name' => 'id_user', 'value' => $this->input->post('id_user') ? $this->function->abs($this->input->post('id_user')) : NULL, 'maxlength' => '11', 'size' => '11', 'class' => 'form');
            
            $config['base_url'] =  base_url() . 'index.php/profile/edit_ignore/pages/';
            $config['total_rows'] = $this->profile->count_all_ignore($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->profile->get_ignore($this->user->id(), $config['per_page'], $this->uri->segment(4));
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('id_user', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id_user = $this->function->abs($this->input->post('id_user'));
                    
                    if ($id_user === '' OR $id_user === FALSE OR $id_user === NULL OR $id_user == 0 OR $id_user == $this->user->id())
                        $doc['error'][] = 'ID пользователя указан некорректно.';
                    elseif ($this->user->parse_id($id_user) === FALSE)
                        $doc['error'][] = 'Пользователь с таким ID не найден.';
                    elseif ($this->profile->check_ignore($id_user))
                        $doc['error'][] = 'Пользователь с таким ID уже есть в черном списке.';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->profile->add_ignore(array('id_user' => $this->user->id(), 'id_ignore' => $id_user, 'time' => now())))
                        {
                            $this->session->set_userdata(array('notice' => 'Выбранный ID успешно добавлен в черный список.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            if ($this->input->post('delete'))
            {
                $this->form_validation->set_rules('id_ignore', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $id_ignore = $this->function->abs($this->input->post('id_ignore'));
                    
                    if ($id_ignore === '' OR $id_ignore === FALSE OR $id_ignore === NULL OR $id_ignore == 0 OR $id_ignore == $this->user->id())
                        $doc['error'][] = 'ID пользователя указан некорректно.';
                    elseif ($this->profile->check_ignore($id_ignore) === FALSE)
                        $doc['error'][] = 'Пользователя с таким ID нет в черном списке.';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->profile->delete_ignore($id_ignore))
                        {
                            $this->session->set_userdata(array('notice' => 'Пользователь успешно удален из черного списка.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('profile/edit_ignore', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Персонализация
    public function edit_settings()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $doc['per_page'] = array('3' => '3', '5' => '5', '7' => '7', '10' => '10');
            $doc['view_smileys'] = array('1' => 'Отображать', '0' => 'Не отображать');
            $doc['view_tags'] = array('1' => 'Отображать', '0' => 'Не отображать');
            $doc['view_http'] = array('1' => 'Отображать', '0' => 'Не отображать');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('per_page', 'Пунктов на страницу', 'required|xss_clean|min_length[1]|numeric');
                $this->form_validation->set_rules('view_smileys', 'Смайлы', 'required|xss_clean|min_length[1]|numeric');
                $this->form_validation->set_rules('view_tags', 'HTML теги', 'required|xss_clean|min_length[1]|numeric');
                $this->form_validation->set_rules('view_http', 'Ссылки в тексте', 'required|xss_clean|min_length[1]|numeric');
                
                if ($this->form_validation->run())
                {
                    $per_page = $this->function->abs($this->input->post('per_page'));
                    $view_smileys = $this->function->abs($this->input->post('view_smileys'));
                    $view_tags = $this->function->abs($this->input->post('view_tags'));
                    $view_http = $this->function->abs($this->input->post('view_http'));
                    
                    if ($per_page == 0 OR $per_page === FALSE OR $per_page === NULL OR $per_page === '')
                        $doc['error'][] = 'Необходимо указать количество Пунктов на страницу.';
                    elseif ($per_page != 3 AND $per_page != 5 AND $per_page != 7 AND $per_page != 10)
                        $doc['error'][] = 'Поле Пунктов на страницу указано некорректно.';
                    if ($view_smileys != 0 AND $view_smileys != 1)
                        $doc['error'][] = 'Режим отображения Смайлов указан некорректно.';
                    if ($view_tags != 0 AND $view_tags != 1)
                        $doc['error'][] = 'Режим отображения HTML тегов указан некорректно.';
                    if ($view_http != 0 AND $view_http != 1)
                        $doc['error'][] = 'Режим отображения Ссылок в тексте указан некорректно.';    
                        
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('per_page' => $per_page, 'view_smileys' => $view_smileys, 'view_tags' => $view_tags, 'view_http' => $view_http)))
                        {
                            $this->session->set_userdata(array('notice' => 'Настройки персонализации успешно сохранены.'));
                            redirect(current_url());
                            exit();
                        }
                    }  
                }
            }
            
            $this->template->page('profile/edit_settings', $this->doc->by_default(array('title' => 'Персонализация', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Обновляем главное фото анкеты
    public function edit_avatar()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['avatar'] = array('name' => 'avatar');
            
            if ($this->input->post('submit')) {
                // Удаляем старые аватары
                @unlink(APPPATH . '../files/avatars/' . $this->user->hash_avatar() . '.png');
                @unlink(APPPATH . '../files/avatars/thumbs/' . $this->user->hash_avatar() . '_thumb.png');
                // Генерация нового хеша для аватара
                $hash_avatar = random_string('unique');
                $config['upload_path'] = './files/avatars/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']	= '7000';
                $config['max_width']  = '4608';
                $config['max_height']  = '3456';
                $config['remove_spaces'] = TRUE;
                $config['overwrite'] = TRUE;
                $config['file_name'] = $hash_avatar . '.png';
                $this->load->library('upload', $config);
                
                if ( ! $this->upload->do_upload('avatar')) 
                {
                    $doc['error'][] = $this->upload->display_errors();
        		} 
                else 
                {
        		  $upload_avatar = $this->upload->data();
        		  $config['image_library'] = 'gd2';
                  $config['source_image'] = $upload_avatar['full_path'];
                  $config['new_image'] = APPPATH . '../files/avatars/thumbs/' . $hash_avatar . '.png';
                  $config['create_thumb'] = TRUE;
                  $config['maintain_ratio'] = TRUE;
                  $config['width'] = 128;
                  $config['height'] = 128;
                  $this->load->library('image_lib', $config);   
                  $this->image_lib->resize();
                  $this->image_lib->clear(); 
                  $this->user->update(array('hash_avatar' => $hash_avatar));
                  $this->session->set_userdata(array('notice' => 'Аватар успшно обновлен.'));
                  redirect(current_url());
                  exit();
        		}
            }
            
            $this->template->page('profile/edit_avatar', $this->doc->by_default(array('title' => 'Главное фото', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Анкеты
    public function anketa()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $this->template->page('profile/anketa', $this->doc->by_default(array('title' => 'Заполнение Анкеты', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Основная
    public function edit_anketa1()
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = $this->user->parse_id($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['name'] = array('name' => 'name', 'value' => $this->input->post('name') ? $this->function->htmlspecialchars($this->input->post('name')) : $doc['user_data']['name'], 'maxlength' => '20', 'style' => 'width:99%', 'class' => 'form');
            $doc['welcome_msg'] = array('name' => 'welcome_msg', 'value' => $this->input->post('welcome_msg') ? $this->function->htmlspecialchars($this->input->post('welcome_msg')) : $doc['user_data']['welcome_msg'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['gender'] = array('m' => 'Мужской', 'w' => 'Женский');
            $doc['day'] = array('name' => 'day', 'value' => $this->input->post('day') ? $this->function->htmlspecialchars($this->input->post('day')) : $doc['user_data']['day'], 'maxlength'  => '2', 'size' => '2', 'class' => 'form');
            $doc['month'] = array('name' => 'month', 'value' => $this->input->post('month') ? $this->function->htmlspecialchars($this->input->post('month')) : $doc['user_data']['month'], 'maxlength' => '2','size' => '2', 'class' => 'form');
            $doc['year'] = array('name' => 'year', 'value' => $this->input->post('year') ? $this->function->htmlspecialchars($this->input->post('year')) : $doc['user_data']['year'], 'maxlength' => '4', 'size' => '4', 'class' => 'form');
            $doc['skype'] = array('name' => 'skype', 'value' => $this->input->post('skype') ? $this->function->htmlspecialchars($this->input->post('skype')) : $doc['user_data']['skype'], 'maxlength' => '31', 'style' => 'width:99%', 'class' => 'form');
            $doc['icq'] = array('name' => 'icq', 'value' => $this->input->post('icq') ? $this->function->htmlspecialchars($this->input->post('icq')) : $doc['user_data']['icq'], 'maxlength' => '10', 'style' => 'width:99%', 'class' => 'form');
            $doc['vk'] = array('name' => 'vk', 'value' => $this->input->post('vk') ? $this->function->htmlspecialchars($this->input->post('vk')) : $doc['user_data']['vk'], 'maxlength' => '20', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                 $this->form_validation->set_rules('name', 'Имя', 'required|xss_clean|min_length[2]|max_length[20]');
                 if ($this->input->post('welcome_msg'))
                 {
                    $this->form_validation->set_rules('welcome_msg', 'Приветствие', 'required|xss_clean|min_length[3]|max_length[255]');
                 }
                 $this->form_validation->set_rules('gender', 'Пол', 'required|xss_clean|exact_length[1]|alpha');
                 $this->form_validation->set_rules('day', 'Дата рождения', 'required|xss_clean|min_length[1]|max_length[2]|numeric');
                 $this->form_validation->set_rules('month', 'Месяц рождения', 'required|xss_clean|min_length[1]|max_length[2]|numeric');
                 $this->form_validation->set_rules('year', 'Год рождения', 'required|xss_clean|exact_length[4]|numeric');
                 
                 if ($this->input->post('skype'))
                 {
                    $this->form_validation->set_rules('skype', 'Skype', 'required|xss_clean|min_length[5]|max_length[31]|alpha_dash');
                 }
                 if ($this->input->post('icq'))
                 {
                    $this->form_validation->set_rules('icq', 'ICQ', 'required|xss_clean|min_length[6]|max_length[10]|numeric');
                 }
                 if ($this->input->post('vk'))
                 {
                    $this->form_validation->set_rules('vk', 'VK/ID', 'required|xss_clean|min_length[6]|max_length[20]|numeric');
                 }
                 
                 if ($this->form_validation->run())
                 {
                    $name = $this->function->variables($this->input->post('name'));
                    $welcome_msg = $this->function->variables($this->input->post('welcome_msg'));
                    $gender = $this->function->variables($this->input->post('gender'));
                    $day = $this->function->abs($this->input->post('day'));
                    $month = $this->function->abs($this->input->post('month'));
                    $year = $this->function->abs($this->input->post('year'));
                    $skype = $this->function->variables($this->input->post('skype'));
                    $icq = $this->function->abs($this->input->post('icq'));
                    $vk = $this->function->abs($this->input->post('vk'));
                    
                    if ( ! element($gender, $doc['gender']))
                        $doc['error'][] = 'Пол указан некорректно.';
                    
                    if (isset($name))
                    {
                        if (ctype_digit($name))
                            $doc['error'][] = 'Имя пользователя не может состоять из одних только цифр.';
                        elseif ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $name))
                            $doc['error'][] = 'Имя пользователя может содержать буквы русского или английского алфавита (комбинировать нельзя), а так же цифры от 1 до 9 и символы -, = и _.';
                    }
                    
                    if ($this->function->day($day))
                        $doc['error'][] = 'Дата рождения указана некорректно.';
                    elseif ($this->function->month($month))
                        $doc['error'][] = 'Месяц рождения указан некорректно.';
                    elseif ($this->function->year($year))
                        $doc['error'][] = 'Год рождения указан некорректно.';
                        
                    if ($skype)
                    {
                        if ( ! preg_match("#^[a-z][a-z0-9_\-\.]{5,31}$#ui", $skype))
                           $doc['error'][] = 'Неверный логин Skype.'; 
                    }
                    
                    if ($icq)
                    {
                        if ( ! ctype_digit($icq))
                            $doc['error'][] = 'Неверный UIN';
                    }
                    
                    if ($vk)
                    {
                        if ( ! ctype_digit($vk))
                            $doc['error'][] = 'Неверный Vk.com/id';
                    }
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('name' => $name, 'welcome_msg' => $welcome_msg, 'skype' => $skype, 'icq' => $icq, 'vk' => $vk, 'gender' => $gender, 'day' => $day, 'month' => $month, 'year' => $year)))
                        {
                            $this->session->set_userdata(array('notice' => 'Анкета успешно сохранена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                 }
            } 
            
            
            $this->template->page('profile/edit_anketa1', $this->doc->by_default(array('title' => 'Заполнение Анкеты | Основная', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Типаж
    public function edit_anketa2()
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = $this->user->parse_id($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['growth'] = array('name' => 'growth', 'value' => $this->input->post('growth') ? $this->function->htmlspecialchars($this->input->post('growth')) : $doc['user_data']['growth'], 'maxlength' => '3', 'style' => 'width:99%', 'class' => 'form');
            $doc['weight'] = array('name' => 'weight', 'value' => $this->input->post('weight') ? $this->function->htmlspecialchars($this->input->post('weight')) : $doc['user_data']['weight'], 'maxlength' => '3', 'style' => 'width:99%', 'class' => 'form');
            $doc['eye_color'] = array('name' => 'eye_color', 'value' => $this->input->post('eye_color') ? $this->function->htmlspecialchars($this->input->post('eye_color')) : $doc['user_data']['eye_color'], 'maxlength' => '20', 'style' => 'width:99%', 'class' => 'form');
            $doc['hair_color'] = array('name' => 'hair_color', 'value' => $this->input->post('hair_color') ? $this->function->htmlspecialchars($this->input->post('hair_color')) : $doc['user_data']['hair_color'], 'maxlength' => '20', 'style' => 'width:99%', 'class' => 'form');
            $doc['body_build'] = array('0' => 'Не отображать', '1' => 'Обычное', '2' => 'Худощавое', '3' => 'Спортивное', '4' => 'Мускулистое', '5' => 'Плотное', '6' => 'Полное');
            $doc['nature'] = array('name' => 'nature', 'value' => $this->input->post('nature') ? $this->function->htmlspecialchars($this->input->post('nature')) : $doc['user_data']['nature'], 'maxlength' => '20', 'style' => 'width:99%', 'class' => 'form');
            $doc['regimen'] = array('0' => 'Не отображать', '1' => 'Я - сова', '2' => 'Я - жаворонок');
            $doc['prof'] = array('name' => 'prof', 'value' => $this->input->post('prof') ? $this->function->htmlspecialchars($this->input->post('prof')) : $doc['user_data']['prof'], 'maxlength' => '64', 'style' => 'width:99%', 'class' => 'form');
            $doc['life'] = array('name' => 'life', 'value' => $this->input->post('life') ? $this->function->htmlspecialchars($this->input->post('life')) : $doc['user_data']['life'], 'maxlength' => '1000', 'style' => 'width:99%', 'class' => 'form');
          
            if ($this->input->post('submit'))
            {
                if ($this->input->post('growth'))
                    $this->form_validation->set_rules('growth', 'Рост', 'required|xss_clean|min_length[2]|max_length[3]|numeric');
                if ($this->input->post('weight'))
                    $this->form_validation->set_rules('weight', 'Вес', 'required|xss_clean|min_length[2]|max_length[3]|numeric');
                if ($this->input->post('eye_color'))
                    $this->form_validation->set_rules('eye_color', 'Цвет глаз', 'required|xss_clean|min_length[2]|max_length[20]');
                if ($this->input->post('hair_color'))
                    $this->form_validation->set_rules('hair_color', 'Цвет волос', 'required|xss_clean|min_length[2]|max_length[20]');
                if ($this->input->post('body_build'))
                    $this->form_validation->set_rules('body_build', 'Телосложение', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('nature'))
                    $this->form_validation->set_rules('nature', 'Характер', 'required|xss_clean|min_length[2]|max_length[20]');
                if ($this->input->post('regimen'))
                    $this->form_validation->set_rules('regimen', 'Режим дня', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('prof'))
                    $this->form_validation->set_rules('prof', 'Профессия', 'required|xss_clean|min_length[3]|max_length[64]');
                if ($this->input->post('life'))
                    $this->form_validation->set_rules('life', 'Жизненные цели:', 'required|xss_clean|min_length[2]|max_length[1000]');
    
                
                
                if ($this->form_validation->run())
                {
                    $growth = $this->function->abs($this->input->post('growth'));
                    $weight = $this->function->abs($this->input->post('weight'));
                    $eye_color = $this->function->variables($this->input->post('eye_color'));
                    $hair_color = $this->function->variables($this->input->post('hair_color'));
                    $body_build = $this->function->abs($this->input->post('body_build'));
                    $nature = $this->function->variables($this->input->post('nature'));
                    $regimen = $this->function->abs($this->input->post('regimen'));
                    $prof = $this->function->variables($this->input->post('prof'));
                    $life = $this->function->variables($this->input->post('life'));
                    
                    if ( ! element($body_build, $doc['body_build']))
                        $doc['error'][] = 'Телосложение указано некорректно.';
                    if ( ! element($regimen, $doc['regimen']))
                        $doc['error'][] = 'Режим дня указан некорректно.';
                        
                    if ($eye_color)
                    {
                        if ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $eye_color))
                            $doc['error'][] = 'Цвет глаз может содержать буквы русского или английского алфавита (комбинировать нельзя), а так же цифры от 1 до 9 и символы &quot;-&quot;, &quot;=&quot; и &quot;_&quot.';
                    }
                    
                    if ($hair_color)
                    {
                        if ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $hair_color))
                            $doc['error'][] = 'Цвет волос может содержать буквы русского или английского алфавита (комбинировать нельзя), а так же цифры от 1 до 9 и символы &quot;-&quot;, &quot;=&quot; и &quot;_&quot.';
                    }
                    
                    if ($nature)
                    {
                        if ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $nature))
                            $doc['error'][] = 'Характер может содержать буквы русского или английского алфавита (комбинировать нельзя), а так же цифры от 1 до 9 и символы &quot;-&quot;, &quot;=&quot; и &quot;_&quot.';
                    }
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('growth' => $growth, 'weight' => $weight, 'eye_color' => $eye_color, 'hair_color' => $hair_color, 'body_build' => "$body_build", 'nature' => $nature, 'regimen' => "$regimen", 'prof' => $prof, 'life' => $life)))
                        {
                            $this->session->set_userdata(array('notice' => 'Анкета успешно сохранена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('profile/edit_anketa2', $this->doc->by_default(array('title' => 'Заполнение Анкеты | Типаж', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Знакомства
    public function edit_anketa3()
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = $this->user->parse_id($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['sex_orient'] = array('0' => 'Не отображать', '1' => 'Гетеро', '2' => 'Гей', '3' => 'Би');  
            $doc['getting_target1'] = array('name' => 'getting_target1', 'value' => 1, 'checked' => $doc['user_data']['getting_target1']);
            $doc['getting_target2'] = array('name' => 'getting_target2', 'value' => 1, 'checked' => $doc['user_data']['getting_target2']);
            $doc['getting_target3'] = array('name' => 'getting_target3', 'value' => 1, 'checked' => $doc['user_data']['getting_target3']);
            $doc['getting_target4'] = array('name' => 'getting_target4', 'value' => 1, 'checked' => $doc['user_data']['getting_target4']);
            $doc['getting_target5'] = array('name' => 'getting_target5', 'value' => 1, 'checked' => $doc['user_data']['getting_target5']);
            $doc['getting_target6'] = array('name' => 'getting_target6', 'value' => 1, 'checked' => $doc['user_data']['getting_target6']);
            $doc['family'] = array('0' => 'Не отображать', '1' => 'Женат/Замужем', '2' => 'Холост/Не замужем', '3' => 'Живем раздельно');
            $doc['children'] = array('0' => 'Не отображать', '1' => 'Детей нет', '2' => 'Нет, но хотелось бы', '3' => 'Есть');
            $doc['sponsor'] = array('0' => 'Не отображать', '1' => 'Не нуждаюсь в спонсоре', '2' => 'Готов(а) стать спонсором', '3' => 'Ищу спонсора');
           
            if ($this->input->post('submit'))
            {
                if ($this->input->post('sex_orient'))
                    $this->form_validation->set_rules('sex_orient', 'Ориентация', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target1'))
                    $this->form_validation->set_rules('getting_target1', 'Дружба и общение', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target2'))
                    $this->form_validation->set_rules('getting_target2', 'Флирт, СМС-переписка', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target3'))
                    $this->form_validation->set_rules('getting_target3', 'Любовь, отношения', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target4'))
                    $this->form_validation->set_rules('getting_target4', 'Брак, создание семьи', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target5'))
                    $this->form_validation->set_rules('getting_target5', 'Виртуальный секс', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target6'))
                    $this->form_validation->set_rules('getting_target6', 'Секс в реале', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('family'))
                    $this->form_validation->set_rules('family', 'Семейное положение', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('children'))
                    $this->form_validation->set_rules('children', 'Дети', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('sponsor'))
                    $this->form_validation->set_rules('sponsor', 'Материальная поддержка', 'required|xss_clean|exact_length[1]|numeric');
                
                if ($this->form_validation->run())
                {
                    $sex_orient = $this->function->abs($this->input->post('sex_orient'));
                    $getting_target1 = $this->function->abs($this->input->post('getting_target1'));
                    $getting_target2 = $this->function->abs($this->input->post('getting_target2'));
                    $getting_target3 = $this->function->abs($this->input->post('getting_target3'));
                    $getting_target4 = $this->function->abs($this->input->post('getting_target4'));
                    $getting_target5 = $this->function->abs($this->input->post('getting_target5'));
                    $getting_target6 = $this->function->abs($this->input->post('getting_target6'));
                    $family = $this->function->abs($this->input->post('family'));
                    $children = $this->function->abs($this->input->post('children'));
                    $sponsor = $this->function->abs($this->input->post('sponsor'));
                    
                    if ($sex_orient)
                    {
                        if ( ! element($sex_orient, $doc['sex_orient']))
                            $doc['error'][] = 'Ориентация указана некорректно.';
                    }
                    
                    if ($getting_target1)
                    {
                        if ($getting_target1 != 0 AND $getting_target1 != 1)
                            $doc['error'][] = 'Дружба и общение указано некорректно.';
                    }
                    if ($getting_target2)
                    {
                        if ($getting_target2 != 0 AND $getting_target2 != 1)
                            $doc['error'][] = 'Флирт, СМС-переписка указано некорректно.';
                    }
                    if ($getting_target3)
                    {
                        if ($getting_target3 != 0 AND $getting_target3 != 1)
                            $doc['error'][] = 'Любовь, отношения указано некорректно.';
                    }
                    if ($getting_target4)
                    {
                        if ($getting_target4 != 0 AND $getting_target4 != 1)
                            $doc['error'][] = 'Брак, создание семьи указано некорректно.';
                    }
                    if ($getting_target5)
                    {
                        if ($getting_target5 != 0 AND $getting_target5 != 1)
                            $doc['error'][] = 'Виртуальный секс указан некорректно.';
                    }
                    if ($getting_target6)
                    {
                        if ($getting_target6 != 0 AND $getting_target6 != 1)
                            $doc['error'][] = 'Секс в реале указан некорректно.';
                    }
                    
                    if ($family)
                    {
                        if ( ! element($family, $doc['family']))
                            $doc['error'][] = 'Семейное положение указано некорректно.';
                    }
                    if ($children)
                    {
                        if ( ! element($children, $doc['children']))
                            $doc['error'][] = 'Дети указаны некорректно.';
                    }
                    if ($sponsor)
                    {
                        if ( ! element($sponsor, $doc['sponsor']))
                            $doc['error'][] = 'Материальная поддержка указана некорректно.';
                    }
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('sex_orient' => "$sex_orient", 'getting_target1' => "$getting_target1", 'getting_target2' => "$getting_target2", 'getting_target3' => "$getting_target3", 'getting_target4' => "$getting_target4", 'getting_target5' => "$getting_target5", 'getting_target6' => "$getting_target6", 'family' => "$family", 'children' => "$children", 'sponsor' => "$sponsor")))
                        {
                            $this->session->set_userdata(array('notice' => 'Анкета успешно сохранена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }            
            
            $this->template->page('profile/edit_anketa3', $this->doc->by_default(array('title' => 'Заполнение Анкеты | Знакомства', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function edit_anketa4()
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = $this->user->parse_id($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['sex_skill'] = array('0' => 'Не отображать', '1' => 'Большой', '2' => 'Небольшой', '3' => 'Нету');
            $doc['sex_often'] = array('0' => 'Не отображать', '1' => 'Хотя бы раз в день', '2' => 'Несколько раз в день', '3' => 'Несколько раз в неделю');
            $doc['sex_like'] = array('name' => 'sex_like', 'value' => $this->input->post('sex_like') ? $this->function->htmlspecialchars($this->input->post('profsex_like')) : $doc['user_data']['sex_like'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
           
            if ($this->input->post('submit'))
            {
                if ($this->input->post('sex_skill'))
                    $this->form_validation->set_rules('sex_skill', 'Сексуальный опыт', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('sex_often'))
                    $this->form_validation->set_rules('sex_often', 'Как часто хотелось бы заниматься сексом', 'required|xss_clean|exact_length[1]|numeric');
                
                if ($this->input->post('sex_like'))
                {
                    $this->form_validation->set_rules('sex_like', 'В сексе я люблю', 'required|xss_clean|min_length[3]|max_length[255]');
                }
                 
                if ($this->form_validation->run())
                {
                    $sex_skill = $this->function->abs($this->input->post('sex_skill'));
                    $sex_often = $this->function->abs($this->input->post('sex_often'));
                    $sex_like = $this->function->variables($this->input->post('sex_like'));
                    
                    if ($sex_skill)
                    {
                        if ( ! element($sex_skill, $doc['sex_skill']))
                            $doc['error'][] = 'Сексуальный опыт указан некорректно.';
                    }
                    
                    if ($sex_often)
                    {
                        if ( ! element($sex_often, $doc['sex_often']))
                            $doc['error'][] = 'Как часто хотелось бы заниматься сексом указано некорректно.';
                    }
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('sex_skill' => "$sex_skill", 'sex_often' => "$sex_often", 'sex_like' => $sex_like)))
                        {
                            $this->session->set_userdata(array('notice' => 'Анкета успешно сохранена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }     
            
            $this->template->page('profile/edit_anketa4', $this->doc->by_default(array('title' => 'Заполнение Анкеты | Сексуальные предпочтения', 'page' => 'my_profie'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}