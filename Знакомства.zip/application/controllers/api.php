<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
        $this->load->model('model_api', 'api', FALSE);
        $this->load->model('model_city', 'city', FALSE);
    }
    
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $this->template->page('api/main', $this->doc->by_default(array('title' => 'Пополнить баланс', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // SMS
    public function addcash()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/api/addcash/pages/';
            $config['total_rows'] = $this->db->count_all('sms_country');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->api->get_country($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('api/addcash', $this->doc->by_default(array('title' => 'Пополнить баланс', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем страну
    public function add_country($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $id = $this->function->abs($id);
            
            if ($id > 0)
            {
                if ($country_data = $this->city->check_country($id))
                {
                    if ($this->api->add_country(array('country' => $country_data['country_name_ru'], 'id_country' => $country_data['oid'])))
                    {
                        $this->session->set_userdata(array('notice' =>  $country_data['country_name_ru'] . ' успешно добавлена в список.'));
                        redirect(base_url() . 'index.php/api/addcash');
                        exit();
                    }
                }
                else
                {
                    $doc['error'][] = 'Страна выбранна некорректно.';
                }
            } 
            
            $config['base_url'] =  base_url() . 'index.php/api/add_country/pages/';
            $config['total_rows'] = $this->db->count_all('country_');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->city->get_country($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('api/add_country', $this->doc->by_default(array('title' => 'Админка', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем страну
    public function edit_country($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($id > 0)
            {
                if ($country_data = $this->api->check_country($id))
                {
                    $doc['country'] = array('name' => 'country', 'value' => $this->input->post('country') ? $this->function->htmlspecialchars($this->input->post('country')) : $country_data['country'], 'maxlength' => '60', 'style' => 'width:99%', 'class' => 'form');
                    $doc['id_country'] = array('name' => 'id_country', 'value' => $this->input->post('id_country') ? $this->function->htmlspecialchars($this->input->post('id_country')) : $country_data['id_country'], 'maxlength' => '11', 'style' => 'width:99%', 'class' => 'form');
                    
                    if ($this->input->post('submit'))
                    {
                        $this->form_validation->set_rules('country', 'Название страны', 'required|xss_clean|min_length[2]|max_length[60]');
                        $this->form_validation->set_rules('id_country', 'ID страны', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                        
                        if ($this->form_validation->run())
                        {
                            $country = $this->function->variables($this->input->post('country'));
                            $id_country = $this->function->abs($this->input->post('id_country'));
                            
                            if ($this->api->edit_country($country_data['id'], array('country' => $country, 'id_country' => $id_country)))
                            {
                                $this->session->set_userdata(array('notice' =>  'Страна успешно отредактирована.'));
                                redirect(base_url() . 'index.php/api/addcash');
                                exit();
                            }
                        }
                    }
                }
                else
                {
                    show_404();
                }
            }
            
            $this->template->page('api/edit_country', $this->doc->by_default(array('title' => 'Админка', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Список кодов для отправки
    public function country($id = '')
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($country_data = $this->api->check_country($id))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            $config['base_url'] =  base_url() . 'index.php/api/country/' . $doc['country_data']['id'] . '/pages/';
            $config['total_rows'] = $this->api->count_all_number($doc['country_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->api->get_tarif_id_country($doc['country_data']['id'], $config['per_page'], $this->uri->segment(4));
            
            $this->template->page('api/country', $this->doc->by_default(array('title' => 'Пополнить баланс', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем тариф
    public function add_tarif($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['number'] = array('name' => 'number', 'value' => $this->function->htmlspecialchars($this->input->post('number')), 'maxlength' => '10', 'class' => 'form');
            $doc['balls'] = array('name' => 'balls', 'value' => $this->function->htmlspecialchars($this->input->post('balls')), 'maxlength' => '10', 'class' => 'form');
            $doc['price'] = array('name' => 'price', 'value' => $this->function->htmlspecialchars($this->input->post('price')), 'maxlength' => '10', 'class' => 'form');
           
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($country_data = $this->api->check_country($id))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            if ($this->input->post('submit'))
            {
                 $this->form_validation->set_rules('number', 'Номер телефона на который будут отправляться смс', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 $this->form_validation->set_rules('balls', 'Вознаграждение в баллах', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 $this->form_validation->set_rules('price', 'Стоимость отправки смс', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 if ($this->form_validation->run())
                 {
                    $number = $this->function->abs($this->input->post('number'));
                    $balls = $this->function->abs($this->input->post('balls'));
                    $price = $this->function->abs($this->input->post('price'));
                    
                    if ($number == 0)
                        $doc['error'][] = 'Телефонный номер не может быть 0 (ноль).';
                    if ($balls == 0)
                        $doc['error'][] = 'Вознаграждение должно быть выше чем 0 (ноль).';
                    if ($price == 0)
                        $doc['error'][] = 'Стоимость не может быть ниже чем 0 (ноль).';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->api->add_tarif(array('id_sms_country' => $doc['country_data']['id'], 'number' => $number, 'balls' => $balls, 'price' => $price)))
                        {
                            $this->session->set_userdata(array('notice' =>  'Тариф успешно добавлен.'));
                            redirect(base_url() . 'index.php/api/country/' . $doc['country_data']['id']);
                            exit();
                        }
                    }
                 }
            }
            $this->template->page('api/add_tarif', $this->doc->by_default(array('title' => 'Админка', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Редактировать тарифы
    public function edit_tarif($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($tarif_data = $this->api->check_tarif($id))
            {
                $doc['tarif_data'] = $tarif_data;
            }
            else
            {
                show_404();
            }
            
            if ($country_data = $this->api->check_country($doc['tarif_data']['id_sms_country']))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['number'] = array('name' => 'number', 'value' => $this->input->post('number') ? $this->function->htmlspecialchars($this->input->post('number')) : $doc['tarif_data']['number'], 'maxlength' => '10', 'class' => 'form');
            $doc['balls'] = array('name' => 'balls', 'value' => $this->input->post('balls') ? $this->function->htmlspecialchars($this->input->post('balls')) : $doc['tarif_data']['balls'], 'maxlength' => '10', 'class' => 'form');
            $doc['price'] = array('name' => 'price', 'value' => $this->input->post('price') ? $this->function->htmlspecialchars($this->input->post('price')) : $doc['tarif_data']['price'], 'maxlength' => '10', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                 $this->form_validation->set_rules('number', 'Номер телефона на который будут отправляться смс', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 $this->form_validation->set_rules('balls', 'Вознаграждение в баллах', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 $this->form_validation->set_rules('price', 'Стоимость отправки смс', 'required|xss_clean|min_length[1]|max_length[10]|numeric');
                 if ($this->form_validation->run())
                 {
                    $number = $this->function->abs($this->input->post('number'));
                    $balls = $this->function->abs($this->input->post('balls'));
                    $price = $this->function->abs($this->input->post('price'));
                    
                    if ($number == 0)
                        $doc['error'][] = 'Телефонный номер не может быть 0 (ноль).';
                    if ($balls == 0)
                        $doc['error'][] = 'Вознаграждение должно быть выше чем 0 (ноль).';
                    if ($price == 0)
                        $doc['error'][] = 'Стоимость не может быть ниже чем 0 (ноль).';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->api->edit_tarif($doc['tarif_data']['id'], array('number' => $number, 'balls' => $balls, 'price' => $price)))
                        {
                            $this->session->set_userdata(array('notice' =>  'Тариф успешно отредактирован.'));
                            redirect(base_url() . 'index.php/api/country/' . $doc['country_data']['id']);
                            exit();
                        }
                    }
                 }
            }
            
            $this->template->page('api/edit_tarif', $this->doc->by_default(array('title' => 'Админка', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Отправка смс
    public function tarif($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($tarif_data = $this->api->check_tarif($id))
            {
                $doc['tarif_data'] = $tarif_data;
            }
            else
            {
                show_404();
            }
            
            if ($country_data = $this->api->check_country($doc['tarif_data']['id_sms_country']))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $this->template->page('api/tarif', $this->doc->by_default(array('title' => 'Отправка смс', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление тарифа
    public function delete_tarif($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
            
            if ($tarif_data = $this->api->check_tarif($id))
            {
                $doc['tarif_data'] = $tarif_data;
            }
            else
            {
                show_404();
            }
            
            if ($country_data = $this->api->check_country($doc['tarif_data']['id_sms_country']))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            if (empty($doc['error']))
            {
                if ($this->api->delete_tarif($doc['tarif_data']['id']))
                {
                    $this->session->set_userdata(array('notice' =>  'Тариф успешно удален.'));
                    redirect(base_url() . 'index.php/api/country/' . $doc['country_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Удаление страны
    public function delete_country($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                show_404();
            }
    
            
            if ($country_data = $this->api->check_country($id))
            {
                $doc['country_data'] = $country_data;
            }
            else
            {
                show_404();
            }
            
            if (empty($doc['error']))
            {
                if ($this->api->delete_country($doc['country_data']['id']))
                {
                    $this->session->set_userdata(array('notice' =>  'Страна и тарифы успешно удалены.'));
                    redirect(base_url() . 'index.php/api/addcash/');
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // WM
    public function wmpay()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->api->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['user_id'] = array('name' => 'user_id', 'value' => $this->input->post('user_id') ? $this->function->htmlspecialchars($this->input->post('user_id')) : $this->user->id(), 'maxlength' => '11', 'class' => 'form');
            $doc['amount'] = array('name' => 'amount', 'value' => $this->input->post('amount') ? $this->function->htmlspecialchars($this->input->post('amount')) : '50', 'maxlength' => '11', 'class' => 'form');
            $doc['paytype'] = array('WMR' => 'WMR', 'WMZ' => 'WMZ');
            
            $this->session->unset_userdata('balls');
            $this->session->unset_userdata('amount');
            $this->session->unset_userdata('paytype');
            $this->session->unset_userdata('user_id');
            $this->session->unset_userdata('payee');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('user_id', 'ID анкеты', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                $this->form_validation->set_rules('amount', 'Сумма', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $id_user = $this->function->abs($this->input->post('user_id'));
                    $amount = $this->function->abs($this->input->post('amount'));
                    $paytype = $this->function->variables($this->input->post('paytype'));
                    
                    if ($id_user === '' OR $id_user === FALSE OR $id_user === NULL OR $id_user == 0)
                        $doc['error'][] = 'ID пользователя указан некорректно.';
                    elseif ($this->user->parse_id($id_user) === FALSE)
                        $doc['error'][] = 'Пользователь с таким ID не найден.';
                    if ($amount < 1)
                        $doc['error'][] = 'Сумма пополнения указана некорректно.';
                    if ( ! element($paytype, $doc['paytype']))
                        $doc['error'][] = 'Тип кошелька указан некорректно.';
                        
                    if (empty($doc['error']))
                    {
                        if ($paytype == 'WMR')
                        {
                            $tarif = '100'; // Цена за рубыль
                            $payee = $doc['config']['WMR'];
                        }
                        elseif ($paytype == 'WMZ')
                        {
                            $tarif = '3000'; // Цена за бакс
                            $payee = $doc['config']['WMZ'];
                        }
                        else
                        {
                            $tarif = '100'; // Цена за рубыль
                            $payee = $doc['config']['WMR'];
                        }
                        
                        $balls = $amount * $tarif;
                        $this->session->set_userdata(array('balls' =>  $balls, 'amount' => $amount, 'paytype' => $paytype, 'user_id' => $id_user, 'payee' => $payee));
                        
                    }
                } 
            }
            
            $this->template->page('api/wmpay', $this->doc->by_default(array('title' => 'Пополнить баланс', 'page' => 'api'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Обработчик
    public function wm_surccess()
    {
        if ($this->user->is_user())
        {
            $this->session->set_userdata(array('notice' =>  'Баланс успешно пополнен.'));
            redirect(base_url());
            exit();
        }
        else
        {
            show_404();
        }
    }
    
    
    public function wm_result()
    {
        
        $doc['config'] = $this->api->config();
        $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
        $doc['error'] = array();
        
        // Задаем значение $secret_key.
        // Оно должно совпадать с Secret Key, указанным нами в настройках кошелька.
        $secret_key="54rwr3fewr";
        // Склеиваем строку параметров
        $common_string = $_POST['LMI_PAYEE_PURSE'].$_POST['LMI_PAYMENT_AMOUNT'].$_POST['LMI_PAYMENT_NO'].
        $_POST['LMI_MODE'].$_POST['LMI_SYS_INVS_NO'].$_POST['LMI_SYS_TRANS_NO'].
        $_POST['LMI_SYS_TRANS_DATE'].$secret_key.$_POST['LMI_PAYER_PURSE'].$_POST['LMI_PAYER_WM'];
        // Шифруем полученную строку в MD5 и переводим ее в верхний регистр
        $hash = strtoupper(md5($common_string));
        // Прерываем работу скрипта, если контрольные суммы не совпадают
        if($hash!=$_POST['LMI_HASH']) exit();
    
        if ($_POST['LMI_PREREQUEST'] == 1)
        {
            // Проверим есть ли ид такой анкеты
            if ($this->user->parse_id($this->function->abs($this->input->post('anketaID'))) === FALSE)
            {
                echo 'ERR: Нет такого пользователя';
                exit();
            }
                
            
            if($this->function->abs($this->input->post('LMI_PAYMENT_AMOUNT')) === '' OR $this->function->abs($this->input->post('LMI_PAYMENT_AMOUNT')) === FALSE OR $this->function->abs($this->input->post('LMI_PAYMENT_AMOUNT')) === NULL OR $this->function->abs($this->input->post('LMI_PAYMENT_AMOUNT')) == 0) 
            {
                echo 'ERR: Неверная сумма платежа ' . $_POST['LMI_PAYMENT_AMOUNT'];
                exit();
            }
            
            if($this->function->variables($this->input->post('LMI_PAYEE_PURSE')) != $doc['config']['WMR'] AND $this->function->variables($this->input->post('LMI_PAYEE_PURSE')) != $doc['config']['WMZ'])
            {
                echo 'ERR: Неверный кошелек получателя ' . $_POST['LMI_PAYEE_PURSE'];
                exit();
            }

        }
        else
        {
            // Задаем значение $secret_key.
            // Оно должно совпадать с Secret Key, указанным нами в настройках кошелька.
            $secret_key="54rwr3fewr";
            // Склеиваем строку параметров
            $common_string = $_POST['LMI_PAYEE_PURSE'].$_POST['LMI_PAYMENT_AMOUNT'].$_POST['LMI_PAYMENT_NO'].
            $_POST['LMI_MODE'].$_POST['LMI_SYS_INVS_NO'].$_POST['LMI_SYS_TRANS_NO'].
            $_POST['LMI_SYS_TRANS_DATE'].$secret_key.$_POST['LMI_PAYER_PURSE'].$_POST['LMI_PAYER_WM'];
            // Шифруем полученную строку в MD5 и переводим ее в верхний регистр
            $hash = strtoupper(md5($common_string));
            // Прерываем работу скрипта, если контрольные суммы не совпадают
            if($hash!=$_POST['LMI_HASH']) exit();
            
            $user = $this->user->parse_id($this->function->abs($this->input->post('anketaID')));
            
            if ($this->function->variables($this->input->post('LMI_PAYEE_PURSE')) == $doc['config']['WMR'])
            {
                $balls = 100 * $this->function->variables($this->input->post('LMI_PAYMENT_AMOUNT'));
            }
            elseif ($this->function->variables($this->input->post('LMI_PAYEE_PURSE')) == $doc['config']['WMZ'])
            {
                $balls = 3000 * $this->function->variables($this->input->post('LMI_PAYMENT_AMOUNT'));
            }
            else
            {
                $balls = 100 * $this->function->variables($this->input->post('LMI_PAYMENT_AMOUNT'));
            }
            
            if ($this->profile->edit_profile($this->function->abs($this->input->post('anketaID')), array('balls' => $user['balls'] + $balls)))
            {
                $this->session->set_userdata(array('notice' =>  'Баланс успешно пополнен.'));
            }
            else
            {
                $this->session->set_userdata(array('notice' =>  'Баланс не пополнен.'));
            }
        }
    }

    public function wm_fail()
    {
        redirect(base_url());
        exit();
    }
    
    
    public function sms($keys = '')
    {
        echo $keys['date'];
    }
}