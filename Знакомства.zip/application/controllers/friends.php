<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Настройки профиля

class Friends extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_friends', 'friend', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    public function index($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['user_data'] = '';
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                 $id = $this->user->id();
            }
            
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            
            if (is_array($doc['user_data']))
            {
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('id_user', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                    if ($this->form_validation->run())
                    {
                        $id_user = $this->function->abs($this->input->post('id_user'));
                        
                        if ($this->user->check_friends($id_user))
                        {
                            if ($this->friend->delete_friends($id_user))
                            {
                                $this->session->set_userdata(array('notice' => 'Пользователь успешно удален из списка ваших друзей.'));
                                $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $id_user, 'description' =>  '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], удалил вас из списка своих друзей.', 'time' => now(), 'read' => '1'));
                                redirect(current_url());
                                exit();
                            }
                        }
                        else
                        {
                            $doc['error'][] = 'Такого пользователя нет в списке ваших друзей.';
                        }
                    }
                }
                
                $config['base_url'] =  base_url() . 'index.php/friends/index/' . $doc['user_data']['id'] . '/pages/';
                $config['total_rows'] = $this->friend->count_all_friends($doc['user_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
                
                $this->pagination->initialize($config);
                
                $doc['foreach'] = $this->friend->get_friends($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
            
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'friends'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['view_friends'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('friends/error_view_friends', $this->doc->by_default(array('title' => 'Мои друзья', 'page' => 'friends'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['view_friends'] == 2))
                {
                    $this->template->page('friends/view_friends_not_found', $this->doc->by_default(array('title' => 'Мои друзья', 'page' => 'friends'), $doc));
                }
                else
                {
                    $this->template->page('friends/main', $this->doc->by_default(array('title' => 'Мои друзья', 'page' => 'friends'), $doc));
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'friends')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function add_friends($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['toward'] = array('0' => 'Друзья на Wapdoza.Ru', '1' => 'Лучшие друзья', '2' => 'Колеги', '3' => 'Одноклассники', '4' => 'Однокурссники', '5' => 'Родственники', '6' => 'Братья Сестры');
            $doc['user_data'] = '';
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            elseif ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            
            // Массив с данными пользователя
            if (is_array($doc['user_data']))
            {
                // Если в Игноре
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'friends'), $doc));
                }
                // Если пользователь не принимает дружбу
                elseif ($this->friend->check_add_friends($doc['user_data']['id']))
                {
                    $this->template->page('friends/error_add_friends', $this->doc->by_default(array('title' => 'Друзья', 'page' => 'friends'), $doc));
                }
                // Если есть в списке друзей
                elseif ($this->friend->check_friends($doc['user_data']['id']))
                {
                    $this->template->page('friends/friends', $this->doc->by_default(array('title' => 'Друзья', 'page' => 'friends'), $doc));
                }
                // Если есть исходящая заявка
                elseif ($this->friend->check_sent_friend($doc['user_data']['id']))
                {
                    $this->template->page('friends/sent_friends', $this->doc->by_default(array('title' => 'Друзья', 'page' => 'friends'), $doc));
                }
                // Если есть входящая заявка
                elseif ($friends_data = $this->friend->check_inbox_friends($doc['user_data']['id']))
                {
                    $doc['friends_data'] = $friends_data;
                    
                    if ($this->input->post('submit'))
                    {
                        $this->form_validation->set_rules('toward', 'Статус отношений', 'required|xss_clean|exact_length[1]|numeric');
                        if ($this->form_validation->run())
                        {
                            $toward = $this->function->abs($this->input->post('toward'));
                            
                            if ($doc['friends_data']['toward'] == $toward)
                            {
                                $toward = $doc['friends_data']['toward'];
                            }
                            else
                            {
                                $toward = 0;
                            }
                                
                            if ($toward != 0 AND $toward != 1 AND $toward != 2 AND $toward != 3 AND $toward != 4 AND $toward != 5 AND $toward != 6) 
                                $doc['error'][] = 'Статус отношений установлен некорректно.';
                            if ($this->friend->check_friends($doc['user_data']['id']) === TRUE)
                                $doc['error'][] = 'Пользователь уже есть в списке ваших друзей';   
                            if ($this->friend->check_inbox_friends($doc['user_data']['id']))
                            {
                                if ($this->friend->add_app_friends($doc['user_data']['id'], $toward))
                                {
                                    $this->session->set_userdata(array('notice' => 'Предложение на дружбу успешно принято.'));
                                    $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], принял ваше предложение дружбы.', 'time' => now(), 'read' => '1'));
                                    redirect(current_url());
                                    exit();
                                }
                            } 
                            else
                            {
                                $doc['error'][] = 'Заявка на добавление в друзья не найдена.';
                            }
                        }
                    }
                    
                    if ($this->input->post('cencell'))
                    {
                        if ($this->friend->check_inbox_friends($doc['user_data']['id']))
                        {
                            if ($this->friend->delete_app_friends($doc['user_data']['id']))
                            {
                                $this->session->set_userdata(array('notice' => 'Предложение на дружбу успешно отклонено.'));
                                $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], отклонил ваше предложение дружбы.', 'time' => now(), 'read' => '1'));
                                redirect(current_url());
                                exit();
                            }
                        } 
                        else
                        {
                            $doc['error'][] = 'Заявка на добавление в друзья не найдена.';
                        }
                    }
                    
                    $this->template->page('friends/inbox_friends', $this->doc->by_default(array('title' => 'Друзья', 'page' => 'friends'), $doc));
                }
                else
                {
                    if ($this->input->post('submit'))
                    {
                        $this->form_validation->set_rules('toward', 'Статус отношений', 'required|xss_clean|exact_length[1]|numeric');
                        if ($this->form_validation->run())
                        {
                            $toward = $this->function->abs($this->input->post('toward'));
                            
                            if ($toward != 0 AND $toward != 1 AND $toward != 2 AND $toward != 3 AND $toward != 4 AND $toward != 5 AND $toward != 6) 
                                $doc['error'][] = 'Статус отношений установлен некорректно.';
                            if (empty($doc['error']))
                            {
                                if ($this->friend->add_friends($doc['user_data']['id'], $toward))
                                {
                                    $this->session->set_userdata(array('notice' => 'Запрос на добавление в друзья успешно отправлен.'));
                                    $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], хочет добавить вас в список своих [url=' . base_url() . 'index.php/friends/app_friends]друзей[/url].', 'time' => now(), 'read' => '1'));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                    }
                    
                    $this->template->page('friends/add_friends', $this->doc->by_default(array('title' => 'Заявка в друзья', 'page' => 'friends'), $doc));
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'friends')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function app_friends()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['toward'] = array('0' => 'Друзья на Wapdoza.Ru', '1' => 'Лучшие друзья', '2' => 'Колеги', '3' => 'Одноклассники', '4' => 'Однокурссники', '5' => 'Родственники', '6' => 'Братья Сестры');
         
            $config['base_url'] =  base_url() . 'index.php/friends/app_friends/pages/';
            $config['total_rows'] = $this->friend->count_all_app_friends($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->friend->get_app_friends($this->user->id(), $config['per_page'], $this->uri->segment(4));
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('toward', 'Статус отношений', 'required|xss_clean|exact_length[1]|numeric');
                $this->form_validation->set_rules('id_user', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $toward = $this->function->abs($this->input->post('toward'));
                    $id_user = $this->function->abs($this->input->post('id_user'));
                    
                    if ($friends_data = $this->friend->check_inbox_friends($id_user))
                    {
                        $doc['friends_data'] = $friends_data;
                        
                        if ($doc['friends_data']['toward'] == $toward)
                        {
                            $toward = $doc['friends_data']['toward'];
                        }
                        else
                        {
                            $toward = 0;
                        }
                             
                        if ($toward != 0 AND $toward != 1 AND $toward != 2 AND $toward != 3 AND $toward != 4 AND $toward != 5 AND $toward != 6) 
                            $doc['error'][] = 'Статус отношений установлен некорректно.';
                        if ($this->friend->check_friends($doc['friends_data']['id_user']) === TRUE)
                            $doc['error'][] = 'Пользователь уже есть в списке ваших друзей';
                            
                        if (empty($doc['error']))
                        {
                            if ($this->friend->add_app_friends($doc['friends_data']['id_user'], $toward))
                            {
                                $this->session->set_userdata(array('notice' => 'Предложение на дружбу успешно принято.'));
                                $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['friends_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], принял ваше предложение дружбы.', 'time' => now(), 'read' => '1'));
                                redirect(current_url());
                                exit();
                            }
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Заявка на добавление в друзья не найдена.';
                    }
                }
            }
            
            if ($this->input->post('cencell'))
            {
                $this->form_validation->set_rules('id_user', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $id_user = $this->function->abs($this->input->post('id_user'));
                    
                    if ($friends_data = $this->friend->check_inbox_friends($id_user))
                    {
                        $doc['friends_data'] = $friends_data;
                        
                        if ($this->friend->delete_app_friends($doc['friends_data']['id_user']))
                        {
                            $this->session->set_userdata(array('notice' => 'Предложение на дружбу успешно отклонено.'));
                            $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['friends_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], отклонил ваше предложение дружбы.', 'time' => now(), 'read' => '1'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Заявка на добавление в друзья не найдена.';
                    }
                }
            }
            
            $this->template->page('friends/app_friends', $this->doc->by_default(array('title' => 'Предложения на дружбу', 'page' => 'friends'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Прямая ссылка на удаление из друзей
    public function delete_friends($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            
            elseif ($this->user->check_friends($id))
            {
                if ($this->friend->delete_friends($id))
                {
                    $this->session->set_userdata(array('notice' => 'Пользователь успешно удален из списка ваших друзей.'));
                    $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $id, 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], удалил вас из списка своих друзей.', 'time' => now(), 'read' => '1'));
                    redirect(base_url() . 'index.php/friends/index/' . $this->user->id());
                    exit();
                }
            }
            else
            {
                redirect(base_url());
                exit();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}