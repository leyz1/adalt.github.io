<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Модуль приватной почты

class Photo extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
        $this->load->model('model_photo', 'photo', FALSE);
        //$this->output->enable_profiler(TRUE); 
    }
    
    public function index($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['user_data'] = '';
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
                
            if ($id === '' OR $id === NULL OR $id === FALSE OR $id == 0)
            {
                $id = $this->user->id();
            }
            
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            
            if (is_array($doc['user_data']))
            {
                
                $config['base_url'] =  base_url() . 'index.php/photo/index/' . $doc['user_data']['id'] . '/pages/';
                $config['total_rows'] = $this->photo->count_all_photo_id($doc['user_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
                
                $this->pagination->initialize($config);
                
                $doc['foreach'] = $this->photo->get_photo($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
            
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'photo')));
                }
                else
                {
                    $this->template->page('photo/main', $this->doc->by_default(array('title' => 'Фото', 'page' => 'photo'), $doc));
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем новые фото
    public function add_photo()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['upload_photo'] = array('name' => 'upload_photo');
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
        
            if ( ! is_dir(APPPATH . './../files/photos/' . $this->user->id()))
            {
                @mkdir(APPPATH . '../files/photos/' . $this->user->id() . '/', 0777);
                @mkdir(APPPATH . '../files/photos/' . $this->user->id() . '/thumbs/', 0777);
            }
            
            
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE) {
                
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                if ($this->input->post('description'))
                {
                    $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                }
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        // Генерация нового хеша для аватара
                        $hash_photo = random_string('unique');
                        
                        $config['upload_path'] = './files/photos/' . $this->user->id();
                        $config['allowed_types'] = 'gif|jpg|png';
                        $config['max_size']	= '7000';
                        $config['max_width']  = '4608';
                        $config['max_height']  = '3456';
                        $config['remove_spaces'] = TRUE;
                        $config['overwrite'] = TRUE;
                        $config['file_name'] = $hash_photo . '.png';
                        $this->load->library('upload', $config);
                        
                        if ( ! $this->upload->do_upload('upload_photo')) 
                        {
                            $doc['error'][] = $this->upload->display_errors();
                		} 
                        else 
                        {
                		  $upload_photo = $this->upload->data();
                		  $config['image_library'] = 'gd2';
                          $config['source_image'] = $upload_photo['full_path'];
                          $config['new_image'] = APPPATH . '../files/photos/' . $this->user->id() . '/thumbs/' . $hash_photo . '.png';
                          $config['create_thumb'] = TRUE;
                          $config['maintain_ratio'] = TRUE;
                          $config['width'] = 128;
                          $config['height'] = 128;
                          $this->load->library('image_lib', $config);   
                          $this->image_lib->resize();
                          $this->image_lib->clear(); 
                          $this->photo->add_photo(array('id_user' => $this->user->id(), 'hash_file' => $hash_photo,'title' => $title, 'description' => $description, 'time' => now(), 'gender' => $this->user->gender(), 'file_size' => $upload_photo['file_size'], 'rating' => '0', 'moder' => '1'));
                          $this->session->set_userdata(array('notice' => 'Фото успешно добавлено.'));
                          $this->user->balls($doc['config']['balls_photo']);
                          redirect(current_url());
                          exit();
                		}
                    }
                }
            }
            
            $this->template->page('photo/add_photo', $this->doc->by_default(array('title' => 'Загрузка фото', 'page' => 'photo'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Скачка файла
    public function download_file($id = '', $hash = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            if ($id === '' AND $id === NULL AND $id === FALSE AND $id == 0)
            {
                show_404();
            }
            elseif ($hash === '' AND $hash === FALSE AND $hash === NULL AND $hash == 0)
            {
                show_error('Запрашиваемый файл не найден на сервере.');
            }
            elseif (file_exists(APPPATH . '../files/photos/' . $id . '/' . $this->function->htmlspecialchars($hash) . '.png'))
            {
                $data = file_get_contents(APPPATH . '../files/photos/' . $id . '/' . $this->function->htmlspecialchars($hash) . '.png'); // Считываем содержимое файла
                $name = 'wapdoza.ru.' . $hash . '.png';
                force_download($name, $data); 
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // голосования за фото
    public function vote_photo($id = '', $vote = 'plus')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($vote === '' OR $vote === FALSE OR $vote === NULL)
            {
                show_404();
            }
            
            if ($vote != 'plus' AND $vote != 'minus')
            {
                show_404();
            }
            
            if ($photo_data = $this->photo->check_photo($id))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
            }
            
            if (is_array($doc['photo_data']))
            {
                if ($this->user->check_ignore($doc['photo_data']['id_user']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'photo')));
                }
                else
                {
                    if ($vote == 'plus')
                    {
                        $rating = $doc['photo_data']['rating'] + 1;
                        $ocenka = '+';
                    }
                    elseif ($vote == 'minus')
                    {
                        $rating = $doc['photo_data']['rating'] - 1;
                        $ocenka = '-';
                    }
                    
                    if ($this->photo->check_vote_photo($doc['photo_data']['id']) === FALSE)
                    {
                        if ($this->photo->add_vote_photo_id($doc['photo_data']['id']))
                        {
                            $this->photo->update_photo($doc['photo_data']['id'], array('rating' => $rating));
                            $this->session->set_userdata(array('notice' => 'Ваш голос успешно принят.'));
                            if ($this->user->id() != $doc['photo_data']['id_user'])
                            {
                                 $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['photo_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], оценил ваше [url=' . base_url() . 'index.php/photo/comments/' . $doc['photo_data']['id'] . ']фото[/url]. Оценка ' . $ocenka . ' 1.', 'time' => now(), 'read' => '1'));
                            }
                            redirect('photo/index/' . $doc['photo_data']['id_user']);
                            exit();
                        }
                        else
                        {
                            redirect('photo/index/' . $doc['photo_data']['id_user']);
                            exit();
                        }
                    }
                    else
                    {
                        redirect('photo/index/' . $doc['photo_data']['id_user']);
                        exit();
                    }
                }
            }
            else
            {
                $this->template->page('photo/error_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Комментарий к фото
    public function comments($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
        
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($photo_data = $this->photo->check_photo($id))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
            }
            
            if (is_array($doc['photo_data']) AND $user_data =$this->user->parse_id($doc['photo_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            
            if (is_array($doc['photo_data']) AND is_array($doc['user_data']))
            {
                $config['base_url'] =  base_url() . 'index.php/photo/comments/' . $doc['photo_data']['id'] . '/pages/';
                $config['total_rows'] = $this->photo->count_all_comments_id($doc['photo_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
    
                // Инициализация
                $this->pagination->initialize($config);
                
                // Массив с новостями
                $doc['foreach'] = $this->photo->get_comments($doc['photo_data']['id'], $config['per_page'], $this->uri->segment(5));
           
                if ($this->user->check_ignore($doc['photo_data']['id_user']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'photo')));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_photo'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('photo/error_view_friends', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_photo'] == 2))
                {
                    $this->template->page('photo/access_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if ($antiflood_time = $this->photo->antiflood_time())
                            {
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                            }
                            
                            if (empty($doc['error']))
                            {
                                if ($this->photo->add_comments(array('id_photo' => $doc['photo_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id())))
                                {
                                    if ($this->user->id() != $doc['photo_data']['id_user'])
                                    {
                                         $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['photo_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], оставил новый комментарий к вашему [url=' . base_url() . 'index.php/photo/comments/' . $doc['photo_data']['id'] . ']фото[/url].', 'time' => now(), 'read' => '1'));
                                    }
                                    $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                                    $this->user->balls($doc['config']['balls_comments']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                    }
                    
                    
                    $this->template->page('photo/comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
            } 
            else
            {
                $this->template->page('photo/error_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }   
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаляем комментарий
    public function delete_comments($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
        
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($post_data = $this->photo->get_comments_id($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
            }
            
            if (is_array($doc['post_data']) AND $photo_data = $this->photo->check_photo($doc['post_data']['id_photo']))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
            }
            
            
            if (is_array($doc['photo_data']) AND is_array($doc['post_data']))
            {
                
                if ($this->user->id() === $doc['photo_data']['id_user'])
                {
                    if ($this->photo->delete_comments_id($doc['post_data']['id']))
                    {
                        $this->session->set_userdata(array('notice' => 'Комментарий успешно удален.'));
                        redirect('photo/comments/' . $doc['photo_data']['id']);
                        exit();
                    }
                    else
                    {
                        redirect('photo/comments/' . $doc['photo_data']['id']);
                        exit();
                    }
                }
                else
                {
                    show_404();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Ответ на комментарий
    public function reply_comments($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1024', 'class' => 'form');
        
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($post_data = $this->photo->get_comments_id($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                $doc['post_data'] = '';
                show_404();
            }
            
            if (is_array($doc['post_data']) AND $photo_data = $this->photo->check_photo($doc['post_data']['id_photo']))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
                show_404();
            }
            
            if (is_array($doc['photo_data']) AND $user_data = $this->user->parse_id($doc['photo_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            
            
            if (is_array($doc['photo_data']) AND is_array($doc['post_data']) AND is_array($doc['user_data']))
            {
                
                $config['base_url'] =  base_url() . 'index.php/photo/comments/' . $doc['photo_data']['id'] . '/pages/';
                $config['total_rows'] = $this->photo->count_all_comments_id($doc['photo_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
    
                // Инициализация
                $this->pagination->initialize($config);
                
                // Массив с новостями
                $doc['foreach'] = $this->photo->get_comments($doc['photo_data']['id'], $config['per_page'], $this->uri->segment(5));
        
                if ($this->user->check_ignore($doc['photo_data']['id_user']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'photo')));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_photo'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('photo/error_view_friends', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['comment_photo'] == 2))
                {
                    $this->template->page('photo/access_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
                elseif ($this->user->id() == $doc['post_data']['id_user'])
                {
                    $this->template->page('album/error_reply_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
                else
                {
                    if ($this->input->post('submit') AND $doc['config']['access'] === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if ($antiflood_time = $this->photo->antiflood_time())
                            {
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                            }
                            
                            if (empty($doc['error']))
                            {
                                if ($this->photo->add_comments(array('id_photo' => $doc['photo_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id(), 'id_reply' => $doc['post_data']['id_user'])))
                                {
                                    if ($this->user->id() != $doc['post_data']['id_user'])
                                    {
                                         $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['post_data']['id_user'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], дал ответ на ваш [url=' . base_url() . 'index.php/photo/comments/' . $doc['photo_data']['id'] . ']комментарий[/url].', 'time' => now(), 'read' => '1'));
                                    }
                                    $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                                    $this->user->balls($doc['config']['balls_comments']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect('photo/comments/' . $doc['photo_data']['id']);
                                    exit();
                                }
                            }
                        }
                    }
                    $this->template->page('photo/reply_comments', $this->doc->by_default(array('title' => 'Комментарии', 'page' => 'photo'), $doc));
                }
            }
            else
            {
                 $this->template->page('photo/error_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Просмотр фото
    public function gender()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $this->template->page('photo/gender', $this->doc->by_default(array('title' => 'Фото пользователей', 'page' => 'photo'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Фото парней
    public function boy()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/photo/boy/pages/';
            $config['total_rows'] = $this->photo->count_all_photo_moder('m');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->photo->get_photo_boy($config['per_page'], $this->uri->segment(4));
            $this->template->page('photo/boy', $this->doc->by_default(array('title' => 'Фото пользователей', 'page' => 'photo'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function girl()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/photo/girl/pages/';
            $config['total_rows'] = $this->photo->count_all_photo_moder('w');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->photo->get_photo_girl($config['per_page'], $this->uri->segment(4));
            $this->template->page('photo/girl', $this->doc->by_default(array('title' => 'Фото пользователей', 'page' => 'photo'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function chart()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/photo/chart/pages/';
            $config['total_rows'] = $this->photo->count_all_photo();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->photo->get_photo_chart($config['per_page'], $this->uri->segment(4));
            $this->template->page('photo/chart', $this->doc->by_default(array('title' => 'Фото пользователей | Популярные', 'page' => 'photo'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    // Модерация фото
    public function moderations()
    {
        if ($this->user->is_admin(array(3, 10)))
        {
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('id', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id = $this->function->abs($this->input->post('id'));
                    
                    if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
                        $doc['error'][] = 'ID фото указан некорректно.';
                    
                    if ($photo_data = $this->photo->check_photo($id))
                    {
                        $doc['photo_data'] = $photo_data;
                        if ($this->photo->update_photo($doc['photo_data']['id'], array('moder' => '0')))
                        {
                            $this->session->set_userdata(array('notice' => 'Фото успешно промодерировано.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Фото не найдено.';
                    }
                }
            }
            
            if ($this->input->post('delete'))
            {
                $this->form_validation->set_rules('id', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id = $this->function->abs($this->input->post('id'));
                    
                    if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
                        $doc['error'][] = 'ID фото указан некорректно.';
                    
                    if ($photo_data = $this->photo->check_photo($id))
                    {
                        $doc['photo_data'] = $photo_data;
                        if ($this->photo->delete_photo($doc['photo_data']['id']))
                        {
                            // Удаляем старые аватары
                            @unlink(APPPATH . '../files/photos/' . $doc['photo_data']['id_user'] . '/' . $doc['photo_data']['hash_file'] . '.png');
                            @unlink(APPPATH . '../files/photos/' . $doc['photo_data']['id_user'] . '/thumbs/' . $doc['photo_data']['hash_file'] . '_thumb.png');
                            $this->session->set_userdata(array('notice' => 'Фото успешно удалено.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Фото не найдено.';
                    }
                }
            }
            $config['base_url'] =  base_url() . 'index.php/photo/moderations/pages/';
            $config['total_rows'] = $this->photo->count_all_photo_moderations();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->photo->get_photo_moderations($config['per_page'], $this->uri->segment(4));
        
            $this->template->page('photo/moderations', $this->doc->by_default(array('title' => 'Модерация фото', 'page' => 'photo'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем фото
    public function edit_photo($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
                
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
                     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($photo_data = $this->photo->check_photo($id))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
                show_404();
            }
            
            if (is_array($doc['photo_data']) AND $user_data =$this->user->parse_id($doc['photo_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
                show_404();
            }
            
            if ($this->user->id() != $doc['user_data']['id'])
            {
                show_404();
            }
            
            if (is_array($doc['photo_data']) AND is_array($doc['user_data']))
            {
                $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['photo_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['photo_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
       
                if ($this->input->post('submit') AND $doc['config']['access'] === FALSE) {
                
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                if ($this->input->post('description'))
                {
                    $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                }
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        if ($this->photo->update_photo($doc['photo_data']['id'], array('title' => $title, 'description' => $description)))
                        {
                            $this->session->set_userdata(array('notice' => 'Фото успешно отредактировано.'));
                            redirect('photo/index/' . $this->user->id());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('photo/edit_photo', $this->doc->by_default(array('title' => 'Редактируем фото', 'page' => 'photo'), $doc));
            $this->session->unset_userdata('notice');
            }
            else
            {
                $this->template->page('photo/error_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление фото
    public function delete_photo($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
                
            $doc['config'] = $this->photo->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
                     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($photo_data = $this->photo->check_photo($id))
            {
                $doc['photo_data'] = $photo_data;
            }
            else
            {
                $doc['photo_data'] = '';
            }
            
            if (is_array($doc['photo_data']) AND $user_data =$this->user->parse_id($doc['photo_data']['id_user']))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            if ($this->user->id() != $doc['user_data']['id'])
            {
                show_404();
            }
            
            if (is_array($doc['photo_data']) AND is_array($doc['user_data']))
            {
                if ($this->photo->delete_photo($doc['photo_data']['id']))
                {
                    // Удаляем старые аватары
                    @unlink(APPPATH . '../files/photos/' . $doc['photo_data']['id_user'] . '/' . $doc['photo_data']['hash_file'] . '.png');
                    @unlink(APPPATH . '../files/photos/' . $doc['photo_data']['id_user'] . '/thumbs/' . $doc['photo_data']['hash_file'] . '_thumb.png');
                    $this->session->set_userdata(array('notice' => 'Фото успешно удалено.'));
                    redirect('photo/index/' . $this->user->id());
                    exit();
                }
            }
            else
            {
                $this->template->page('photo/error_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'photo')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}