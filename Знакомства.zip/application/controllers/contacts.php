<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Модуль приватной почты

class Contacts extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_contacts', 'contact', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
        //$this->output->enable_profiler(TRUE); 
    }
    
    // Главная страница с контактами
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/contacts/index/pages/';
            $config['total_rows'] = $this->contact->count_all_contacts($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                
            $this->pagination->initialize($config);
                
            $doc['foreach'] = $this->contact->get_contacts($this->user->id(), $config['per_page'], $this->uri->segment(4));
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('id_to', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $id_to = $this->function->abs($this->input->post('id_to'));
                    if ($this->contact->check_contacs_list_id_user($id_to))
                    {
                        if ($this->contact->delete_contcats($id_to))
                        {
                            $this->session->set_userdata(array('notice' => 'Пользователь успешно удален из списка ваших контактов.'));
                            $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $id_to, 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], удалил(а) вас из списка своих контактов.', 'time' => now(), 'read' => '1'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Пользователь не найден в списке ваших контактов.';
                    }
                }
            }
            
            $this->template->page('contacts/main', $this->doc->by_default(array('title' => 'Контакты и почта', 'page' => 'contacts'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Отображаем диалог пользователя
    public function messages($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            $doc['user_data'] = '';
            
            $doc['config'] = $this->contact->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1000', 'class' => 'form');
            // Ролучаем и обрабатываем ID пользователя
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            // Ищем пользователя в бд и вертаем массив с его данными
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                // Если нихрена не найдено то возращаем пустой массив
                $doc['user_data'] = '';
            }
            // Если в массиве есть данные идем далее
            if (is_array($doc['user_data']))
            {
                // Читаем сообщения
                $this->contact->read_messages($doc['user_data']['id']);
                
                $config['base_url'] =  base_url() . 'index.php/contacts/messages/' . $doc['user_data']['id'] . '/pages/';
                $config['total_rows'] = $this->contact->count_all_messages_id($doc['user_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
                
                $this->pagination->initialize($config);
                
                $doc['foreach'] = $this->contact->get_messages($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
     
                // Если пользователь в черном списке, то напоминаем ему об етом
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'contacts'), $doc));
                }
                // Если доступ к почте только друзям
                elseif ($doc['user_data']['sent_msg'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE)
                {
                    $this->template->page('contacts/error_sent_msg', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts'), $doc));
                }
                // Если доступ к почте закрытый
                elseif ($doc['user_data']['sent_msg'] == 2)
                {
                    $this->template->page('contacts/access_sent_msg', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts'), $doc));
                }
                // Елси в списке игнора
                elseif ($this->contact->check_ignored($doc['user_data']['id']))
                {
                    $this->template->page('contacts/ignored', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts'), $doc));
                }
                else
                {
                    // Добавляем в список контактов если надо
                    if ($this->contact->check_contacs_list_id_user($doc['user_data']['id']) === FALSE)
                    {
                        $this->contact->add_contacts_id_user($doc['user_data']['id']);
                    }
                    
                    if ($this->input->post('submit') AND $this->contact->quarantine_time() === FALSE)
                    {
                        $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[1]|max_length[1000]');
                        if ($this->form_validation->run())
                        {
                            $description = $this->function->variables($this->input->post('description'));
                            
                            if ($antiflood_time = $this->contact->antiflood_time())
                            {
                                $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                            }
                            
                            if (empty($doc['error']))
                            {
                                // Отправка сообщения
                                if ($this->contact->check_contacs_list_id_to($doc['user_data']['id']) === FALSE)
                                {
                                    $this->contact->add_contacts_id_to($doc['user_data']['id']);
                                }
                                if ($this->contact->sent_messages($doc['user_data']['id'], $description))
                                {
                                    $this->session->set_userdata(array('notice' => 'Сообщение успешно отправлено.'));
                                    $this->user->balls($doc['config']['balls']);
                                    $this->user->update(array('date_last_post' => now()));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                    }
                    
                    $this->template->page('contacts/messages', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts'), $doc));
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'contacts')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Очистка сообщений
    public function trunce_messages($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            $doc['user_data'] = '';
            // Ролучаем и обрабатываем ID пользователя
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            // Ищем пользователя в бд и вертаем массив с его данными
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                // Если нихрена не найдено то возращаем пустой массив
                $doc['user_data'] = '';
            }
            
            if (is_array($doc['user_data']))
            {
                if ($this->contact->check_contacs_list_id_user($doc['user_data']['id']))
                {
                    if ($this->contact->trunce_messages($doc['user_data']['id']))
                    {
                        $this->session->set_userdata(array('notice' => 'Переписка с пользователем успешно очищена.'));
                        $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], очистил вашу с ним историю переписки.', 'time' => now(), 'read' => '1'));
                        redirect(base_url() . 'index.php/contacts/messages/' . $doc['user_data']['id']);
                        exit();
                    }
                }
                else
                {
                    redirect(base_url());
                    exit();
                }
            }
            else
            {
                redirect(base_url());
                exit();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Новые сообщения
    public function new_messages()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/contacts/new_messages/pages/';
            $config['total_rows'] = $this->contact->count_all_new_contacts($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                
            $this->pagination->initialize($config);
                
            $doc['foreach'] = $this->contact->get_new_messages($this->user->id(), $config['per_page'], $this->uri->segment(4));
     
            $this->template->page('contacts/new_messages', $this->doc->by_default(array('title' => 'Новые сообщения', 'page' => 'contacts'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавление в игнор
    public function add_ignored($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            $doc['user_data'] = '';
            // Ролучаем и обрабатываем ID пользователя
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            // Ищем пользователя в бд и вертаем массив с его данными
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                // Если нихрена не найдено то возращаем пустой массив
                $doc['user_data'] = '';
            }
            
            if (is_array($doc['user_data']))
            {
                // Добавляем в список контактов если надо
                if ($this->contact->check_contacs_list_id_user($doc['user_data']['id']) === FALSE)
                {
                    $this->contact->add_contacts_id_user($doc['user_data']['id']);
                }
                
                if ($this->contact->add_ignored($doc['user_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Пользователь успешно добавлен в список игнора.'));
                    $this->profile->add_journal(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'description' => '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], добавил вас в список игнора.', 'time' => now(), 'read' => '1'));
                    redirect(base_url() . 'index.php/contacts/messages/' . $doc['user_data']['id']);
                    exit();
                }
                else
                {
                    redirect('contacts/index');
                    exit();
                }
            }
            else
            {
                redirect('contacts/index');
                    exit();
            }        
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем в список контактов
    public function add_contacted($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            $doc['user_data'] = '';
            // Ролучаем и обрабатываем ID пользователя
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0 OR $id == $this->user->id())
            {
                show_404();
            }
            // Ищем пользователя в бд и вертаем массив с его данными
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                // Если нихрена не найдено то возращаем пустой массив
                $doc['user_data'] = '';
            }
            
            if (is_array($doc['user_data']))
            {
                // Добавляем в список контактов если надо
                if ($this->contact->check_contacs_list_id_user($doc['user_data']['id']) === FALSE)
                {
                    $this->contact->add_contacts_id_user($doc['user_data']['id']);
                }
                
                if ($this->contact->add_contacted($doc['user_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Пользователь успешно добавлен в список контактов.'));
                    redirect(base_url() . 'index.php/contacts/messages/' . $doc['user_data']['id']);
                    exit();
                }
                else
                {
                    redirect('contacts/index');
                    exit();
                }
            }
            else
            {
                redirect('contacts/index');
                    exit();
            }        
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Подаем на спам
    public function add_spam($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            $doc['user_data'] = '';
            // Ролучаем и обрабатываем ID пользователя
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1000', 'style' => 'width:99%', 'class' => 'form');
            $doc['type_spam'] = array('1' => 'СПАМ, Реклама', '2' => 'Нецензурная лексика', '3' => 'Грубость и оскорбления', '4' => 'Педофилия');
            
            if ($messages_data = $this->contact->check_messages($id))
            {
                $doc['messages_data'] = $messages_data;
            }
            else
            {
                $doc['messages_data'] = '';
            }
            
            if (is_array($doc['messages_data']))
            {
                if ($this->input->post('submit'))
                {
                     $this->form_validation->set_rules('description', 'Сообщение', 'required|xss_clean|min_length[10]|max_length[1000]');
                     $this->form_validation->set_rules('type_spam', 'Причина жалобы', 'required|xss_clean|exact_length[1]|numeric');
                     if ($this->form_validation->run())
                     {
                        $type_spam = $this->function->abs($this->input->post('type_spam'));
                        $description = $this->function->variables($this->input->post('description'));
                        
                        if ($type_spam != 1 AND $type_spam != 2 AND $type_spam != 3 AND $type_spam != 4)
                            $doc['error'][] = 'Режим "Причина жалобы" указан некорректно.';
                        
                        if (empty($doc['error']))
                        {
                            if ($this->profile->add_spam(array('id_user' => $this->user->id(), 'id_to' => $doc['messages_data']['id_user'], 'spam' => $this->function->variables($doc['messages_data']['description']), 'type' =>$type_spam, 'description' => $description, 'time' => now(), 'read' => '1')))
                            {
                                $this->session->set_userdata(array('notice' => 'Жалоба успешно отправлена Администратору.'));
                                redirect(base_url() . 'index.php/contacts/messages/' . $doc['messages_data']['id_user']);
                                exit();
                            }
                        }
                     }
                }
                
                $this->template->page('contacts/spam_messages', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts'), $doc));
            }
            else
            {
                $this->template->page('contacts/error_messages', $this->doc->by_default(array('title' => 'Переписка', 'page' => 'contacts')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}