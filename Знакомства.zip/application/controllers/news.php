<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_news', 'news', FALSE);
    }
    
    // Главная страница новостей
    public function index()
    {
        if ($this->user->is_user())
        {
            // Загружаем конфиг модуля новостей
            $doc['config'] = $this->news->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            // Пространичная навигация
            $config['base_url'] =  base_url() . 'index.php/news/index/pages/';
            $config['total_rows'] = $this->db->count_all('news');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            // Инициализация
            $this->pagination->initialize($config);
            
            // Массив с новостями
            $doc['foreach'] = $this->news->get_news($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('news/main', $this->doc->by_default(array('title' => 'Новости', 'page' => 'news'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
             $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем новость
    public function add_news()
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '3000', 'class' => 'form');
            $doc['access'] = array('name' => 'access', 'value' => 1, 'checked' => TRUE);
            $doc['error'] = array();
            
            // Принимаем данные из формы
            if ($this->input->post('submit'))
            {
                // Правила валидации форм
                $this->form_validation->set_rules('title', 'Заголовок', 'required|xss_clean|min_length[10]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    $access = $this->function->variables($this->input->post('access'));
                    
                    // Проверяем нет ли ошибок
                    if ($access != 1 AND $access != 0) 
                        $doc['error'][] = 'Режим комментирования указан некорректно.';
                        
                    // Вставка в БД
                    if (empty($doc['error']))
                    {
                        if ($this->news->add_news(array('title' => $title, 'description' => $description, 'time' => now(), 'access' => $access, 'id_admin' => $this->user->id())))
                        {
                            $this->session->set_userdata(array('notice' => 'Новость успешно добавлена.'));
                            redirect('news/index');
                            exit();
                        }
                    }
                }
            }
                      
            $this->template->page('news/add_news', $this->doc->by_default(array('title' => 'Новости', 'page' => 'news'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Просмотр новости
    public function comments($id = '')
    {
        if ($this->user->is_user())
        {
            // Загружаем конфиг модуля новостей
            $doc['config'] = $this->news->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '3000', 'class' => 'form');
            
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($id))
            {
                $doc['news_data'] = $news_data;
            }
            else
            {
                show_404();
            }
            
            // Пространичная навигация
            $config['base_url'] =  base_url() . 'index.php/news/comments/' . $doc['news_data']['id'] . '/pages/';
            $config['total_rows'] = $this->news->count_all_comments_id($doc['news_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            // Инициализация
            $this->pagination->initialize($config);
            
            // Массив с новостями
            $doc['foreach'] = $this->news->get_comments($doc['news_data']['id'], $config['per_page'], $this->uri->segment(5));
            
            // Принимаем данные из формы
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $doc['news_data']['access'] == 1 AND $this->news->quarantine_time() === FALSE)
            {
                // Правила валидации форм
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $description = $this->function->variables($this->input->post('description'));
                    
                    // Проверка на флуд
                    if ($antiflood_time = $this->news->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }
                    
                    // Добавляем коммент в БД
                    if  (empty($doc['error']))
                    {
                        if ($this->news->add_comments(array('id_news' => $doc['news_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id())))
                        {
                            $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                            $this->user->balls($doc['config']['balls']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('news/comments', $this->doc->by_default(array('title' => 'Новости | Комментарии', 'page' => 'news'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление комментария
    public function delete_comments($id = 0)
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($data = $this->news->get_comments_id($id))
            {
                if ($this->news->delete_comments_id($data['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Комментарий успешно удален.'));
                    redirect('news/comments/' . $data['id_news']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем комментарий
    public function edit_comments($id = 0)
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            // Получаем ID комментария
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($data = $this->news->get_comments_id($id))
            {
                $doc['comments_data'] = $data;
            }
            else
            {
                show_404();
            }
            
            // Загружаем конфиг модуля новостей
            $doc['config'] = $this->news->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['comments_data']['description'], 'maxlength' => '3000', 'class' => 'form');
            
            // Принимаем данные из формы
            if ($this->input->post('submit'))
            {
                // Правила валидации форм
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($this->news->update_comments_id($doc['comments_data']['id'], array('description' => $description, 'edit_who' => $this->user->login(), 'edit_time' => now(), 'edit_count' => $doc['comments_data']['edit_count'] + 1)))
                    {
                        $this->session->set_userdata(array('notice' => 'Комментарий успешно отредактирован.'));
                        redirect('news/comments/' . $doc['comments_data']['id_news']);
                        exit();
                    }
                }
            }
            $this->template->page('news/edit_comments', $this->doc->by_default(array('title' => 'Новости | Комментарии', 'page' => 'news'), $doc));
            
        }
        else
        {
            show_404();
        }
    }
    
    // Голосуем за новость
    public function vote_news($id = '', $vote = 'plus')
    {
        if ($this->user->is_user())
        {
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($vote === '' OR $vote === FALSE OR $vote === NULL)
            {
                show_404();
            }
            
            if ($vote != 'plus' AND $vote != 'minus')
            {
                show_404();
            }

            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($id))
            {
                $doc['news_data'] = $news_data;
            }
            else
            {
                show_404();
            }
            
            if ($vote == 'plus')
            {
                $rating = $doc['news_data']['rating'] + 1;
            }
            elseif ($vote == 'minus')
            {
                $rating = $doc['news_data']['rating'] - 1;
            }
            
            if ($this->news->check_vote_news($doc['news_data']['id']) === FALSE)
            {
                if ($this->news->vote_news_id($doc['news_data']['id']))
                {
                    $this->news->update_news($doc['news_data']['id'], array('rating' => $rating));
                    $this->session->set_userdata(array('notice' => 'Ваш голос успешно принят.'));
                    redirect('news/comments/' . $doc['news_data']['id']);
                    exit();
                }
                else
                {
                    redirect('news/comments/' . $doc['news_data']['id']);
                }
            }
            else
            {
                redirect('news/comments/' . $doc['news_data']['id']);
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Страница с ответом
    public function reply_comments($id = '')
    {
        if ($this->user->is_user())
        {
            // Получаем ID комментария
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($data = $this->news->get_comments_id($id))
            {
                $doc['comments_data'] = $data;
            }
            else
            {
                show_404();
            }
            
            if ($this->user->id() == $doc['comments_data']['id_user'])
            {
                show_404();
            }
            
            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($doc['comments_data']['id_news']))
            {
                $doc['news_data'] = $news_data;
            }
            
            // Загружаем конфиг модуля новостей
            $doc['config'] = $this->news->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : '', 'maxlength' => '3000', 'class' => 'form');
            
            // Принимаем данные из формы
            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $doc['news_data']['access'] == 1 AND $this->news->quarantine_time() === FALSE)
            {
                // Правила валидации форм
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[3]|max_length[1024]');
                
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $description = $this->function->variables($this->input->post('description'));
                    
                    // Проверка на флуд
                    if ($antiflood_time = $this->news->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }
                    
                    // Отправка комментария
                    if (empty($doc['error']))
                    {
                        if ($this->news->add_comments(array('id_news' => $doc['news_data']['id'], 'description' => $description, 'time' => now(), 'id_user' => $this->user->id(), 'id_reply' => $doc['comments_data']['id_user'])))
                        {
                            $this->user->update(array('date_last_post' => now()));
                            $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                            redirect('news/comments/' . $doc['comments_data']['id_news']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('news/reply_comments', $this->doc->by_default(array('title' => 'Новости | Комментарии', 'page' => 'news'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактирование новости
    public function edit_news($id = '')
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($id))
            {
                $doc['news_data'] = $news_data;
            }
            else
            {
                show_404();
            }
            
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['news_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['news_data']['description'], 'maxlength' => '3000', 'class' => 'form');
            $doc['access'] = array('name' => 'access', 'value' => 1, 'checked' => $doc['news_data']['access']);
            $doc['error'] = array();
            
            // Принимаем данные из формы
            if ($this->input->post('submit'))
            {
                // Правила валидации форм
                $this->form_validation->set_rules('title', 'Заголовок', 'required|xss_clean|min_length[10]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    $access = $this->function->variables($this->input->post('access'));
                    
                    // Проверяем нет ли ошибок
                    if ($access != 1 AND $access != 0) 
                        $doc['error'][] = 'Режим комментирования указан некорректно.';
                        
                    // Вставка в БД
                    if (empty($doc['error']))
                    {
                        if ($this->news->update_news($doc['news_data']['id'], array('title' => $title, 'description' => $description, 'time' => now(), 'access' => $access, 'id_admin' => $this->user->id(), 'edit_who' => $this->user->login(), 'edit_time' => now(), 'edit_count' => $doc['news_data']['edit_count'] + 1)))
                        {
                            $this->session->set_userdata(array('notice' => 'Новость успешно отредактирована.'));
                            redirect('news/comments/' . $doc['news_data']['id']);
                            exit();
                        }
                    }
                }
            }
                      
            $this->template->page('news/edit_news', $this->doc->by_default(array('title' => 'Новости', 'page' => 'news'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Очистка комментариев 
    public function trunce($id = '')
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($id))
            {
                $doc['news_data'] = $news_data;
            }
            else
            {
                show_404();
            }
            // Очистка комментариев
            if ($this->news->trunce($doc['news_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Комментарии успешно очищены.'));
                redirect('news/comments/' . $doc['news_data']['id']);
                exit();
            }
            else
            {
                redirect('news/comments/' . $doc['news_data']['id']);
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Удаление новости
    public function delete_news($id = '')
    {
        // Уровень доступа (level=10)
        if ($this->user->is_admin(array(10)))
        {
            // Получаем ID новости
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            // Проверим есть ли данная новость в БД и вернем массив с данными, если нет выдаем ошибку 404
            if ($news_data = $this->news->check_news($id))
            {
                $doc['news_data'] = $news_data;
            }
            else
            {
                show_404();
            }
            // Очистка комментариев
            if ($this->news->delete_news($doc['news_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Новость и все данные успешно удалены.'));
                redirect('news/index');
                exit();
            }
            else
            {
                redirect('news/index');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
}