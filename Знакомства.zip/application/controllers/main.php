<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_news', 'news', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    // Главная страница
    public function index($web = '')
    {           
        
        if ( ! $this->user->is_user())
        {
            if ($this->session->userdata('web_style') AND $web === '')
                $web = $this->session->userdata('web_style');
                
            if ($web != 'web' AND $web != 'default')
            {
                $this->session->set_userdata(array('web_style' => 'default'));
            }
            else
            {
                $this->session->set_userdata(array('web_style' => $web));
            }
        }

        //$this->user->out();
        $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
        $doc['login'] = array('name' => 'login', 'value' => $this->function->htmlspecialchars($this->input->post('login')), 'maxlength' => '20', 'class' => 'form');
        $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'class' => 'form');
        $doc['error'] = array();
            
        $doc['foreach'] = $this->profile->get_users_main();
            
        // Принимаем данные из формы
        if ($this->input->post('submit'))
        {
            // Правила валидации форм
            $this->form_validation->set_rules('login', 'Логин', 'required|xss_clean|min_length[2]|max_length[20]|alpha_dash');
            $this->form_validation->set_rules('password', 'Пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
            
            // Инициализация валидации  
            if ($this->form_validation->run())
            {
                // Принимаем переменные
                $login = $this->input->post('login');
                $password = $this->input->post('password');
                
                // Проверяем есть ли пользователь в БД
                if ($array = $this->user->check_login(array('login' => $login, 'password' => $this->encrypt->sha1($this->encrypt->sha1($password)))))
                {
                    $newdata = array('uid' => $this->function->abs($array['id']), 'ups' => $array['password']);
                    $this->session->set_userdata($newdata);
                    $cuid = array('name' => 'cuid', 'value'  => $this->encrypt->encode($array['id']), 'expire' => now() + 3600 * 24 * 365);
                    $cups = array('name' => 'cups', 'value'  => $this->encrypt->sha1($password), 'expire' => now() + 3600 * 24 * 365);
                    $this->input->set_cookie($cuid);
                    $this->input->set_cookie($cups);
                    redirect(current_url());
                    exit();
                }
                else $doc['error'] = 'Неправильный Логин или Пароль.';
            }
        }
        
        if ($this->user->is_user())
        {
            redirect(base_url() . 'index.php/page/main');
            exit();
        }
        else
        {
            $this->template->page('pages/main', $this->doc->by_default(array('page' => 'main'), $doc));
        }
        $this->session->unset_userdata('notice');
        
    }
}