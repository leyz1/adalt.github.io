<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shopping extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_shopping', 'shop', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
    }
    
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/shopping/index/pages/';
            $config['total_rows'] = $this->db->count_all('shopping');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->shop->get_shopping($config['per_page'], $this->uri->segment(4));
  
            $this->template->page('shopping/main', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Новая катнгория
    public function add_catalog()
    {
        if ($this->user->is_admin(array(10)))
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                if ($this->input->post('description'))
                {
                    $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                }
                
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        if ($this->shop->add_catalog(array('title' => $title, 'description' => $description)))
                        {
                            $this->session->set_userdata(array('notice' => 'Категория успешно добавлена.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('shopping/add_catalog', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем каталог
    public function edit_catalog($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($id))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['catalog_data']))
            {
                $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['catalog_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['catalog_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                    if ($this->input->post('description'))
                    {
                        $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                    }
                    
                    if ($this->form_validation->run())
                    {
                        $title = $this->function->variables($this->input->post('title'));
                        $description = $this->function->variables($this->input->post('description'));
                        
                        if (empty($doc['error']))
                        {
                            if ($this->shop->edit_shopping($doc['catalog_data']['id'], array('title' => $title, 'description' => $description)))
                            {
                                $this->session->set_userdata(array('notice' => 'Категория успешно отредактирована.'));
                                redirect(current_url());
                                exit();
                            }
                        }
                    }
                }
                $this->template->page('shopping/edit_catalog', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Просмотр каталога
    public function catalog($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($id))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['catalog_data']))
            {
                $config['base_url'] =  base_url() . 'index.php/shopping/catalog/' . $doc['catalog_data']['id'] . '/pages/';
                $config['total_rows'] = $this->shop->count_all_shopping_id($doc['catalog_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
                    
                $this->pagination->initialize($config);
                $doc['foreach'] = $this->shop->get_shopping_gift($doc['catalog_data']['id'], $config['per_page'], $this->uri->segment(5));
            
                $this->template->page('shopping/catalog', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Популярные покупки
    public function chart()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
             $config['base_url'] =  base_url() . 'index.php/shopping/chart/pages/';
             $config['total_rows'] = $this->shop->count_all_shopping_chart();
             $config['per_page'] = $this->user->per_page();
             $config['full_tag_open'] = '<div class="page">';
             $config['full_tag_close'] = '</div>';
             $config['uri_segment'] = 4;
             $config['num_links'] = 2;
             $config['first_link'] = '&laquo; В начало';
             $config['next_link'] = 'Далее';
             $config['prev_link'] = 'Назад';
             $config['last_link'] = 'В конец &raquo;';
                    
             $this->pagination->initialize($config);
             $doc['foreach'] = $this->shop->get_shopping_chart($config['per_page'], $this->uri->segment(4));
            
            
            $this->template->page('shopping/chart', $this->doc->by_default(array('title' => 'Популярные покупки', 'page' => 'shopping'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Новые подарки
    public function new_gift()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/shopping/new_gift/pages/';
            $config['total_rows'] = $this->shop->count_all_shopping_chart();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->shop->get_shopping_new($config['per_page'], $this->uri->segment(4));
            
            
            $this->template->page('shopping/new_gift', $this->doc->by_default(array('title' => 'Новые добавления', 'page' => 'shopping'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем подарок
    public function add_gift($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['balls'] = array('name' => 'balls', 'value' => $this->function->htmlspecialchars($this->input->post('balls')), 'maxlength' => '11', 'class' => 'form');
            $doc['gift'] = array('name' => 'gift');
        
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($id))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['catalog_data']))
            {
                if ( ! is_dir(APPPATH . './../files/gifts/' . $doc['catalog_data']['id'] . '/'))
                {
                    @mkdir(APPPATH . '../files/gifts/' . $doc['catalog_data']['id'] . '/', 0777);
                }
                
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                    if ($this->input->post('description'))
                    {
                        $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                    }
                    $this->form_validation->set_rules('balls', 'Цена', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                    if ($this->form_validation->run())
                    {
                        $title = $this->function->variables($this->input->post('title'));
                        $description = $this->function->variables($this->input->post('description'));
                        $balls = $this->function->abs($this->input->post('balls'));
                        
                        if ($balls == 0)
                            $doc['error'][] = 'Цена должна быть выше чем 0 (ноль).';
                        
                        if (empty($doc['error']))
                        {
                            // Генерация нового хеша для аватара
                            $hash_photo = random_string('unique');
                            
                            $config['upload_path'] = './files/gifts/' . $doc['catalog_data']['id'] . '/';
                            $config['allowed_types'] = 'gif|jpg|png';
                            $config['max_size']	= '500';
                            $config['max_width']  = '320';
                            $config['max_height']  = '240';
                            $config['remove_spaces'] = TRUE;
                            $config['overwrite'] = TRUE;
                            $config['file_name'] = $hash_photo . '.png';
                            $this->load->library('upload', $config);
                            
                            if ( ! $this->upload->do_upload('gift')) 
                            {
                                $doc['error'][] = $this->upload->display_errors();
                    		} 
                            elseif (empty($doc['error']))
                            {
                                if ($this->shop->add_gift(array('id_catalog' => $doc['catalog_data']['id'], 'hash_file' => $hash_photo, 'title' => $title, 'description' => $description, 'balls' => $balls, 'time' => now(), 'shopping' => '0')))
                                {
                                    $this->session->set_userdata(array('notice' => 'Подарок успешно добавлен.'));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                    }
                }
                
                $this->template->page('shopping/add_gift', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем подарок
    public function edit_gift($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($gift_data = $this->shop->check_gift($id))
            {
                $doc['gift_data'] = $gift_data;
            }
            else
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($doc['gift_data']['id_catalog']))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['gift_data']) AND is_array($doc['catalog_data']))
            {
                $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['gift_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['gift_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
                $doc['balls'] = array('name' => 'balls', 'value' => $this->input->post('balls') ? $this->function->htmlspecialchars($this->input->post('balls')) : $doc['gift_data']['balls'], 'maxlength' => '11', 'class' => 'form');
                
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                    if ($this->input->post('description'))
                    {
                        $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                    }
                    $this->form_validation->set_rules('balls', 'Цена', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                    if ($this->form_validation->run())
                    {
                        $title = $this->function->variables($this->input->post('title'));
                        $description = $this->function->variables($this->input->post('description'));
                        $balls = $this->function->abs($this->input->post('balls'));
                        
                        if ($balls == 0)
                            $doc['error'][] = 'Цена должна быть выше чем 0 (ноль).';
                        
                        if (empty($doc['error']))
                        {
                            if ($this->shop->edit_gift($doc['gift_data']['id'], array('title' => $title, 'description' => $description, 'balls' => $balls)))
                            {
                                $this->session->set_userdata(array('notice' => 'Подарок успешно отредактирован.'));
                                redirect(current_url());
                                exit();
                            }
                        }
                    }
                }
                
                $this->template->page('shopping/edit_gift', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Удаление подарка
    public function delete_gift($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($gift_data = $this->shop->check_gift($id))
            {
                $doc['gift_data'] = $gift_data;
            }
            else
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($doc['gift_data']['id_catalog']))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['gift_data']) AND is_array($doc['catalog_data']))
            {
                if ($this->shop->delete_gift($doc['gift_data']['id']))
                {
                    @unlink(APPPATH . '../files/gifts/' . $doc['catalog_data']['id'] . '/' . $doc['gift_data']['hash_file'] . '.png');
                    $this->session->set_userdata(array('notice' => 'Подарок успешно удален.'));
                    redirect('shopping/catalog/' . $doc['catalog_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Полное удаление категории
    public function delete_catalog($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
     
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }

            if ($catalog_data = $this->shop->check_shopping($id))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['catalog_data']))
            {
                if ($this->shop->delete_catalog($doc['catalog_data']['id']))
                {
                    delete_files('./files/gifts/' . $doc['catalog_data']['id'] . '/', TRUE);
                    @rmdir(APPPATH . '../files/gifts/' . $doc['catalog_data']['id'] . '/');
                    $this->session->set_userdata(array('notice' => 'Каталог успешно удален.'));
                    redirect('shopping/');
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    // Покупка подарка
    public function cart($id = '')
    {
        if ($this->user->is_user())
        {
            $this->function->abs($id);
            
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($gift_data = $this->shop->check_gift($id))
            {
                $doc['gift_data'] = $gift_data;
            }
            else
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($doc['gift_data']['id_catalog']))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['gift_data']) AND is_array($doc['catalog_data']))
            {
                if ($this->input->post('submit') AND $this->input->post('id') == $doc['gift_data']['id'])
                {
                    $this->form_validation->set_rules('id', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                    if ($this->form_validation->run())
                    {
                        if ($gift = $this->shop->check_gift($doc['gift_data']['id']))
                        {
                            if ($this->user->total_balls() < $gift['balls'])
                                $doc['error'][] = 'У вас не хватает баллов для покупки подарка.';
                            if (empty($doc['error']))
                            {
                                if ($this->shop->add_cart(array('id_catalog' => $doc['catalog_data']['id'], 'id_gift' => $doc['gift_data']['id'], 'id_user' => $this->user->id(), 'hash_file' => $doc['gift_data']['hash_file'], 'title' => $doc['gift_data']['title'], 'balls' => $doc['gift_data']['balls'], 'time' => $doc['gift_data']['time'])))
                                {
                                    $this->shop->edit_gift($doc['gift_data']['id'], array('shopping' => $doc['gift_data']['shopping'] + 1));
                                    $this->user->minus_balls($doc['gift_data']['balls']);
                                    $this->session->set_userdata(array('notice' => 'Подарок успешно куплен.'));
                                    redirect(current_url());
                                    exit();
                                }
                            }
                        }
                        else
                        {
                            $doc['error'][] = 'Подарок не найден в базе данных.';
                        }
                    }
                }
                
                $this->template->page('shopping/cart', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                $this->session->unset_userdata('notice');
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Мои покупки
    public function present($id = '')
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = '';
            $id = $this->function->abs($id);
            $this->session->unset_userdata('id_to');
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id > 0)
            {
                if ($user_data = $this->user->parse_id($id))
                {
                    $doc['user_data'] = $user_data;
                    
                }
                else
                {
                    $doc['user_data'] = '';
                    $doc['error'][] = 'Пользователь не найден.';
                }
                
                if (is_array($doc['user_data']))
                {
                    if ($this->user->id() == $doc['user_data']['id'])
                        $doc['error'][] = 'Запрещено отправлять себе подарки.';
                    if (empty($doc['error']))
                    {
                        $this->session->set_userdata(array('id_to' => $doc['user_data']['id']));
                    }
                }
            }
            
            if ($this->input->post('delete'))
            {
                $this->form_validation->set_rules('id_present', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                if ($this->form_validation->run())
                {
                    $id_present = $this->function->abs($this->input->post('id_present'));
                    
                    if ($id_present === '' OR $id_present === FALSE OR $id_present === NULL OR $id_present == 0)
                        $doc['error'][] = 'ID покупки указан некорректно.';
                    if (empty($doc['error']))
                    {
                        if ($del = $this->shop->check_present($id_present))
                        {
                            $this->shop->delete_cart($del['id']);
                            $this->session->set_userdata(array('notice' => 'Покупка успешно удалена.'));
                            redirect(current_url());
                            exit();
                        }
                        else
                        {
                            $doc['error'][] = 'Ето не ваша покупка.';
                        }
                    }
                }
            }
            
            $config['base_url'] =  base_url() . 'index.php/shopping/present/' . ($this->session->userdata('id_to') ? $doc['user_data']['id'] . '/' : '') . 'pages/';
            $config['total_rows'] = $this->shop->count_all_cart_id_user($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = ($this->session->userdata('id_to') ? 5 : 4);
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->shop->get_present($this->user->id(), $config['per_page'], $this->uri->segment($this->session->userdata('id_to') ? 5 : 4));
            
            $this->template->page('shopping/present', $this->doc->by_default(array('title' => 'Мои покупки', 'page' => 'shopping'), $doc));
            $this->session->unset_userdata('notice');
            
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Отправка подарка
    public function cart_present($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['present_data'] = '';
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1000', 'class' => 'form');
            $doc['anonymous'] = array('0' => 'Публичный', '1' => 'Приватный', '2' => 'Анонимный');
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            if ($present_data = $this->shop->check_present($id))
            {
                $doc['present_data'] = $present_data;
            }
            else
            {
                show_404();
            }
            
            if ($catalog_data = $this->shop->check_shopping($doc['present_data']['id_catalog']))
            {
                $doc['catalog_data'] = $catalog_data;
            }
            else
            {
                show_404();
            }
            
            if ($this->session->userdata('id_to'))
            {
                $id_to = $this->session->userdata('id_to');
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['present_data']))
            {
                if ($this->user->check_ignore($id_to))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'present')));
                }
                else
                {
                    if ($this->input->post('submit') AND $id_to > 0 AND $this->user->id() != $id_to)
                    {
                        if ($this->input->post('description'))
                        {
                            $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[1000]');
                        }
                        $this->form_validation->set_rules('anonymous', 'Параметры отправки', 'required|xss_clean|exact_length[1]|numeric'); 
              
                        if ($this->form_validation->run())
                        {
                            $id_array = $this->user->parse_id($id_to);
                            
                            $description = $this->function->variables($this->input->post('description'));
                            $anonymous = $this->function->abs($this->input->post('anonymous'));
                            $id_to = $this->function->abs($id_array['id']);

                            if ($anonymous != 0 AND $anonymous != 1 AND $anonymous != 2)
                                $doc['error'][] = 'Параметры отправки указаны некорректно.';
                            if ($this->user->id() == $id_to)
                                $doc['error'][] = 'Запрещено дарить себе подарки.';
                            if ($id_to == 0)
                                $doc['error'][] = 'Получатель указан некорректно.';
                            
                            if (empty($doc['error']))
                            {
                                if ($this->shop->add_present(array('id_catalog' => $doc['catalog_data']['id'], 'id_gift' => $doc['present_data']['id_gift'], 'id_user' => $this->user->id(), 'id_to' => $id_to, 'hash_file' => $doc['present_data']['hash_file'], 'title' => $doc['present_data']['title'], 'description' => $description, 'time' => now(), 'anonymous' => $anonymous)))
                                {
                                    if ($anonymous == 0 OR $anonymous == 1)
                                    {
                                        $msg = '[url=' . base_url() . 'index.php/page/profile/' . $this->user->id() . '][b]' . $this->user->login() . '[/b][/url], сделал вам [url=' . base_url() . 'index.php/page/present/]подарок[/url].';
                                    }
                                    else
                                    {
                                        $msg = '[b]Анонимный пользователь[/b] сделал вам [url=' . base_url() . 'index.php/page/present/]подарок[/url].';
                                    }
                                    
                                    $this->shop->delete_cart($doc['present_data']['id']);
                                    $this->profile->add_journal(array('id_user' => '0', 'id_to' => $id_to, 'description' => $msg, 'time' => now(), 'read' => '1'));
                                    $this->session->set_userdata(array('notice' => 'Подарок успешно отправлен.'));
                                    $this->session->unset_userdata('id_to');
                                    redirect(base_url() . 'index.php/page/profile/' . $id_to);
                                    exit();
                                }
                            }
                        }
                    }
                    
                    $this->template->page('shopping/cart_present', $this->doc->by_default(array('title' => 'Магазин подарков', 'page' => 'shopping'), $doc));
                    $this->session->unset_userdata('notice');
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
}