<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forum extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_forum', 'forum', FALSE);
    }
    
    // Главная страница форума
    public function index()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/forum/index/pages/';
            $config['total_rows'] = $this->db->count_all('forum');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->forum->get_forum($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('forum/main', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('search_forum');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Страница создания форума
    public function add_forum()
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $doc['config'] = $this->forum->config();       
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[255]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if (empty($doc['error']))
                    {
                        if ($this->forum->add_forum(array('title' => $title, 'description' => $description, 'sort' => $this->forum->sort_forum())))
                        {
                            $this->session->set_userdata(array('notice' => 'Форум успешно создан.'));
                            redirect('forum/index');
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/add_forum', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Перемещаем форум на позицию выше
    public function up_forum($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($this->forum->up_forum($doc['forum_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Форум успешно перемещен на позицию выше.'));
                redirect('forum/index');
                exit();
            }
            else
            {
                redirect('forum/index');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Перемещаем форум на позицию ниже
    public function down_forum($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($this->forum->down_forum($doc['forum_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Форум успешно перемещен на позицию ниже.'));
                redirect('forum/index');
                exit();
            }
            else
            {
                redirect('forum/index');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Выводим списрк категорий форума
    public function category($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/forum/category/' . $doc['forum_data']['id'] . '/pages/';
            $config['total_rows'] = $this->forum->count_all_category_id($doc['forum_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->forum->get_category($doc['forum_data']['id'], $config['per_page'], $this->uri->segment(5));
            
            $this->template->page('forum/category', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Добавляем категорию в форуме
    public function add_category($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                
                if ($this->input->post('description'))
                {
                    $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                }

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));

                    if (empty($doc['error']))
                    {
                        if ($this->forum->add_category(array('id_forum' =>  $doc['forum_data']['id'], 'title' => $title, 'description' => $description, 'sort' => $this->forum->sort_category($doc['forum_data']['id']))))
                        {
                            $this->session->set_userdata(array('notice' => 'Категория успешно создана.'));
                            redirect('forum/category/' . $doc['forum_data']['id']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/add_category', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Перемещаем категорию на позицию выше
    public function up_category($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            if ($this->forum->up_category($doc['category_data']))
            {
                $this->session->set_userdata(array('notice' => 'Категория успешно перемещена на позицию выше.'));
                redirect('forum/category/' . $doc['category_data']['id_forum']);
                exit();
            }
            else
            {
                redirect('forum/category/' . $doc['category_data']['id_forum']);
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Перемещаем категорию на позицию ниже
    public function down_category($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            if ($this->forum->down_category($doc['category_data']))
            {
                $this->session->set_userdata(array('notice' => 'Категория успешно перемещена на позицию ниже.'));
                redirect('forum/category/' . $doc['category_data']['id_forum']);
                exit();
            }
            else
            {
                redirect('forum/category/' . $doc['category_data']['id_forum']);
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Отображаем список топиков
    public function topic($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['category_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/forum/topic/' . $doc['category_data']['id'] . '/pages/';
            $config['total_rows'] = $this->forum->count_all_topic_id($doc['category_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_topic($doc['category_data']['id'], $config['per_page'], $this->uri->segment(5));

            $this->template->page('forum/topic', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Новая тема
    public function add_topic($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            
            if ($forum_data = $this->forum->check_forum($doc['category_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->function->htmlspecialchars($this->input->post('title')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '10000', 'style' => 'width:99%', 'class' => 'form');

            if ($this->input->post('submit') AND $doc['config']['access'] === FALSE AND $this->forum->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[10000]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($antiflood_time = $this->forum->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }
                    if ($doc['config']['moder'] == 1)
                    {
                        $moder = 1;
                    }
                    else
                    {
                        $moder = 0;
                    }

                    if (empty($doc['error']))
                    {
                        $topic_data = array('id_forum' => $doc['forum_data']['id'], 'id_category' => $doc['category_data']['id'], 'id_user' => $this->user->id(), 'title' => $title, 'description' =>$description, 'time_create' => now(), 'time' => now(), 'moder' => $moder);
                        if ($this->forum->add_topic($topic_data))
                        {
                            $this->session->set_userdata(array('notice' => 'Новая тема успешно создана.'));
                            $this->user->balls($doc['config']['balls_topic']);
                            redirect('forum/topic/' . $doc['category_data']['id']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/add_topic', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Включена предварительная модерация новых тем
    public function moder()
    {
         $this->template->page('forum/moder', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum')));
    }
    
    // Список тем на модерации
    public function topic_moderation()
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/forum/topic_moderation/pages/';
            $config['total_rows'] = $this->forum->count_all_moder();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_topic_moderation($config['per_page'], $this->uri->segment(4));
  
            $this->template->page('forum/topic_moderation', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Мои темы
    public function my_topic()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/forum/my_topic/pages/';
            $config['total_rows'] = $this->forum->count_all_my_topic($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_my_topic($this->user->id(), $config['per_page'], $this->uri->segment(4));
  
            $this->template->page('forum/my_topic', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Переход в тему
    public function post($id = '', $word = 'word_limiter')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['topic_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            
            if ($word == 'word_limiter')
            {
                $doc['word'] = 'word_limiter';
            }
            elseif ($word == 'word')
            {
                $doc['word'] = 'word';
            }
            else
            {
                $doc['word'] = 'word_limiter';
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '1000', 'style' => 'width:99%', 'class' => 'form');
            
            $config['base_url'] =  base_url() . 'index.php/forum/post/' . $doc['topic_data']['id'] . '/pages/';
            $config['total_rows'] = $this->forum->count_all_post_id($doc['topic_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->forum->get_post($doc['topic_data']['id'], $config['per_page'], $this->uri->segment(5));

            if ($this->input->post('submit') AND $doc['topic_data']['close'] == 0 AND $doc['topic_data']['moder'] == 0 AND $doc['config']['access'] === FALSE AND $this->forum->quarantine_time() === FALSE)
            {
                 $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[10]|max_length[1000]');

                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));

                    if ($antiflood_time = $this->forum->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }

                    if (empty($doc['error']))
                    {
                        $post_data = array('id_forum' => $doc['forum_data']['id'], 'id_category' => $doc['category_data']['id'], 'id_topic' => $doc['topic_data']['id'], 'id_user' => $this->user->id(), 'description' => $description, 'time' => now());
                        if ($this->forum->add_post($post_data))
                        {
                            $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                            $this->forum->edit_topic($doc['topic_data']['id'], array('time' => now()));
                            $this->user->balls($doc['config']['balls_comments']);
                            $this->user->update(array('date_last_post' => now()));
                            $this->forum->up_bookmark($doc['topic_data']['id']);
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }

            if ($this->forum->check_bookmark($doc['topic_data']['id']))
                $this->forum->read_bookmark($doc['topic_data']['id']);

            $this->template->page('forum/post', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление отдельного поста
    public function delete_post($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->forum->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404();
            }
            if ($topic_data = $this->forum->check_topic($doc['post_data']['id_topic']))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                 show_404();
            }
            
            if ($this->forum->delete_post_id($doc['post_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Комментарий успешно удален.'));
                redirect('forum/post/' . $doc['topic_data']['id']);
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Ответ на комментарий
    public function reply_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->forum->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['post_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['post_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if ($topic_data = $this->forum->check_topic($doc['post_data']['id_topic']))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                 show_404();
            }
            if ($this->user->id() == $doc['post_data']['id_user'])
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : '', 'maxlength' => '1000', 'class' => 'form');

            if ($this->input->post('submit') AND $doc['topic_data']['close'] == 0 AND $doc['topic_data']['moder'] == 0 AND $doc['config']['access'] === FALSE AND $this->forum->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[10]|max_length[1000]');

                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));
                    
                    if ($antiflood_time = $this->forum->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }

                    if (empty($doc['error']))
                    {
                        $post_data = array('id_forum' => $doc['forum_data']['id'], 'id_category' => $doc['category_data']['id'], 'id_topic' => $doc['topic_data']['id'], 'id_user' => $this->user->id(), 'id_reply' => $doc['post_data']['id_user'], 'description' => $description, 'time' => now());
                        if ($this->forum->add_post($post_data))
                        {
                            $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                            $this->user->balls($doc['config']['balls_comments']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/reply_post', $this->doc->by_default(array('title' => 'Форум | Комментарии', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function quote_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->forum->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['post_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['post_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if ($topic_data = $this->forum->check_topic($doc['post_data']['id_topic']))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                 show_404();
            }

            if ($this->user->id() == $doc['post_data']['id_user'])
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : '', 'maxlength' => '1000', 'class' => 'form');
            
            if ($this->input->post('submit') AND $doc['topic_data']['close'] == 0 AND $doc['topic_data']['moder'] == 0 AND $doc['config']['access'] === FALSE AND $this->forum->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[10]|max_length[1000]');
 
                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));

                    if ($antiflood_time = $this->forum->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }

                    if (empty($doc['error']))
                    {
                        $post_user = $this->user->parse_id($doc['post_data']['id_user']);
                        $post_data = array('id_forum' => $doc['forum_data']['id'], 'id_category' => $doc['category_data']['id'], 'id_topic' => $doc['topic_data']['id'], 'id_user' => $this->user->id(), 'description' => '[quote][b]' . $post_user['login'] . ',[/b] ' . delete_tags($doc['post_data']['description']) . '[/quote]' . $description, 'time' => now());
                        if ($this->forum->add_post($post_data))
                        {
                            $this->session->set_userdata(array('notice' => 'Комментарий успешно добавлен.'));
                            $this->user->balls($doc['config']['balls_comments']);
                            $this->user->update(array('date_last_post' => now()));
                            redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/quote_post', $this->doc->by_default(array('title' => 'Форум | Комментарии', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактируем пост
    public function edit_post($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($post_data = $this->forum->check_post($id))
            {
                $doc['post_data'] = $post_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['post_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['post_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if ($topic_data = $this->forum->check_topic($doc['post_data']['id_topic']))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                 show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['post_data']['description'], 'maxlength' => '1000', 'class' => 'form');

            if ($this->input->post('submit') AND $doc['topic_data']['close'] == 0 AND $doc['topic_data']['moder'] == 0 AND $doc['config']['access'] === FALSE AND $this->forum->quarantine_time() === FALSE)
            {
                $this->form_validation->set_rules('description', 'Комментарий', 'required|xss_clean|min_length[10]|max_length[1000]');

                if ($this->form_validation->run())
                {
                    $description = $this->function->variables($this->input->post('description'));

                    if ($antiflood_time = $this->forum->antiflood_time())
                    {
                        $doc['error'][] = 'Рабатает Антифлуд. Подождите ' . $antiflood_time . ' сек и повторите отправку сообщения.';
                    }

                    if (empty($doc['error']))
                    {
                        $edit_data = array('description' => $description, 'edit_who' => $this->user->login(), 'edit_time' => now(), 'edit_count' => $doc['post_data']['edit_count'] + 1);
                        if ($this->user->is_admin(array(1, 10)))
                        {
                            $edit_p = TRUE;
                        }
                        elseif ($this->user->is_user() AND $this->user->id() == $doc['post_data']['id_user'] AND $doc['topic_data']['close'] == 0 AND $doc['post_data']['time'] > now() - 600)
                        {
                            $edit_p = TRUE;
                        }
                        else
                        {
                            show_404();
                        }
                        if ($edit_p === TRUE)
                        {
                            if ($this->forum->edit_post($doc['post_data']['id'], $edit_data))
                            {
                                $this->session->set_userdata(array('notice' => 'Комментарий успешно отредактирован.'));
                                redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                                exit();
                            }
                        }
                        else
                        {
                            show_404();
                        }
                    }
                }
            }

            // Права на редактирование поста
            if ($this->user->is_admin(array(1, 10)))
            {
                $this->template->page('forum/edit_post', $this->doc->by_default(array('title' => 'Форум | Комментарии', 'page' => 'forum'), $doc));
            }
            elseif ($this->user->is_user() AND $this->user->id() == $doc['post_data']['id_user'] AND $doc['topic_data']['close'] == 0 AND $doc['post_data']['time'] > now() - 600)
            {
                $this->template->page('forum/edit_post', $this->doc->by_default(array('title' => 'Форум | Комментарии', 'page' => 'forum'), $doc));

            }
            else
            {
                show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактируем топик
    public function edit_topic($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['topic_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['topic_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['topic_data']['description'], 'maxlength' => '10000', 'style' => 'width:99%', 'class' => 'form');
            $doc['up'] = array('name' => 'up', 'value' => 1, 'checked' => $doc['topic_data']['up']);
            $doc['close'] = array('name' => 'close', 'value' => 1, 'checked' => $doc['topic_data']['close']);
            $doc['moder'] = array('0' => 'Проверено', '1' => 'На модерации');

            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[10000]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));
                    $up = $this->function->abs($this->input->post('up'));
                    $close = $this->function->abs($this->input->post('close'));
                    $moder = $this->function->abs($this->input->post('moder'));
                    
                    if ($up != 0 AND $up != 1)
                        $doc['error'][] = 'Не удалось закрепить/открепить тему.';
                    if ($close != 0 AND $close != 1)
                        $doc['error'][] = 'Не удалость закрыть/открыть тему.';
                    if ($moder != 0 AND $moder != 1)
                        $doc['error'][] = 'Режим "Модерации" указан некорректно.';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->forum->edit_topic($doc['topic_data']['id'], array('title' => $title, 'description' => $description, 'time' => now(), 'up' => $up, 'close' => $close, 'edit_who' => $this->user->login(), 'edit_time' => now(), 'edit_count' => $doc['topic_data']['edit_count'] + 1, 'moder' => $moder)))
                        {
                            $this->session->set_userdata(array('notice' => 'Тема успешно отредактирована.'));
                            redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            if ($this->input->post('moved'))
            {
                $move = $this->input->post('move') ? $this->function->abs($this->input->post('move')) : FALSE; 
                
                if ($move > 0)
                {
                    if ($move_data = $this->forum->check_category($move))
                    {
                        $doc['move_data'] = $move_data;
                    } 
                    else
                    {
                        show_404();
                    }
                }
                
                if (is_array($doc['move_data']))
                {
                    if ($this->forum->moved($doc['topic_data']['id'], $doc['move_data']))
                    {
                        $this->session->set_userdata(array('notice' => 'Тема успешно перемещанна.'));
                        redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                        exit();
                    }
                }
            }
            $doc['move_forum'] = $this->forum->move_forum();
            $this->template->page('forum/edit_topic', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
      
        }
        else
        {
            show_404();
        }
    }
    
    // Добавление темы в закладки
    public function add_bookmark($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['topic_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if ($this->forum->check_bookmark($doc['topic_data']['id']))
            {
                $this->session->set_userdata(array('notice' => 'Тема уже добавлена в закладки.'));
                redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                exit();
            }
            elseif($this->forum->add_bookmark($doc['topic_data']))
            {
                $this->session->set_userdata(array('notice' => 'Тема успешно добавлена в закладки.'));
                redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                exit();
            }
            else
            {
                 show_404();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаляем из закладок
    public function delete_bookmark($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['topic_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if ($this->forum->check_bookmark($doc['topic_data']['id']))
            {
                if ($this->forum->delete_bookmark($doc['topic_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Тема успешно удалена из закладок.'));
                    redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }

        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Удаление топика
    public function delete_topic($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if (is_array($doc['topic_data']) AND is_array($doc['category_data']))
            {
                if ($this->forum->delete_topic($doc['topic_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Тема успешно удалена.'));
                    redirect(base_url() . 'index.php/forum/topic/' . $doc['category_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Очистка топика
    public function trunce($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($topic_data = $this->forum->check_topic($id))
            {
                $doc['topic_data'] = $topic_data;
            }
            else
            {
                show_404();
            }
            if ($category_data = $this->forum->check_category($doc['topic_data']['id_category']))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                 show_404();
            }
            if (is_array($doc['topic_data']))
            {
                if ($this->forum->trunce($doc['topic_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Все комментарии к теме успешно удалены.'));
                    redirect(base_url() . 'index.php/forum/post/' . $doc['topic_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // закладки пользователя
    public function bookmark()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/forum/bookmark/pages/';
            $config['total_rows'] = $this->forum->count_all_bookmark_id($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_bookmark($this->user->id(), $config['per_page'], $this->uri->segment(4));
            $this->template->page('forum/bookmark', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Активные темы
    public function active_topic()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/forum/active_topic/pages/';
            $config['total_rows'] = $this->forum->count_all_active_topic();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_active_topic($config['per_page'], $this->uri->segment(4));
  
            $this->template->page('forum/active_topic', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактируем категорию
    public function edit_category($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['category_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['category_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['category_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');

            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                
                if ($this->input->post('description'))
                {
                    $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');
                }
 
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));

                    if (empty($doc['error']))
                    {
                        if ($this->forum->edit_category($doc['category_data']['id'], array('title' => $title, 'description' => $description)))
                        {
                            $this->session->set_userdata(array('notice' => 'Категория успешно отредактирована.'));
                            redirect('forum/category/' . $doc['forum_data']['id']);
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/edit_category', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    // Удаление категории
    public function delete_category($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($category_data = $this->forum->check_category($id))
            {
                $doc['category_data'] = $category_data;
            }
            else
            {
                show_404();
            }
            if ($forum_data = $this->forum->check_forum($doc['category_data']['id_forum']))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            if (is_array($doc['category_data']) AND is_array($doc['forum_data']))
            {
                if ($this->forum->delete_category($doc['category_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Категория успешно удалена.'));
                    redirect('forum/category/' . $doc['forum_data']['id']);
                    exit();
                }
            }
            else
            {
                show_404();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Редактируем подфорум
    public function edit_forum($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }

            $doc['config'] = $this->forum->config();
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : $doc['forum_data']['title'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['description'] = array('name' => 'description', 'value' => $this->input->post('description') ? $this->function->htmlspecialchars($this->input->post('description')) : $doc['forum_data']['description'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Название', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[10]|max_length[3000]');

                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    $description = $this->function->variables($this->input->post('description'));

                    if (empty($doc['error']))
                    {
                        if ($this->forum->edit_forum($doc['forum_data']['id'], array('title' => $title, 'description' => $description)))
                        {
                            $this->session->set_userdata(array('notice' => 'Форум успешно отредактирован.'));
                            redirect('forum/');
                            exit();
                        }
                    }
                }
            }
            $this->template->page('forum/edit_forum', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            show_404();
        }
    }
    
    public function delete_forum($id = '')
    {
        if ($this->user->is_admin(array(1, 10)))
        {
            $id = $this->function->abs($id);

            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($forum_data = $this->forum->check_forum($id))
            {
                $doc['forum_data'] = $forum_data;
            }
            else
            {
                show_404();
            }
            
            if (is_array($doc['forum_data']))
            {
                if ($this->forum->delete_forum($doc['forum_data']['id']))
                {
                    $this->session->set_userdata(array('notice' => 'Форум успешно удален.'));
                    redirect('forum/');
                    exit();
                }
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Поиск
    public function search()
    {
        if ($this->user->is_user())
        {
            $doc['config'] = $this->forum->config();
            $doc['error'] = array();
            $doc['title'] = array('name' => 'title', 'value' => $this->input->post('title') ? $this->function->htmlspecialchars($this->input->post('title')) : '', 'maxlength' => '10', 'style' => 'width:99%', 'class' => 'form');
            $doc['search_forum'] = $this->session->userdata('search_forum') ? $this->session->userdata('search_forum') : '';

            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('title', 'Запрос', 'required|xss_clean|min_length[3]|max_length[10]');
  
                if ($this->form_validation->run())
                {
                    $title = $this->function->variables($this->input->post('title'));
                    
                    if ($title)
                    {
                        $this->session->set_userdata(array('search_forum' => $title));
                        redirect(current_url());
                        exit();
                    }
                }
            }
            
            $config['base_url'] =  base_url() . 'index.php/forum/search/pages/';
            $config['total_rows'] = $this->forum->count_all_search($doc['search_forum']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';

            $this->pagination->initialize($config);

            $doc['foreach'] = $this->forum->get_search($doc['search_forum'], $config['per_page'], $this->uri->segment(4));
   
            $this->template->page('forum/search', $this->doc->by_default(array('title' => 'Форум', 'page' => 'forum'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Правила форума
    public function rules()
    {
        $this->template->page('forum/rules', $this->doc->by_default(array('title' => 'Правила Форума', 'page' => 'forum')));
    }
}