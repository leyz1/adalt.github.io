<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('library_user', NULL, 'user');
        $this->load->library('library_template', NULL, 'template');
        $this->load->library('library_doc', NULL, 'doc');
        $this->load->model('model_functions', 'function', FALSE);
        $this->load->model('model_news', 'news', FALSE);
        $this->load->model('model_forum', 'forum', FALSE);
        $this->load->model('model_chat', 'chat', FALSE);
        $this->load->model('model_profile', 'profile', FALSE);
        $this->load->model('model_friends', 'friend', FALSE);
        $this->load->model('model_contacts', 'contact', FALSE);
        $this->load->model('model_photo', 'photo', FALSE);
        $this->load->model('model_album', 'album', FALSE);
        $this->load->model('model_shopping', 'shop', FALSE);
        $this->load->model('model_blog', 'blog', FALSE);
        $this->load->model('model_wall', 'wall', FALSE);
        $this->load->model('model_seo', 'seo', FALSE);
    }
    
    // Регистрация
    public function registration()
    {
        if ( ! $this->user->is_user())
        {
            $doc['login'] = array('name' => 'login', 'value' => $this->function->htmlspecialchars($this->input->post('login')), 'maxlength' => '20', 'class' => 'form');
            $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'class' => 'form');
            $doc['gender'] = array('m' => 'Мужской', 'w' => 'Женский');
            $doc['day'] = array('name' => 'day', 'value' => $this->function->htmlspecialchars($this->input->post('day')), 'maxlength'  => '2', 'size' => '2', 'class' => 'form');
            $doc['month'] = array('name' => 'month', 'value' => $this->function->htmlspecialchars($this->input->post('month')), 'maxlength' => '2','size' => '2', 'class' => 'form');
            $doc['year'] = array('name' => 'year', 'value' => $this->function->htmlspecialchars($this->input->post('year')), 'maxlength' => '4', 'size' => '4', 'class' => 'form');
            $doc['captcha'] = array('name' => 'captcha', 'maxlength' => '5', 'size' => '5', 'class' => 'form');
            $doc['error'] = array();
            $doc['name'] = array('name' => 'name', 'value' => $this->function->htmlspecialchars($this->input->post('name')), 'maxlength' => '32', 'class' => 'form');
           
            $vals = array('word' => random_string('numeric', 5), 'img_path' => './captcha/', 'img_url' => base_url() . 'captcha/', 'font_path' => './system/fonts/texb.ttf', 'img_width' => '150', 'img_height' => 30, 'expiration' => 600);        
            $doc['code'] = create_captcha($vals);
            
            // Принимаем данные из формы
            if ($this->input->post('submit'))
            {
                // Правила валидации форм
                $this->form_validation->set_rules('name', 'Ваше имя или ник', 'required|xss_clean|min_length[3]|max_length[20]');
                $this->form_validation->set_rules('login', 'Логин', 'required|xss_clean|min_length[2]|max_length[20]|alpha_dash|is_unique[users.login]');
                $this->form_validation->set_rules('password', 'Пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
                $this->form_validation->set_rules('gender', 'Пол', 'required|xss_clean|exact_length[1]|alpha');
                $this->form_validation->set_rules('day', 'Дата рождения', 'required|xss_clean|exact_length[2]|numeric');
                $this->form_validation->set_rules('month', 'Месяц рождения', 'required|xss_clean|exact_length[2]|numeric');
                $this->form_validation->set_rules('year', 'Год рождения', 'required|xss_clean|exact_length[4]|numeric');
                $this->form_validation->set_rules('captcha', 'Код с картинки', 'required|xss_clean|exact_length[5]|numeric');
                   
                // Инициализация валидации  
                if ($this->form_validation->run())
                {
                    // Принимаем переменные
                    $login = $this->input->post('login');
                    $password = $this->input->post('password');
                    $gender = $this->input->post('gender');
                    $day = $this->input->post('day');
                    $month = $this->input->post('month');
                    $year = $this->input->post('year');
                    $code = $this->input->post('captcha');
                    $name = $this->input->post('name');
                    
                    // Проверяем нет ли ошибок
                    if ($this->user->check_login_registration($login))
                        $doc['error'][] = 'Логин уже занят.';
                        
                    if ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $name))
                            $doc['error'] = 'Имя может содержать ТОЛЬКО буквы русского или ТОЛЬКО латинского алфавита.';
                            
                    if ($gender != 'm' and $gender != 'w') 
                        $doc['error'][] = 'Пол указан некорректно.';
                    if ($code != $this->session->userdata('word')) 
                        $doc['error'][] = 'Проверочный код введен не верно.';
                    if ($this->function->day($day))
                        $doc['error'][] = 'Дата рождения указана некорректно.';
                    elseif ($this->function->month($month))
                        $doc['error'][] = 'Месяц рождения указан некорректно.';
                    elseif ($this->function->year($year))
                        $doc['error'][] = 'Год рождения указан некорректно.';
                      
                    // Вставка в БД
                    if (empty($doc['error']))
                    {
                        if ($this->user->registration(array(
                            'login' => $login,
                            'password' => $this->encrypt->sha1($this->encrypt->sha1($password)),
                            'name' => $name,
                            'gender' => $gender,
                            'day' => $day,
                            'month' => $month,
                            'year' => $year,
                            'date_registration' => now(),
                            'date_login' => now(),
                            'visits' => '1',
                            'balls' => '1000',
                            'ip' => $this->input->ip_address(),
                            'user_agent' => $this->input->user_agent())))
                            {
                                // Проверяем есть ли пользователь в БД
                                $array = $this->user->check_login(array('login' => $login, 'password' => $this->encrypt->sha1($this->encrypt->sha1($password))));
                                $newdata = array('uid' => $this->function->abs($array['id']), 'ups' => $array['password']);
                                $this->session->set_userdata($newdata);
                                $cuid = array('name' => 'cuid', 'value'  => $this->encrypt->encode($array['id']), 'expire' => now() + 3600 * 24 * 365);
                                $cups = array('name' => 'cups', 'value'  => $this->encrypt->sha1($password), 'expire' => now() + 3600 * 24 * 365);
                                $this->input->set_cookie($cuid);
                                $this->input->set_cookie($cups);
                                $this->session->set_userdata(array('notice' => 'Спасибо за регистрацию на сайте. Не забудь добавить Wapdoza.Ru в закладки!'));
                                redirect(current_url());
                                exit();
                        }
                    }
                } 
                $this->session->unset_userdata('word');
            }
            
            $this->session->set_userdata($vals);
            $this->template->page('pages/registration', $this->doc->by_default(array('title' => 'Регистрация'), $doc));
        }
        else
        {
            redirect(base_url());
        }
    }
    
    // Регистрация 2
    public function registration_steep()
    {
        if ( ! $this->user->is_user())
        {
            $doc['login'] = array('name' => 'login', 'value' => $this->function->htmlspecialchars($this->input->post('login')), 'maxlength' => '20', 'class' => 'form');
            $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'class' => 'form');
            $doc['gender'] = array('m' => 'Мужской', 'w' => 'Женский');
            $doc['day'] = array('name' => 'day', 'value' => $this->function->htmlspecialchars($this->input->post('day')), 'maxlength'  => '2', 'size' => '2', 'class' => 'form');
            $doc['month'] = array('name' => 'month', 'value' => $this->function->htmlspecialchars($this->input->post('month')), 'maxlength' => '2','size' => '2', 'class' => 'form');
            $doc['year'] = array('name' => 'year', 'value' => $this->function->htmlspecialchars($this->input->post('year')), 'maxlength' => '4', 'size' => '4', 'class' => 'form');
            $doc['captcha'] = array('name' => 'captcha', 'maxlength' => '5', 'size' => '5', 'class' => 'form');
            $doc['error'] = array();
            $doc['name'] = array('name' => 'name', 'value' => $this->function->htmlspecialchars($this->input->post('name')), 'maxlength' => '32', 'class' => 'form');
           
            $vals = array('word' => random_string('numeric', 5), 'img_path' => './captcha/', 'img_url' => base_url() . 'captcha/', 'font_path' => './system/fonts/texb.ttf', 'img_width' => '150', 'img_height' => 30, 'expiration' => 600);        
            $doc['code'] = create_captcha($vals);
            
            
            if ($this->session->userdata('login') !== FALSE)
            {
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('name', 'Ваше имя или ник', 'required|xss_clean|min_length[3]|max_length[20]');
                    $this->form_validation->set_rules('password', 'Пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
                    $this->form_validation->set_rules('gender', 'Пол', 'required|xss_clean|exact_length[1]|alpha');
                    $this->form_validation->set_rules('day', 'Дата рождения', 'required|xss_clean|exact_length[2]|numeric');
                    $this->form_validation->set_rules('month', 'Месяц рождения', 'required|xss_clean|exact_length[2]|numeric');
                    $this->form_validation->set_rules('year', 'Год рождения', 'required|xss_clean|exact_length[4]|numeric');
                    $this->form_validation->set_rules('captcha', 'Код с картинки', 'required|xss_clean|exact_length[5]|numeric');
                    
                    if ($this->form_validation->run())
                    {
                        $name = $this->input->post('name');
                        $password = $this->input->post('password');
                        $gender = $this->input->post('gender');
                        $day = $this->input->post('day');
                        $month = $this->input->post('month');
                        $year = $this->input->post('year');
                        $code = $this->input->post('captcha');
                        $login = $this->session->userdata('login');
                        
                        if ($this->user->check_login_registration($login))
                        {
                            $doc['error'][] = 'Логин уже занят.';
                            $this->session->unset_userdata('login');
                            redirect(current_url());
                            exit();
                        }
                        if ( ! preg_match('/^([a-z1-9\*\-\+\@\(\)\=]+|[а-я1-9\-\=\_]+)$/sui', $name))
                            $doc['error'] = 'Имя может содержать ТОЛЬКО буквы русского или ТОЛЬКО латинского алфавита.';
                            
                        if ($gender != 'm' and $gender != 'w') 
                        $doc['error'][] = 'Пол указан некорректно.';
                        if ($code != $this->session->userdata('word')) 
                            $doc['error'][] = 'Проверочный код введен не верно.';
                        if ($this->function->day($day))
                            $doc['error'][] = 'Дата рождения указана некорректно.';
                        elseif ($this->function->month($month))
                            $doc['error'][] = 'Месяц рождения указан некорректно.';
                        elseif ($this->function->year($year))
                            $doc['error'][] = 'Год рождения указан некорректно.';
                            
                        // Вставка в БД
                        if (empty($doc['error']))
                        {
                            if ($this->user->registration(array(
                                'login' => $login,
                                'password' => $this->encrypt->sha1($this->encrypt->sha1($password)),
                                'name' => $name,
                                'gender' => $gender,
                                'day' => $day,
                                'month' => $month,
                                'year' => $year,
                                'date_registration' => now(),
                                'date_login' => now(),
                                'visits' => '1',
                                'balls' => '1000',
                                'ip' => $this->input->ip_address(),
                                'user_agent' => $this->input->user_agent())))
                                {
                                    // Проверяем есть ли пользователь в БД
                                    $array = $this->user->check_login(array('login' => $login, 'password' => $this->encrypt->sha1($this->encrypt->sha1($password))));
                                    $newdata = array('uid' => $this->function->abs($array['id']), 'ups' => $array['password']);
                                    $this->session->set_userdata($newdata);
                                    $cuid = array('name' => 'cuid', 'value'  => $this->encrypt->encode($array['id']), 'expire' => now() + 3600 * 24 * 365);
                                    $cups = array('name' => 'cups', 'value'  => $this->encrypt->sha1($password), 'expire' => now() + 3600 * 24 * 365);
                                    $this->input->set_cookie($cuid);
                                    $this->input->set_cookie($cups);
                                    $this->session->set_userdata(array('notice' => 'Спасибо за регистрацию на сайте. Не забудь добавить Wapdoza.Ru в закладки!'));
                                    redirect(base_url() . 'index.php/city/country/');
                                    exit();
                            }
                        }    
                    }
                    $this->session->unset_userdata('word');
                }
                
                $this->session->set_userdata($vals);
                $this->template->page('pages/registration_steep', $this->doc->by_default(array('title' => 'Регистрация'), $doc));
            }
            else
            {
                if ($this->input->post('submit'))
                {
                    $this->form_validation->set_rules('login', 'Логин', 'required|xss_clean|min_length[2]|max_length[20]|alpha_dash|is_unique[users.login]');
                    if ($this->form_validation->run())
                    {
                        $login = $this->input->post('login');
                        if ($this->user->check_login_registration($login))
                            $doc['error'][] = 'Логин уже занят.';
                        if (empty($doc['error']))
                        {
                            $this->session->set_userdata(array('login' => true, 'login' => $this->function->variables($login)));
                            redirect(current_url());
                            exit();
                        }
                    }
                    $this->session->unset_userdata('word');
                }
                $this->session->set_userdata($vals);
                $this->template->page('pages/registration_steep', $this->doc->by_default(array('title' => 'Регистрация'), $doc));
            }
        }
        else
        {
            redirect(base_url());
        }
    }
    
    
    // Сервисы
    public function services()
    {
        
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
			
			
		if ($this->user->is_user())
        {	
            $doc['error'] = array();
            
            $this->template->page('pages/services', $this->doc->by_default(array('title' => 'Сервисы/Услуги'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Звезда поиска
    public function star_search()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->input->post('submit'))
            {
                $doc['user_data'] = $this->user->parse_id($this->user->id());
                
                if ($doc['user_data']['balls'] < 10000)
                    $doc['error'] = 'У Вас недостаточно баллов для заказа услуги. Пополните свой баланс!';
                
                elseif ($doc['user_data']['date_star_search'] > now())
                    $doc['error'][] = 'Услуга уже активирована для Вашей анкеты.';    
                if (empty($doc['error']) AND now() > $doc['user_data']['date_star_search'])
                {
                    if ($this->user->update(array('date_star_search' => now() + 1209600)))
                    {
                        $this->user->minus_balls(10000);
                        $this->session->set_userdata(array('notice' => 'Услуга успешно активирована.'));
                        redirect(current_url());
                        exit();
                    }
                }
            }
            $this->template->page('pages/star_search', $this->doc->by_default(array('title' => 'Звезда поиска'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Поднятие анкеты
    public function anketa_up()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($this->input->post('submit'))
            {
                $doc['user_data'] = $this->user->parse_id($this->user->id());
                
                if ($doc['user_data']['balls'] < 10000)
                    $doc['error'] = 'У Вас недостаточно баллов для заказа услуги. Пополните свой баланс!';
                
                elseif ($doc['user_data']['date_anketa_up'] > now())
                    $doc['error'][] = 'Услуга уже активирована для Вашей анкеты.';    
                if (empty($doc['error']) AND now() > $doc['user_data']['date_anketa_up'])
                {
                    if ($this->user->update(array('date_anketa_up' => now() + 604807)))
                    {
                        $this->user->minus_balls(10000);
                        $this->session->set_userdata(array('notice' => 'Услуга успешно активирована.'));
                        redirect(current_url());
                        exit();
                    }
                }
            }
            $this->template->page('pages/anketa_up', $this->doc->by_default(array('title' => 'Поднять анкету'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Анкета Дня
    public function anketa_day()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['anketa_day_type'] = array('all' => 'Показ всем', 'm' => 'Показ парням', 'w' => 'Показ девушкам');
            $doc['time_service'] = array('1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6','7' => '7','8' => '8','9' => '9','10' => '10','11' => '11','12' => '12');
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('anketa_day_type', 'Кому показывать анкету?', 'required|xss_clean|min_length[1]|max_length[3]');
                $this->form_validation->set_rules('time_service', 'Количество часов', 'required|xss_clean|min_length[1]|max_length[2]|numeric');
                
                $doc['user_data'] = $this->user->parse_id($this->user->id());
                
                if ($this->form_validation->run())
                {
                    $anketa_day_type = $this->function->variables($this->input->post('anketa_day_type'));
                    $time_service = $this->function->abs($this->input->post('time_service'));
                    
                    // Расчетбаллов
                    if ($time_service == 1)
                    {
                        $balls = 1000;
                    }
                    elseif ($time_service == 2)
                    {
                        $balls = 2000;
                    }
                    elseif ($time_service == 3)
                    {
                        $balls = 3000;
                    }
                    elseif ($time_service == 4)
                    {
                        $balls = 4000;
                    }
                    elseif ($time_service == 5)
                    {
                        $balls = 5000;
                    }
                    elseif ($time_service == 6)
                    {
                        $balls = 6000;
                    }
                    elseif ($time_service == 7)
                    {
                        $balls = 7000;
                    }
                    elseif ($time_service == 8)
                    {
                        $balls = 8000;
                    }
                    elseif ($time_service == 9)
                    {
                        $balls = 9000;
                    }
                    elseif ($time_service == 10)
                    {
                        $balls = 10000;
                    }
                    elseif ($time_service == 11)
                    {
                        $balls = 11000;
                    }
                    elseif ($time_service == 12)
                    {
                        $balls = 12000;
                    }
                    else
                    {
                        $balls = 1000;
                    }
                    
                    if ( ! element($anketa_day_type, $doc['anketa_day_type']))
                        $doc['error'][] = 'Режим показа указан некорректно.';
                    if ( ! element($time_service, $doc['time_service']))
                        $doc['error'][] = 'Количество часов указано некорректно.';
                    if ($doc['user_data']['balls'] < $balls)
                        $doc['error'] = 'У Вас недостаточно баллов для заказа услуги. Пополните свой баланс!';
                    
                    if (empty($doc['error']))
                    {
                        if ($this->user->update(array('date_anketa_day' => now() + ($time_service * 3600), 'anketa_day_type' => $anketa_day_type)))
                        {
                            $this->user->minus_balls($balls);
                            $this->session->set_userdata(array('notice' => 'Услуга успешно активирована.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                }
            }
            $this->template->page('pages/anketa_day', $this->doc->by_default(array('title' => 'Анкета дня'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Личный кабинет
    public function main()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            
            $this->template->page('pages/menu', $this->doc->by_default(array('page' => 'menu', 'title' => 'Меню'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
        $this->session->unset_userdata('notice');
    }
    
    // Выход с сайта
    public function out()
    {
        
        if ($this->user->is_user())
        {
            // Принимаем данные из формы
            if ($this->input->post('submit'))
            {
                if ($this->user->out())
                {
                    redirect(base_url());
                    exit();                    
                }                
            }
            
            // Отмена
            if ($this->input->post('cancell'))
            {
                redirect(base_url());
                exit();                         
            } 
            
            $this->template->page('pages/out', $this->doc->by_default(array('url' => 'out', 'title' => 'Выход')));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Смайлы
    public function smileys()
    {
        if ($this->user->is_user())
        {
            // Проверим существует ли директория со со смайламы
            if (!is_dir(APPPATH . './../images/smileys/'))
            {
                show_404();
            }

            // Парсинг папки
            $map = directory_map('./images/smileys/');

            $config['base_url'] =  base_url() . 'index.php/page/smileys/pages/';
            $config['total_rows'] = count($map);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->chat->get_smileys($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('pages/smileys', $this->doc->by_default(array('url' => 'smileys', 'title' => 'Смайлы'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Отображаем профиль
    public function profile($id = '')
    {
        $id = $this->function->abs($id);
            
        $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
        $doc['error'] = array();
            
        if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
        {
            show_404();
        }
        elseif ($user_data = $this->user->parse_id($id))
        {
            $doc['user_data'] = $user_data;
        }
        else
        {
            show_404();
        }
            
        if ($this->user->check_ignore($doc['user_data']['id']))
        {
            $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'my_profie'), $doc));
        }
        else
        {
            // Запись гостей
            if ($this->user->is_user() && $this->user->id() != $doc['user_data']['id'])
            {
                if ($guest = $this->profile->check_guest($doc['user_data']['id']))
                {
                    $this->profile->edit_guest($guest['id']);
                }
                else
                {
                    $this->profile->add_guest(array('id_user' => $this->user->id(), 'id_to' => $doc['user_data']['id'], 'time' => now(), 'read' =>"1"));
                }
            }
                
            $this->template->page('pages/profile', $this->doc->by_default(array('title' => $doc['user_data']['login'], 'url' => 'profile'), $doc));
        }
        $this->session->unset_userdata('notice');
    }
    
    // Скачиваем аватар
    public function download_file($hash = '')
    {
        if ($hash === '' AND $hash === FALSE AND $hash === NULL AND $hash == 0)
        {
            show_error('Запрашиваемый файл не найден на сервере.');
        }
        elseif (file_exists(APPPATH . '../files/avatars/' . $this->function->htmlspecialchars($hash) . '.png'))
        {
            $data = file_get_contents(APPPATH . '../files/avatars/' . $this->function->htmlspecialchars($hash) . '.png'); // Считываем содержимое файла
            $name = 'wapdoza.ru.' . $hash . '.png';
            force_download($name, $data); 
        }
        else
        {
            show_404();
        }
    }
    
    // Журнал событий
    public function journal()
    {
        if ($this->user->is_user())
        {
            $this->profile->read_journal($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/journal/pages/';
            $config['total_rows'] = $this->profile->count_all_journal($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->profile->get_journal($this->user->id(), $config['per_page'], $this->uri->segment(4));
            $this->template->page('pages/journal', $this->doc->by_default(array('title' => 'Мой журнал', 'url' => 'journal'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Очистка журнала
    public function trunce_journal()
    {
        if ($this->user->is_user())
        {
            if ($this->profile->trunce_journal())
            {
                $this->session->set_userdata(array('notice' => 'Журнал событий успешно очищен.'));
                redirect(base_url() . 'index.php/page/journal');
                exit();
            }
            else
            {
                redirect(base_url() . 'index.php/page/journal');
                exit();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Очистка гостей
    public function trunce_guest()
    {
        if ($this->user->is_user())
        {
            if ($this->profile->trunce_guest())
            {
                $this->session->set_userdata(array('notice' => 'Список гостей успешно очищен.'));
                redirect(base_url() . 'index.php/page/guest');
                exit();
            }
            else
            {
                redirect(base_url() . 'index.php/page/guest');
                exit();
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Просмотр жалобы
    public function spam()
    {
        if ($this->user->is_admin(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))
        {
            $this->profile->read_spam();
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/spam/pages/';
            $config['total_rows'] = $this->db->count_all('users_spam');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
            
            $this->pagination->initialize($config);
            
            $doc['foreach'] = $this->profile->get_spam($config['per_page'], $this->uri->segment(4));
            $this->template->page('pages/spam', $this->doc->by_default(array('title' => 'Спам/Жалобы', 'url' => 'journal'), $doc));
            $this->session->unset_userdata('notice');

        }
        else
        {
            show_404();
        }
    }
    
    // Очистка спама
    public function trunce_spam()
    {
        if ($this->user->is_admin(array(8, 9, 10)))
        {
            if ($this->profile->trunce_spam())
            {
                $this->session->set_userdata(array('notice' => 'Спам/Жалобы успешно очищены.'));
                redirect(base_url() . 'index.php/page/spam');
                exit();
            }
            else
            {
                redirect(base_url() . 'index.php/page/spam');
                exit();
            }
        }
        else
        {
            show_404();
        }
    }
    
    // Подарки пользователя
    public function present($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                 $id = $this->user->id();
            }
            
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if (is_array($doc['user_data']))
            {
                $config['base_url'] =  base_url() . 'index.php/page/present/' . $doc['user_data']['id'] . '/pages/';
                $config['total_rows'] = $this->shop->count_all_gift_id_user($doc['user_data']['id']);
                $config['per_page'] = $this->user->per_page();
                $config['full_tag_open'] = '<div class="page">';
                $config['full_tag_close'] = '</div>';
                $config['uri_segment'] = 5;
                $config['num_links'] = 2;
                $config['first_link'] = '&laquo; В начало';
                $config['next_link'] = 'Далее';
                $config['prev_link'] = 'Назад';
                $config['last_link'] = 'В конец &raquo;';
                    
                $this->pagination->initialize($config);
                $doc['foreach'] = $this->shop->get_gift($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
            
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'present'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['view_present'] == 1 AND $this->user->check_friends($doc['user_data']['id']) === FALSE))
                {
                    $this->template->page('shopping/error_view_friends', $this->doc->by_default(array('title' => 'Мои друзья', 'page' => 'friends'), $doc));
                }
                elseif (($this->user->id() != $doc['user_data']['id']) AND ($doc['user_data']['view_present'] == 2))
                {
                    $this->template->page('shopping/view_not_found', $this->doc->by_default(array('title' => 'Подарки', 'page' => 'friends'), $doc));
                }
                else
                {
                    if ($this->input->post('delete'))
                    {
                        $this->form_validation->set_rules('id_present', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric');
                        if ($this->form_validation->run())
                        {
                            $id_present = $this->function->abs($this->input->post('id_present'));
                            if ($id_present === '' OR $id_present === FALSE OR $id_present === NULL OR $id_present == 0)
                                $doc['error'][] = 'ID подарка указан некорректно.';
                            if (empty($doc['error']))
                            {
                                if ($del = $this->shop->check_gift_id_user($id_present))
                                {
                                    $this->shop->delete_gift_id_user($del['id']);
                                    $this->session->set_userdata(array('notice' => 'Подарок успешно удален.'));
                                    redirect(current_url());
                                    exit();
                                }
                                else
                                {
                                    $doc['error'][] = 'Ето не ваш подарок.';
                                }
                            }
                        }
                    }
                    
                    
                    $this->template->page('pages/present', $this->doc->by_default(array('title' => 'Подарки', 'page' => 'present'), $doc));
                    $this->session->unset_userdata('notice');
                }
            }
            else
            {
                $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'friends')));
            }
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Анкета
    public function anketa($id = '')
    {
        if ($this->user->is_user())
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                $id = $this->user->id();
            }
            
            if ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                $doc['user_data'] = '';
            }
            
            if (is_array($doc['user_data']))
            {
                if ($this->user->check_ignore($doc['user_data']['id']))
                {
                    $this->template->page('templates/black_list', $this->doc->by_default(array('title' => 'Черный список', 'page' => 'friends'), $doc));
                }
                else
                {
                    $this->template->page('pages/anketa', $this->doc->by_default(array('title' => 'Просмотр Анкеты', 'page' => 'anketa'), $doc));
                }
                $this->session->unset_userdata('notice');
            }
            else
            {
                 $this->template->page('templates/user_not_found', $this->doc->by_default(array('title' => 'ОПС!', 'page' => 'my_profile')));
            }
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Парни на сайте
    public function boy()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/boy/pages/';
            $config['total_rows'] = $this->profile->count_online_boy();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_online_boy($config['per_page'], $this->uri->segment(4));

            $this->template->page('pages/boy', $this->doc->by_default(array('title' => 'Кто на сайте', 'page' => 'online'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Девушки на сайте
    public function girl()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/girl/pages/';
            $config['total_rows'] = $this->profile->count_online_girl();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_online_girl($config['per_page'], $this->uri->segment(4));

            $this->template->page('pages/girl', $this->doc->by_default(array('title' => 'Кто на сайте', 'page' => 'online'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    public function all_online()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/all_online/pages/';
            $config['total_rows'] = $this->profile->count_user_online();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_user_online($config['per_page'], $this->uri->segment(4));

            $this->template->page('pages/all_online', $this->doc->by_default(array('title' => 'Кто на сайте', 'page' => 'online'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Все пользователи
    public function users()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/users/pages/';
            $config['total_rows'] = $this->db->count_all('users');
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_users($config['per_page'], $this->uri->segment(4));

            $this->template->page('pages/users', $this->doc->by_default(array('title' => 'Пользователи', 'page' => 'users'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Мой журнал
    public function guest()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            // Читаем гостей
            $this->profile->read_guest($this->user->id());
             
            $config['base_url'] =  base_url() . 'index.php/page/guest/pages/';
            $config['total_rows'] = $this->profile->count_all_guest_id_to($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_guest($this->user->id(), $config['per_page'], $this->uri->segment(4));

            $this->template->page('pages/guest', $this->doc->by_default(array('title' => 'Мои гости', 'page' => 'guest'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Бан пользователя
    public function baned($id = '')
    {
        if ($this->user->is_admin(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['description'] = array('name' => 'description', 'value' => $this->function->htmlspecialchars($this->input->post('description')), 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['time_ban'] = array('1' => '1 Час', '2' => '2 Часа', '3' => '3 Часа', '4' => '1 День', '5' => '2 Дня', '6' => '3 Дня', '7' => '1 Месяц', '8' => 'Забанить навсегда');
            
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                show_404();
            }
            
            $config['base_url'] =  base_url() . 'index.php/page/baned/' . $doc['user_data']['id'] . '/pages/';
            $config['total_rows'] = $this->profile->count_all_ban($doc['user_data']['id']);
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_users_ban($doc['user_data']['id'], $config['per_page'], $this->uri->segment(5));
            
            if ($this->input->post('submit'))
            {
                $banan = $this->user->parse_id($doc['user_data']['id']);
                
                $this->form_validation->set_rules('description', 'Описание', 'required|xss_clean|min_length[5]|max_length[255]');
                $this->form_validation->set_rules('time_ban', 'Время бана', 'required|xss_clean|exact_length[1]|numeric');
                
                if ($this->form_validation->run())
                {
                    $time_ban = $this->function->abs($this->input->post('time_ban'));
                    $description = $this->function->variables($this->input->post('description'));
                            
                    if ($this->user->id() == $banan['id'])
                        $doc['error'][] = 'Себя банить нельзя или ты Урка? Сообщи Админу, чтобы тебя забанил.';
                    elseif ($banan['level'] == 10)
                        $doc['error'][] = 'Спасибо, Админ узнает, что ты хотел его забанить.';
                    if ( ! element($time_ban, $doc['time_ban']))
                        $doc['error'][] = 'Время бана установлено некорректно.';
                        
                    if (empty($doc['error']))
                    {
                        if ($time_ban == 1)
                        {
                            $ban = 3600;
                        }
                        elseif ($time_ban == 2)
                        {
                            $ban = 3600 * 2;
                        }
                        elseif ($time_ban == 3)
                        {
                            $ban = 3600 * 3; 
                        }
                        elseif ($time_ban == 4)
                        {
                            $ban = 86400;
                        }
                        elseif ($time_ban == 5)
                        {
                            $ban = 86400 * 2;
                        }
                        elseif ($time_ban == 6)
                        {
                            $ban = 86400 * 3;
                        }
                        elseif ($time_ban == 7)
                        {
                            $ban = 86400 * 31;
                        }
                        elseif ($time_ban == 8)
                        {
                            $ban = 86400 * 9999;
                        }
                        
                        if (empty($doc['error']))
                        {
                            $time_end = now() + $ban;
                            
                            if ($this->profile->add_ban(array('id_user' => $doc['user_data']['id'], 'id_admin' => $this->user->id(), 'description' => $description, 'time' => $time_end)))
                            {
                                $this->session->set_userdata(array('notice' => 'Урка успешно забанен.'));
                                redirect(base_url() . 'index.php/page/profile/' . $doc['user_data']['id']);
                                exit();
                            }
                        }
                    }
                }
            }
            
            if ($this->input->post('nulled'))
            {
                $this->form_validation->set_rules('id_ban', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id_ban = $this->function->abs($this->input->post('id_ban'));
                    if ($id_ban === '' OR $id_ban === FALSE OR $id_ban === NULL OR $id_ban == 0)
                        $doc['error'][] = 'ID бана указан некорректно.';
                    if ($this->profile->check_baned($id_ban))
                    {
                        if ($this->profile->nulled_ban($id_ban))
                        {
                            $this->session->set_userdata(array('notice' => 'Время бана успешно обнулено.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Бан не найден.';
                    }
                    
                }
            }
            
            if ($this->input->post('delete'))
            {
                $this->form_validation->set_rules('id_ban', 'ID', 'required|xss_clean|min_length[1]|max_length[11]|numeric'); 
                if ($this->form_validation->run())
                {
                    $id_ban = $this->function->abs($this->input->post('id_ban'));
                    if ($id_ban === '' OR $id_ban === FALSE OR $id_ban === NULL OR $id_ban == 0)
                        $doc['error'][] = 'ID бана указан некорректно.';
                    if ($this->profile->check_baned($id_ban))
                    {
                        if ($this->profile->delete_ban($id_ban))
                        {
                            $this->session->set_userdata(array('notice' => 'Бан успешно удален.'));
                            redirect(current_url());
                            exit();
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Бан не найден.';
                    }
                    
                }
            }
            
            $this->template->page('pages/baned', $this->doc->by_default(array('title' => 'Забанить Урку', 'page' => 'users'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Список нарушений
    public function bans()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/bans/pages/';
            $config['total_rows'] = $this->profile->count_all_ban($this->user->id());
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_users_ban($this->user->id(), $config['per_page'], $this->uri->segment(4));
            
            $this->template->page('pages/bans', $this->doc->by_default(array('title' => 'Список нарушений', 'page' => 'bans'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Бан панель
    public function banan()
    {
        if ($this->user->is_admin(array(10)))
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            
            $config['base_url'] =  base_url() . 'index.php/page/banan/pages/';
            $config['total_rows'] = $this->profile->count_all_banan();
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_users_banan($config['per_page'], $this->uri->segment(4));
            
            $this->template->page('pages/banan', $this->doc->by_default(array('title' => 'Бан - Панель', 'page' => 'bans'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Правила сайта
    public function service()
    {
        $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
        $doc['error'] = array();
        $this->template->page('pages/service', $this->doc->by_default(array('title' => 'Правила сайта', 'page' => 'service'), $doc));
        $this->session->unset_userdata('notice');
        $this->output->cache(60); 
    }
    
    // Деактивация
    public function activation()
    {
        $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
        $doc['error'] = array();
        $this->template->page('pages/activation', $this->doc->by_default(array('title' => 'Анкета деактивирована', 'page' => 'activation'), $doc));
        $this->session->unset_userdata('notice');
        $this->output->cache(60);
    }
    
    // Поиск
    public function search()
    {
        if ($this->user->is_user())
        {
            $doc['user_data'] = $this->user->parse_id($this->user->id());
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['city'] = array('name' => 'city', 'value' => $this->function->htmlspecialchars($this->input->post('city')), 'maxlength' => '64', 'size' => '32', 'class' => 'form');
            $doc['gender'] = array('m' => 'Парня', 'w' => 'Дувушку');
            $doc['sex_orient'] = array('0' => 'Не указывать', '1' => 'Гетеро', '2' => 'Гей', '3' => 'Би');  
            $doc['getting_target1'] = array('name' => 'getting_target1', 'value' => 1, 'checked' => $doc['user_data']['getting_target1']);
            $doc['getting_target2'] = array('name' => 'getting_target2', 'value' => 1, 'checked' => $doc['user_data']['getting_target2']);
            $doc['getting_target3'] = array('name' => 'getting_target3', 'value' => 1, 'checked' => $doc['user_data']['getting_target3']);
            $doc['getting_target4'] = array('name' => 'getting_target4', 'value' => 1, 'checked' => $doc['user_data']['getting_target4']);
            $doc['getting_target5'] = array('name' => 'getting_target5', 'value' => 1, 'checked' => $doc['user_data']['getting_target5']);
            $doc['getting_target6'] = array('name' => 'getting_target6', 'value' => 1, 'checked' => $doc['user_data']['getting_target6']);
            $doc['family'] = array('0' => 'Не указывать', '1' => 'Женат/Замужем', '2' => 'Холост/Не замужем', '3' => 'Живем раздельно');
            $doc['sex_skill'] = array('0' => 'Не указывать', '1' => 'Большой', '2' => 'Небольшой', '3' => 'Нету');
           
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('gender', 'Пол', 'required|xss_clean|exact_length[1]|alpha');
                
                if ($this->input->post('city'))
                    $this->form_validation->set_rules('city', 'Город', 'required|xss_clean|min_length[2]|max_length[64]');
                if ($this->input->post('sex_orient'))
                    $this->form_validation->set_rules('sex_orient', 'Ориентация', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target1'))
                    $this->form_validation->set_rules('getting_target1', 'Дружба и общение', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target2'))
                    $this->form_validation->set_rules('getting_target2', 'Флирт, СМС-переписка', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target3'))
                    $this->form_validation->set_rules('getting_target3', 'Любовь, отношения', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target4'))
                    $this->form_validation->set_rules('getting_target4', 'Брак, создание семьи', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target5'))
                    $this->form_validation->set_rules('getting_target5', 'Виртуальный секс', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('getting_target6'))
                    $this->form_validation->set_rules('getting_target6', 'Секс в реале', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('family'))
                    $this->form_validation->set_rules('family', 'Семейное положение', 'required|xss_clean|exact_length[1]|numeric');
                if ($this->input->post('sex_skill'))
                    $this->form_validation->set_rules('sex_skill', 'Сексуальный опыт', 'required|xss_clean|exact_length[1]|numeric');
              
                if ($this->form_validation->run())
                {
                    $gender = $this->function->variables($this->input->post('gender'));
                    $city = $this->function->variables($this->input->post('city'));
                    $sex_orient = $this->function->abs($this->input->post('sex_orient'));
                    $getting_target1 = $this->function->abs($this->input->post('getting_target1'));
                    $getting_target2 = $this->function->abs($this->input->post('getting_target2'));
                    $getting_target3 = $this->function->abs($this->input->post('getting_target3'));
                    $getting_target4 = $this->function->abs($this->input->post('getting_target4'));
                    $getting_target5 = $this->function->abs($this->input->post('getting_target5'));
                    $getting_target6 = $this->function->abs($this->input->post('getting_target6'));
                    $family = $this->function->abs($this->input->post('family'));
                    $sex_skill = $this->function->abs($this->input->post('sex_skill'));
                    
                    if ( ! element($gender, $doc['gender']))
                        $doc['error'][] = 'Пол указан некорректно.';
                        
                    if ( ! element($sex_orient, $doc['sex_orient']))
                            $doc['error'][] = 'Ориентация указана некорректно.';    
                    
                    if ($getting_target1)
                    {
                        if ($getting_target1 != 0 AND $getting_target1 != 1)
                            $doc['error'][] = 'Дружба и общение указано некорректно.';
                    }
                    if ($getting_target2)
                    {
                        if ($getting_target2 != 0 AND $getting_target2 != 1)
                            $doc['error'][] = 'Флирт, СМС-переписка указано некорректно.';
                    }
                    if ($getting_target3)
                    {
                        if ($getting_target3 != 0 AND $getting_target3 != 1)
                            $doc['error'][] = 'Любовь, отношения указано некорректно.';
                    }
                    if ($getting_target4)
                    {
                        if ($getting_target4 != 0 AND $getting_target4 != 1)
                            $doc['error'][] = 'Брак, создание семьи указано некорректно.';
                    }
                    if ($getting_target5)
                    {
                        if ($getting_target5 != 0 AND $getting_target5 != 1)
                            $doc['error'][] = 'Виртуальный секс указан некорректно.';
                    }
                    if ($getting_target6)
                    {
                        if ($getting_target6 != 0 AND $getting_target6 != 1)
                            $doc['error'][] = 'Секс в реале указан некорректно.';
                    }
                    
                    if ($family)
                    {
                        if ( ! element($family, $doc['family']))
                            $doc['error'][] = 'Семейное положение указано некорректно.';
                    }
                    
                    if ($sex_skill)
                    {
                        if ( ! element($sex_skill, $doc['sex_skill']))
                            $doc['error'][] = 'Сексуальный опыт указан некорректно.';
                    }
                    
                    if (empty($doc['error']))
                    {
                        if ($sex_orient == 0)
                            $sex_orient = '';
                            
                        if ($family == 0)
                            $family = '';
                            
                        if ($sex_skill == 0)
                            $sex_skill = '';
                                    
                        $search_data = array(
                            'gender' => $gender,
                            'city' => $city,
                            'sex_orient' => "$sex_orient",
                            'getting_target1' => "$getting_target1",
                            'getting_target2' => "$getting_target2",
                            'getting_target3' => "$getting_target3",
                            'getting_target4' => "$getting_target4",
                            'getting_target5' => "$getting_target5",
                            'getting_target6' => "$getting_target6",
                            'family' => "$family",
                            'sex_skill' => "$sex_skill"
                        );
                        $this->session->set_userdata(array('go' => $search_data));
                        redirect(base_url() . 'index.php/page/go/');
                        exit();
                    }
                }
            }
            
            
            $this->template->page('pages/search', $this->doc->by_default(array('title' => 'Поиск пользователей', 'page' => 'search'), $doc));
            $this->session->unset_userdata('go'); 
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Результаты поиска
    public function go()
    {
        if ($this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();

            $config['base_url'] =  base_url() . 'index.php/page/go/pages/';
            $config['total_rows'] = $this->profile->count_search($this->session->userdata('go'));
            $config['per_page'] = $this->user->per_page();
            $config['full_tag_open'] = '<div class="page">';
            $config['full_tag_close'] = '</div>';
            $config['uri_segment'] = 4;
            $config['num_links'] = 2;
            $config['first_link'] = '&laquo; В начало';
            $config['next_link'] = 'Далее';
            $config['prev_link'] = 'Назад';
            $config['last_link'] = 'В конец &raquo;';
                    
            $this->pagination->initialize($config);
            $doc['foreach'] = $this->profile->get_search($this->session->userdata('go'), $config['per_page'], $this->uri->segment(4));
 
            $this->template->page('pages/go', $this->doc->by_default(array('title' => 'Результаты поиска', 'page' => 'search'), $doc));
        }
        else
        {
            $this->template->page('templates/only_user', $this->doc->by_default());
        }
    }
    
    // Редактируем профиль
    public function edit_user($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['level'] = array('0' => 'Пользователь', '1' => 'Модератор форума', '2' => 'Модератор чата', '3' => 'Модератор фото', '4' => 'Модератор дневников', '10' => 'Главный Администратор');
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                show_404();
            }
            
            $doc['gender'] = array('m' => 'Мужской', 'w' => 'Женский');
            $doc['welcome_msg'] = array('name' => 'welcome_msg', 'value' => $this->input->post('welcome_msg') ? $this->function->htmlspecialchars($this->input->post('welcome_msg')) : $doc['user_data']['welcome_msg'], 'maxlength' => '255', 'style' => 'width:99%', 'class' => 'form');
            $doc['balls'] = array('name' => 'balls', 'value' => $this->input->post('balls') ? $this->function->htmlspecialchars($this->input->post('balls')) : $doc['user_data']['balls'], 'maxlength' => '10', 'style' => 'width:99%', 'class' => 'form');
            $doc['deleted'] = array('0' => 'Активация', '1' => 'Деактивация');
            
            if ($this->input->post('submit'))
            {
                if ($this->input->post('gender'))
                    $this->form_validation->set_rules('gender', 'Пол', 'required|xss_clean|exact_length[1]|alpha');
                if ($this->input->post('level'))
                    $this->form_validation->set_rules('level', 'Должность', 'required|xss_clean|min_length[1]|max_length[2]|numeric');
                if ($this->input->post('welcome_msg'))
                    $this->form_validation->set_rules('welcome_msg', 'Приветствие', 'required|xss_clean|min_length[3]|max_length[255]');
                if ($this->input->post('balls'))
                    $this->form_validation->set_rules('balls', 'Баллы', 'required|xss_clean|numeric');
                if ($this->input->post('deleted'))
                    $this->form_validation->set_rules('deleted', 'Статус анкеты', 'required|xss_clean|exact_length[1]|numeric');
                        
                if ($this->form_validation->run())
                {
                    $welcome_msg = $this->function->variables($this->input->post('welcome_msg'));
                    $gender = $this->function->variables($this->input->post('gender'));
                    $balls = $this->function->abs($this->input->post('balls'));
                    $level = $this->function->abs($this->input->post('level'));
                    $deleted = $this->function->abs($this->input->post('deleted'));
                    
                    if ( ! element($level, $doc['level']))
                        $doc['error'][] = 'Должность назначена неверно.';
                    if ( ! element($deleted, $doc['deleted']))
                        $doc['error'][] = 'Статус анкеты указан некорректно.';
                        
                    if (empty($doc['error']))
                    {
                        if ($this->profile->edit_profile($doc['user_data']['id'], array('level' => $level, 'welcome_msg' => $welcome_msg, 'gender' => $gender, 'balls' => $balls, 'delete' => "$deleted")))
                        {
                            $this->session->set_userdata(array('notice' => 'Профиль успешно отредактирован.'));
                            redirect(base_url() . 'index.php/page/profile/' . $doc['user_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('pages/edit_user', $this->doc->by_default(array('title' => 'Редактируеи профиль', 'page' => 'my_profile'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Изменяем логин
    public function edit_login($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                show_404();
            }
            
            $doc['login'] = array('name' => 'login', 'value' => $this->input->post('login') ? $this->function->htmlspecialchars($this->input->post('login')) : $doc['user_data']['login'], 'maxlength' => '20', 'class' => 'form');
          
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('login', 'Логин', 'required|xss_clean|min_length[2]|max_length[20]|alpha_dash|is_unique[users.login]');
                 
                if ($this->form_validation->run())
                {
                    $login = $this->function->variables($this->input->post('login'));
                    
                     if ($this->user->check_login_registration($login))
                        $doc['error'][] = 'Логин уже занят.';
                            
                    if (empty($doc['error']))
                    {
                        if ($this->profile->edit_profile($doc['user_data']['id'], array('login' => $login)))
                        {
                            $this->session->set_userdata(array('notice' => 'Профиль успешно отредактирован.'));
                            redirect(base_url() . 'index.php/page/profile/' . $doc['user_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('pages/edit_login', $this->doc->by_default(array('title' => 'Изменить логин', 'page' => 'my_profile'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Изменяем пароль
    public function edit_pass($id = '')
    {
        if ($this->user->is_admin(array(10)))
        {
            $id = $this->function->abs($id);
            
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            if ($id === '' OR $id === FALSE OR $id === NULL OR $id == 0)
            {
                show_404();
            }
            elseif ($user_data = $this->user->parse_id($id))
            {
                $doc['user_data'] = $user_data;
            }
            else
            {
                show_404();
            }
            
            $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'class' => 'form');
           
            if ($this->input->post('submit'))
            {
                $this->form_validation->set_rules('password', 'Пароль', 'required|xss_clean|min_length[6]|max_length[40]|alpha_dash');
               
                if ($this->form_validation->run())
                {
                    $password = $this->input->post('password');

                    if (empty($doc['error']))
                    {
                        if ($this->profile->edit_profile($doc['user_data']['id'], array('password' => $this->encrypt->sha1($this->encrypt->sha1($password)))))
                        {
                            $this->session->set_userdata(array('notice' => 'Профиль успешно отредактирован.'));
                            redirect(base_url() . 'index.php/page/profile/' . $doc['user_data']['id']);
                            exit();
                        }
                    }
                }
            }
            
            $this->template->page('pages/edit_pass', $this->doc->by_default(array('title' => 'Изменить пароль', 'page' => 'my_profile'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            show_404();
        }
    }
    
    // Восстановление пароля
    public function pswdreminder()
    {
        if ( ! $this->user->is_user())
        {
            $doc['notice'] = $this->session->userdata('notice') ? $this->session->userdata('notice') : array();
            $doc['error'] = array();
            $doc['mail'] = array('name' => 'mail', 'value' => $this->function->htmlspecialchars($this->input->post('mail')), 'maxlength' => '128', 'size' => 128, 'class' => 'form');
            $doc['login'] = array('name' => 'login', 'value' => $this->function->htmlspecialchars($this->input->post('login')), 'maxlength' => '20', 'class' => 'form');
            $doc['password'] = array('name' => 'password', 'maxlength' => '40', 'class' => 'form');
       
            if ($this->input->post('submit'))
            {
                 $this->form_validation->set_rules('login', 'Логин', 'required|xss_clean|min_length[2]|max_length[20]|alpha_dash');
                 $this->form_validation->set_rules('mail', 'E-mail', 'required|xss_clean|valid_email'); 
                 if ($this->form_validation->run())
                 {
                    $login = $this->input->post('login');
                    $mail = $this->input->post('mail');
                    
                    if ($this->user->check_login_registration($login))
                    {
                        if ($sent_pass = $this->user->check_pswdreminder($login, $mail))
                        {
                            $hash_password = random_string('alnum', 6);
                            
                            if ($this->profile->edit_profile($sent_pass['id'], array('password' => $this->encrypt->sha1($this->encrypt->sha1($hash_password)))))
                            {
                                $this->email->from('noreply@wapdoza.ru', 'Система'); 
                                $this->email->to(trim($mail)); 
                                $this->email->subject('Восстановление пароля на сайте Wapdoza.Ru'); 
                                $this->email->message('Ваш новый пароль сгенирирован автоматически: ' . $hash_password); 
                                $this->email->send();
                                //send_email(trim($mail), 'Восстановление пароля на сайте Wapdoza.Ru', 'Новый пароль: ' . $hash_password);
                                $this->session->set_userdata(array('notice' => 'Новый пароль отправлен Вам на E-mail.'));
                                redirect(base_url());
                                exit();
                            }
                        }
                        else
                        {
                            $doc['error'][] = 'Неверный адрес E-mail или информация о E-mail отсутствует';
                        }
                    }
                    else
                    {
                        $doc['error'][] = 'Пользователь с таким логином не зарегистрирован.';
                    }
                 }   
            }
            
            $this->template->page('pages/pswdreminder', $this->doc->by_default(array('title' => ' Забыли пароль?', 'page' => 'my_profile'), $doc));
            $this->session->unset_userdata('notice');
        }
        else
        {
            redirect(base_url());
            exit();
        }
    }
    
    // Seo generations
    public function sitemap()
    {
         $this->template->page('pages/sitemap', $this->doc->by_default(array('title' => 'SEO WAPDOZA.RU', 'page' => 'sitemap')));
    }
}