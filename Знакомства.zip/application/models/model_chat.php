<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Chat extends CI_Model
{
    // Настройки чата
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 3, // Таймаут между отправкой комментариев
            'balls' => 10, // Количество баллов за один комментарий
            'bot_nerd' => 'Умник', // Ник бота умника
            'bot_nerd2' => 'Дядя Вася', // Ник матерного бота
            'autoupdate' => '15', // Автообновление в чате
            'timeout_questions' => '60', // Таймаут между вопросами
            'timeout_help' => '15'); // Таймаут между подсказками
    }
    
    // Функция возращает последнию позицию комнаты
    public function sort_room()
    {
        $this->db->order_by('sort', 'DESC');
        $query = $this->db->get('chat_room', 1);
        if ($query->num_rows() > 0) 
        {
            $room = $query->row_array();
            return trim($room['sort'] + 1);
        }
        else
        {
            return 1;
        }                
    }
    
    // Функция добавляет новую комнату в БД
    public function add_room($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('chat_room', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все комнаты из БД
    public function get_room($num, $offset)
    {
        $this->db->order_by('sort');
        $query = $this->db->get('chat_room', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверяет существование комнаты в бд и возвращает ассоциативный массив с её данными
    public function check_room($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('chat_room');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Функция перемещаем форум на позицию выше
    public function up_room($id = '')
    {
        $sort = '';
        $sort2 = '';
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            // Первая позиция
            $this->db->where('id', $id);
            $query = $this->db->get('chat_room', 1);
            if ($query->num_rows() > 0) 
            {
                $room = $query->row_array();
                $sort = trim($room['sort']);
            }
            // Вторая позиция
            $this->db->where('sort < "' . $sort . '"');
            $this->db->order_by('sort', 'DESC');
            $query = $this->db->get('chat_room', 1);
            if ($query->num_rows() > 0) 
            {
                $room2 = $query->row_array();
                $sort2 = trim($room2['sort']);
            }
            // Если некуда перемещать
            if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
            {
                return FALSE;
            }
            elseif ($sort2 > 0)
            {
                $this->db->where('id', $room['id']);
                $this->db->update('chat_room', array('sort' => $sort2));
                $this->db->where('id', $room2['id']);
                $this->db->update('chat_room', array('sort' => $sort));
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция перемещаем форум на позицию ниже
    public function down_room($id = '')
    {
        $sort = '';
        $sort2 = '';
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            // Первая позиция
            $this->db->where('id', $id);
            $query = $this->db->get('chat_room', 1);
            if ($query->num_rows() > 0) 
            {
                $room = $query->row_array();
                $sort = trim($room['sort']);
            }
            // Вторая позиция
            $this->db->where('sort > "' . $sort . '"');
            $this->db->order_by('sort', 'ASC');
            $query = $this->db->get('chat_room', 1);
            if ($query->num_rows() > 0) 
            {
                $room2 = $query->row_array();
                $sort2 = trim($room2['sort']);
            }
            // Если некуда перемещать
            if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
            {
                return FALSE;
            }
            elseif ($sort2 > 0)
            {
                $this->db->where('id', $room['id']);
                $this->db->update('chat_room', array('sort' => $sort2));
                $this->db->where('id', $room2['id']);
                $this->db->update('chat_room', array('sort' => $sort));
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция добавляет сообщение в комнату
    public function add_post($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('chat_post', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все посты из БД в заданной комнате
    public function get_post($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_room', $id);
            $this->db->order_by('time', 'DESC');
            $this->db->order_by('id_user', '0');
            $query = $this->db->get('chat_post', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество постов в выбранной комнате
    public function count_all_post_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {          
            $this->db->where('id_room', $id);
            $query = $this->db->get('chat_post');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверяет сущетвование поста в бд
    public function check_post($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('chat_post');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функцмя удаляет выбранный пост из бд
    public function delete_post($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('chat_post', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция автоматической чистки комнат
    public function auto_trunce_room($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_room', $id);
            $this->db->where('time < "' . (now() - 600) . '"');
            $this->db->delete('chat_post');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция запишет кто есть к комнате
    public function add_who_room($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('chat_who', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция удаляет пользователя с комнаты
    public function delete_who_room_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('chat_who', array('id_user' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция удаляет всех пользователей с комнаты за 10 минут
    public function delete_who_room($id = '')
    {
        $this->db->where('time < "' . (now() - 600) . '"');
        $this->db->delete('chat_who');
        return TRUE;
    }
    
    // Функция отображает количество пользователей в комнате
    public function count_all_who_room($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_room', $id);
            $query = $this->db->get('chat_who');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Фугкция выводит список пользователей в комнате
    public function get_who_room($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_room', $id);
            $query = $this->db->get('chat_who', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество пользователей в чате
    public function count_all_who()
    {
        $this->db->where('time > "' . (now() - 600) . '"');
        $query = $this->db->get('chat_who');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Очистка комнаты
    public function trunce_room($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('chat_post', array('id_room' => $id)))
            {
                $this->dbutil->optimize_table('chat_post');
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция обновляет данные о комнате
    public function edit_room($id = '', $array)
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('chat_room', $array); 
            // Оптимизация
            $this->dbutil->optimize_table('chat_room');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция полного удаления комнаты
    public function delete_room($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('chat_room', array('id' => $id)))
            {
                $this->db->delete('chat_post', array('id_room' => $id));
                $this->db->delete('chat_who', array('id_room' => $id));
                // Оптимизация
                $this->dbutil->optimize_table('chat_room');
                $this->dbutil->optimize_table('chat_post');
                $this->dbutil->optimize_table('chat_who');
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает список умников
    public function get_iq($num, $offset)
    {
        $this->db->order_by('iq', 'DESC');
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Засчитываем iq пользователю
    public function iq($iq = 0)
    {
        $CI =& get_instance();
        $data = $this->user->authorization();
        
        if ($iq > 0 AND is_array($data))
        {
            $CI->db->where('id', $data['id']);
            $CI->db->update('users', array('iq' => $data['iq'] + $iq)); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Смайлы
    public function get_smileys($num, $offset)
    {
        $map = directory_map('./images/smileys/');
        
        if ($offset == 0) $offset = 1;
        
        $total = count($map);
        
        $end = $num + $offset;
        
        if ($end > $total) $end = $total;
        
        for ($i = $offset; $i < $end; $i++)
        {
            $result_array[] = $map[$i];
        }
        return $result_array;
    }
}