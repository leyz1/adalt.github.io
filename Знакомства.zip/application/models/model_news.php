<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_News extends CI_Model
{
    // Настройки новостей
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls' => 10); // Количество баллов за один комментарий
    }
    
    // Вставка новости в БД
    public function add_news($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('news', $array))
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Выборка новостей из БД
    public function get_news($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('news', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        return FALSE;
    }
    
    // Проверим есть ли данная новость в бд
    public function check_news($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('news');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        return FALSE;
    }
    
    // Карантин для новых пользователей
    public function quarantine_time()
    {
        // Пользовательские данные
        $data = $this->user->authorization();
        // Конфиг новостей
        $config = $this->config();
        // Сверяем дату регистрации
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        return FALSE;
    }
    
    // Вставка комментария в БД
    public function add_comments($array)
    { 
        if (is_array($array))
        {
            if ($this->db->insert('news_comments', $array))
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Выборка комментариев из БД
    public function get_comments($id = 0, $num , $offset)
    {
        if ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_news', $id);
            $query = $this->db->get('news_comments', $num, $offset);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        }
        return FALSE; 
    }
    
    // Количество комментариев по выбранной новости
    public function count_all_comments_id($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id_news', $id);
            $query = $this->db->get('news_comments');
            if ($query->num_rows() > 0) {
                return $query->num_rows();
            }
            return 0;
        }
        return 0; 
    }
    
    // Достаем отдельный комментарий из БД
    public function get_comments_id($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('news_comments');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
        }
        return FALSE; 
    }
    
    // Удаляем отдельный комментарий
    public function delete_comments_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('news_comments', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем комментарий
    public function update_comments_id($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('news_comments', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем новость
    public function update_news($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('news', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Узнаем можно ли голосовать
    public function check_vote_news($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND element('id', $data))
        {
            $this->db->where('id_news', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('news_vote');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
    }
    
    // Принимаем голос за новость
    public function vote_news_id($id = '')
    {
        $data = $this->user->authorization();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND element('id', $data))
        {
            if ($this->db->insert('news_vote', array('id_news' => $id, 'time' => now(), 'id_user' => $data['id'])))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Время Антифлуда
    public function antiflood_time()
    {
        // Пользовательские данные
        $data = $this->user->authorization();
        // Конфиг новостей
        $config = $this->config();
        // Сверяем дату последнего поста
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        return FALSE;
    }
    
    // Очистка комментариев
    public function trunce($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('news_comments', array('id_news' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление новости
    public function delete_news($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('news', array('id' => $id));
            $this->db->delete('news_comments', array('id_news' => $id));
            $this->db->delete('news_vote', array('id_news' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик новостей
    public function count_news()
    {
        $total = $this->db->count_all('news');
        
        $this->db->where('time > "' . (now() - 86400) . '"');
        $query = $this->db->get('news');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        return $total;
    }
    // Последние новости
    public function get_news_lasted()
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('news', 4);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        return FALSE;
    }
}