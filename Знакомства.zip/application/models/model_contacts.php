<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Contacts extends CI_Model
{
    // Настройки сообщений
    public function config()
    {
        return array(
            'quarantine_time' => 180, // Время карантина
            'antiflood_time' => 10, // Таймаут между отправкой комментариев
            'balls' => 10); // Количество баллов за один комментарий
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверит есть ли пользователь в списке контактов
    public function check_contacs_list_id_user($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    public function check_contacs_list_id_to($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция добавляет пользователя в список контактов
    public function add_contacts_id_user($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->insert('contacts_users', array('id_user' => $data['id'], 'id_to' => $id, 'time' => now(), 'read' => '0', 'list' => '0')); 
            //$this->db->insert('contacts_users', array('id_user' => $id, 'id_to' => $data['id'], 'time' => now(), 'read' => '0', 'list' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    public function add_contacts_id_to($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->insert('contacts_users', array('id_user' => $id, 'id_to' => $data['id'], 'time' => now(), 'read' => '0', 'list' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отправки сообщений
    public function sent_messages($id = '', $description = '')
    {
        $data = $this->user->authorization();
        if ($id === '' AND $description === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data) AND $description)
        {
            if ($this->db->insert('contacts_messages', array('id_user' => $data['id'], 'id_to' => $id, 'description' => $description, 'time' => now(), 'read' => '1')))
            {
                $this->db->where('id_user', $id);
                $this->db->where('id_to', $data['id']);
                $this->db->update('contacts_users', array('time' => now(), 'read' => '1'));
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все сообщения автора
    public function get_messages($id = '', $num, $offset)
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->or_where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $this->db->order_by('time', 'DESC');
            $query = $this->db->get('contacts_messages', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество сообщений в диалоге с автором 
    public function count_all_messages_id($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->or_where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $query = $this->db->get('contacts_messages');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Читаем все сообщения автор
    public function read_messages($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $this->db->update('contacts_messages', array('read' => '0'));
            
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->update('contacts_users', array('read' => '0'));
            
            
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Очистка переписки
    public function trunce_messages($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->delete('contacts_messages', array('id_user' => $data['id'], 'id_to' => $id));
            $this->db->delete('contacts_messages', array('id_user' => $id, 'id_to' => $data['id']));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик новых сообщений
    public function count_all_new_messages($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $this->db->where('read', '1');
            $query = $this->db->get('contacts_messages');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    public function count_all_new_messages_id($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $this->db->where('read', '1');
            $query = $this->db->get('contacts_messages');
            if ($query->num_rows() > 0) 
            {
                return '<span class="red">+ ' . $query->num_rows() . '</span>';
            }
            else
            {
                return 0;
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает новых авторов сообщений
    public function get_new_messages($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $this->db->where('read', '1');
            $query = $this->db->get('contacts_users', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик новых сообщений
    public function count_all_new_contacts($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $this->db->where('read', '1');
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик моих контактов
    public function count_all_contacts($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает контакты пользователя
    public function get_contacts($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('contacts_users', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Обновляем данные о контакте
    public function add_ignored($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->update('contacts_users', array('read' => '0', 'list' => '1'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка есть ли пользователь в списке игнора
    public function check_ignored($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $this->db->where('list', '1');
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Показ сссылки Игнор или КОнтакты
    public function check_contacts($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->where('list', '0');
            $query = $this->db->get('contacts_users');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем в список контактов
    public function add_contacted($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $this->db->update('contacts_users', array('read' => '0', 'list' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка сообщения
    public function check_messages($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id', $id);
            $this->db->where('id_to', $data['id']);
            $query = $this->db->get('contacts_messages');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление контакта
    public function delete_contcats($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            if ($this->db->delete('contacts_users', array('id_user' => $data['id'], 'id_to' => $id)))
            {
                $this->trunce_messages($id);
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
}