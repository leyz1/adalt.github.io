<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Seo extends CI_Model
{
    
    
    // Вывод дневников пользователя
    public function get_blog()
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('blog');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    
    // Функция выводит список последних активных тем
    public function get_topic()
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('forum_topic');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Пользователи
    public function get_users()
    {
        $this->db->where('delete', "0");
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
}