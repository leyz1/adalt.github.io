<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Functions extends CI_Model
{
    // Фильтрация форм
    public function htmlspecialchars($htmlspecialchars)
    {
        return htmlspecialchars(trim($htmlspecialchars), ENT_QUOTES, 'UTF-8');
    }
    
    // Фильтрация чисел
    public function abs($str)
    {
		return intval(abs(trim($str)));
    }
    
    // Проверка переменных
    public function variables($str)
    {
        // Удаляем лишние знаки препинания
        $str = preg_replace('#(\.|\?|!|\(|\)){3,}#', '\1\1\1', $str);

        // Фильтруем символы
        $str = nl2br($str);
        $str = preg_replace('!\p{C}!u', '', $str);
        $str = str_replace('<br />', "\n", $str);

        // Удаляем лишние пробелы
        $str = preg_replace('# {2,}#', ' ', $str);

        // Удаляем более 2-х переносов строк подряд
        $str = preg_replace("/(\n)+(\n)/i", "\n\n", $str);

        return trim($str);
    }
    
    // Проверка дня рождения
    public function day($day)
    {
        $day = $this->abs($day);
        if ($day < 1 || $day > 31 || !$day) 
        {
            return TRUE;
        } 
        else 
        {
            return FALSE;
        }
    }

    // Проверка месяца рождения
    public function month($month)
    {
        $month = $this->abs($month);
        if ($month < 1 || $month > 12 || !$month) 
        {
            return TRUE;
        } 
        else 
        {
            return FALSE;
        }
    }

    // Проверка года рождения
    public function year($year)
    {
        $year = $this->abs($year);
        if ($year < 1960 || $year > 2008 || !$year) 
        {
            return TRUE;
        } 
        else 
        {
            return FALSE;
        }
    }    
}