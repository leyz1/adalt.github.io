<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Forum extends CI_Model
{
    // Настройки форума
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls_comments' => 10, // Количество баллов за один комментарий
            'balls_topic' => 20, // Количество баллов за один созданный топик
            'moder' => TRUE); // Модерация топиков TRUE = Включена
    }
    
    // Функция возращает последнию позицию форума
    public function sort_forum()
    {
        $this->db->order_by('sort', 'DESC');
        $query = $this->db->get('forum', 1);
        if ($query->num_rows() > 0) 
        {
            $forum = $query->row_array();
            return trim($forum['sort'] + 1);
        }
        else
        {
            return 1;
        }                
    }
    
    // Функция добавляет новый подфорум в БД
    public function add_forum($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('forum', $array))
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Функция выбирает все форумы из БД
    public function get_forum($num, $offset)
    {
        $this->db->order_by('sort');
        $query = $this->db->get('forum', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        return FALSE;
    }
    
    // Функция проверяет существование форума в бд и возвращает ассоциативный массив с его данными
    public function check_forum($id = 0)
    {
        if ($id == 0)
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('forum');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Функция перемещаем форум на позицию выше
    public function up_forum($id = '')
    {
        $sort = '';
        $sort2 = '';
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            // Первая позиция
            $this->db->where('id', $id);
            $query = $this->db->get('forum', 1);
            if ($query->num_rows() > 0) 
            {
                $forum = $query->row_array();
                $sort = trim($forum['sort']);
            }
            // Вторая позиция
            $this->db->where('sort < "' . $sort . '"');
            $this->db->order_by('sort', 'DESC');
            $query = $this->db->get('forum', 1);
            if ($query->num_rows() > 0) 
            {
                $forum2 = $query->row_array();
                $sort2 = trim($forum2['sort']);
            }
            // Если некуда перемещать
            if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
            {
                return FALSE;
            }
            elseif ($sort2 > 0)
            {
                $this->db->where('id', $forum['id']);
                $this->db->update('forum', array('sort' => $sort2));
                $this->db->where('id', $forum2['id']);
                $this->db->update('forum', array('sort' => $sort));
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция перемещаем форум на позицию ниже
    public function down_forum($id = '')
    {
        $sort = '';
        $sort2 = '';
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            // Первая позиция
            $this->db->where('id', $id);
            $query = $this->db->get('forum', 1);
            if ($query->num_rows() > 0) 
            {
                $forum = $query->row_array();
                $sort = trim($forum['sort']);
            }
            // Вторая позиция
            $this->db->where('sort > "' . $sort . '"');
            $this->db->order_by('sort', 'ASC');
            $query = $this->db->get('forum', 1);
            if ($query->num_rows() > 0) 
            {
                $forum2 = $query->row_array();
                $sort2 = trim($forum2['sort']);
            }
            // Если некуда перемещать
            if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
            {
                return FALSE;
            }
            elseif ($sort2 > 0)
            {
                $this->db->where('id', $forum['id']);
                $this->db->update('forum', array('sort' => $sort2));
                $this->db->where('id', $forum2['id']);
                $this->db->update('forum', array('sort' => $sort));
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция возращает последнию позицию подкатегории в выбранном форуме
    public function sort_category($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_forum', $id);
            $this->db->order_by('sort', 'DESC');
            $query = $this->db->get('forum_category', 1);
            if ($query->num_rows() > 0) 
            {
                $category = $query->row_array();
                return trim($category['sort'] + 1);
            }
            else
            {
                return 1;
            }
        }
        else
        {
            return FALSE;
        }            
    }
    
    // Функция добавляет новую подкатегорию в форуме
    public function add_category($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('forum_category', $array))
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Функция выбирает все подкатегории в выбранном форуме
    public function get_category($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        if ($id > 0)
        {
            $this->db->where('id_forum', $id);
            $this->db->order_by('sort');
            $query = $this->db->get('forum_category', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество подкатегорий в выбранном форуме 
    public function count_all_category_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_forum', $id);
            $query = $this->db->get('forum_category');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверит сеществование подкатегории в бд и возвращает ассоциативный массив с её данными
    public function check_category($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        if ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('forum_category');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Функция перемещает подкатегорию на позицию выше
    public function up_category($array)
    {
        if (is_array($array))
        {
            if (element('id', $array) AND element('id_forum', $array))
            {
                $sort = '';
                $sort2 = '';
                if ($array['id'] === '' OR $array['id'] === NULL OR $array['id'] === FALSE OR $array['id'] == 0)
                {
                    return FALSE;
                }
                elseif ($array['id_forum'] === '' OR $array['id_forum'] === NULL OR $array['id_forum'] === FALSE OR $array['id_forum'] == 0)
                {
                    return FALSE;
                }
                elseif ($array['id'] > 0 AND $array['id_forum'] > 0)
                {
                    $this->db->where('id', $array['id']);
                    $this->db->where('id_forum', $array['id_forum']);
                    $query = $this->db->get('forum_category', 1);
                    if ($query->num_rows() > 0) 
                    {
                        $category = $query->row_array();
                        $sort = trim($category['sort']);
                    }
                    $this->db->where('id_forum', $array['id_forum']);
                    $this->db->where('sort < "' . $sort . '"');
                    $this->db->order_by('sort', 'DESC');
                    $query = $this->db->get('forum_category', 1);
                    if ($query->num_rows() > 0) 
                    {
                        $category2 = $query->row_array();
                        $sort2 = trim($category2['sort']);
                    }
                    // Если некуда перемещать
                    if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
                    {
                        return FALSE;
                    }
                    elseif ($sort2 > 0)
                    {
                        $this->db->where('id', $category['id']);
                        $this->db->update('forum_category', array('sort' => $sort2));
                        $this->db->where('id', $category2['id']);
                        $this->db->update('forum_category', array('sort' => $sort));
                        return TRUE;
                    }
                    else
                    {
                        return FALSE;
                    }
                }
                else
                {
                    return FALSE;
                } 
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция перемещает подкатегорию на позицию ниже
    public function down_category($array)
    {
        if (is_array($array))
        {
            if (element('id', $array) AND element('id_forum', $array))
            {
                $sort = '';
                $sort2 = '';
                if ($array['id'] === '' OR $array['id'] === NULL OR $array['id'] === FALSE OR $array['id'] == 0)
                {
                    return FALSE;
                }
                elseif ($array['id_forum'] === '' OR $array['id_forum'] === NULL OR $array['id_forum'] === FALSE OR $array['id_forum'] == 0)
                {
                    return FALSE;
                }
                elseif ($array['id'] > 0 AND $array['id_forum'] > 0)
                {
                    $this->db->where('id', $array['id']);
                    $this->db->where('id_forum', $array['id_forum']);
                    $query = $this->db->get('forum_category', 1);
                    if ($query->num_rows() > 0) 
                    {
                        $category = $query->row_array();
                        $sort = trim($category['sort']);
                    }
                    $this->db->where('id_forum', $array['id_forum']);
                    $this->db->where('sort > "' . $sort . '"');
                    $this->db->order_by('sort', 'ASC');
                    $query = $this->db->get('forum_category', 1);
                    if ($query->num_rows() > 0) 
                    {
                        $category2 = $query->row_array();
                        $sort2 = trim($category2['sort']);
                    }
                    // Если некуда перемещать
                    if ($sort2 === '' OR $sort2 === FALSE OR $sort2 === NULL OR $sort2 == 0)
                    {
                        return FALSE;
                    }
                    elseif ($sort2 > 0)
                    {
                        $this->db->where('id', $category['id']);
                        $this->db->update('forum_category', array('sort' => $sort2));
                        $this->db->where('id', $category2['id']);
                        $this->db->update('forum_category', array('sort' => $sort));
                        return TRUE;
                    }
                    else
                    {
                        return FALSE;
                    }
                }
                else
                {
                    return FALSE;
                } 
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция добавляет новую тему в бд
    public function add_topic($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('forum_topic', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество тем находящихся на модерации
    public function count_all_moder()
    {
        $this->db->where('moder', '1');
        $query = $this->db->get('forum_topic');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Функция выбирает все темы в выбранной подкатегории
    public function get_topic($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_category', $id);
            $this->db->where('moder', '0');
            $this->db->order_by('up', 'DESC');
            $this->db->order_by('time', 'DESC');
            $query = $this->db->get('forum_topic', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество тем в выбранной подкатегории
    public function count_all_topic_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_category', $id);
            $this->db->where('moder', '0');
            $query = $this->db->get('forum_topic');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверит сеществование выбранной темы в бд и возвращает ассоциативный массив с её данными
    public function check_topic($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('forum_topic');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Функция добавляет посты в бд
    public function add_post($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('forum_post', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все посты по выбранной теме
    public function get_post($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'ASC');
            $this->db->where('id_topic', $id);
            $query = $this->db->get('forum_post', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество постов в выбранной теме
    public function count_all_post_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_topic', $id);
            $query = $this->db->get('forum_post');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверит существование выбранного поста в бд и возвращает ассоциативный массив с его данными
    public function check_post($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('forum_post');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Функция удаляет отдельный пост из бд
    public function delete_post_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('forum_post', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция обновляет данные в выбранном посте
    public function edit_post($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('forum_post', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция обновляет данные в выбранной теме
    public function edit_topic($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('forum_topic', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция возвращает список форумов для перемещения
    public  function move_forum()
    {
        $this->db->order_by('sort');
        $query = $this->db->get('forum');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция возвращает спосок подкатегорий в выбранном форуме для перемещения
    public  function move_category($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('sort');
            $this->db->where('id_forum', $id);
            $query = $this->db->get('forum_category');
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция перемещения темы
    public function moved($id, $array)
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('forum_topic', array('id_forum' => $array['id_forum'], 'id_category' => $array['id']));
            $this->db->where('id_topic', $id);
            $this->db->update('forum_post', array('id_forum' => $array['id_forum'], 'id_category' => $array['id']));
            $this->db->where('id_topic', $id);
            $this->db->update('forum_bookmark', array('id_forum' => $array['id_forum'], 'id_category' => $array['id']));
            // Оптимизация
            $this->dbutil->optimize_table('forum_topic');
            $this->dbutil->optimize_table('forum_post');
            $this->dbutil->optimize_table('forum_bookmark');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция проверит сущетвование темы в закладках
    public function check_bookmark($id = '')
    {
        $id_user = $this->user->id();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_user > 0)
        {
            $this->db->where('id_topic', $id);
            $this->db->where('id_user', $id_user);
            $query = $this->db->get('forum_bookmark');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция добавляет тему в закладки
    public function add_bookmark($array)
    {
        $this->load->dbutil();
        $id_user = $this->user->id();
        if ($array['id'] === '')
        {
            return FALSE;
        }
        elseif (is_array($array) > 0 AND $id_user > 0)
        {
            if ($this->db->insert('forum_bookmark', array('id_forum' => $array['id_forum'], 'id_category' => $array['id_category'], 'id_topic' => $array['id'], 'id_user' => $id_user, 'time' => now(), 'up' => '0')))
            {
                $this->dbutil->optimize_table('forum_bookmark');
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция удаляет выбранную тему из закладок
    public function delete_bookmark($id = '')
    {
        $this->load->dbutil();
        $id_user = $this->user->id();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_user > 0)
        {
            if ($this->db->delete('forum_bookmark', array('id_topic' => $id, 'id_user' => $id_user)))
            {
                $this->dbutil->optimize_table('forum_bookmark');
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция полного удаления выбранной темы из бд
    public function delete_topic($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('forum_topic', array('id' => $id)))
            {
                $this->db->delete('forum_post', array('id_topic' => $id));
                $this->db->delete('forum_bookmark', array('id_topic' => $id));
                // Оптимизация
                $this->dbutil->optimize_table('forum_topic');
                $this->dbutil->optimize_table('forum_post');
                $this->dbutil->optimize_table('forum_bookmark');
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция чистки постов в выбранной теме
    public function trunce($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('forum_post', array('id_topic' => $id));
            $this->dbutil->optimize_table('forum_post');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество тем в закладках выбранного пользователя
    public function count_all_bookmark_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('forum_bookmark');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все темы в закладках пользователя
    public function get_bookmark($id, $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('up');
            $this->db->where('id_user', $id);
            $query = $this->db->get('forum_bookmark', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция чтения закладки
    public function read_bookmark($id = '')
    {
        $id_user = $this->user->id();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_user > 0)
        {
            $this->db->where('id_topic', $id);
            $this->db->where('id_user', $id_user);
            $this->db->update('forum_bookmark', array('up' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция обновляет данные в закладках по выбранной теме
    public function up_bookmark($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_topic', $id);
            $this->db->update('forum_bookmark', array('up' => 1));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает список тем находящихся на модерации
    public function get_topic_moderation($num, $offset)
    {
        $this->db->where('moder', '1');
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('forum_topic', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Функция выбирает все темы выбранного пользователя
    public function get_my_topic($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('forum_topic', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество тем пользователя
    public function count_all_my_topic($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('forum_topic');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция отображает количество тем на форуме
    public function count_all_active_topic()
    {
        $this->db->where('moder', '0');
        $query = $this->db->get('forum_topic');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Функция выводит список активных тем
    public function get_active_topic($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('forum_topic', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Функция бновляет данные в выбранной подкатегории
    public function edit_category($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('forum_category', $array);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция полного удаления выбранной подкатегории
    public function delete_category($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('forum_category', array('id' => $id)))
            {
                $this->db->delete('forum_topic', array('id_category' => $id));
                $this->db->delete('forum_post', array('id_category' => $id));
                $this->db->delete('forum_bookmark', array('id_category' => $id));
                // Оптимизация
                $this->dbutil->optimize_table('forum_category');
                $this->dbutil->optimize_table('forum_topic');
                $this->dbutil->optimize_table('forum_post');
                $this->dbutil->optimize_table('forum_bookmark');
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция обновляет данные в выбранном форуме
    public function edit_forum($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('forum', $array);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция полного удаления выбранного форума
    public function delete_forum($id = '')
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('forum', array('id' => $id)))
            {
                $this->db->delete('forum_category', array('id_forum' => $id));
                $this->db->delete('forum_topic', array('id_forum' => $id));
                $this->db->delete('forum_post', array('id_forum' => $id));
                $this->db->delete('forum_bookmark', array('id_forum' => $id));
                // Оптимизация
                $this->dbutil->optimize_table('forum_category');
                $this->dbutil->optimize_table('forum_topic');
                $this->dbutil->optimize_table('forum_post');
                $this->dbutil->optimize_table('forum_bookmark');
                $this->dbutil->optimize_table('forum');
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выводит список найденных тем в результате поиска
    public function get_search($search = '', $num, $offset)
    {
        if ($search === '')
        {
            return FALSE;
        }
        elseif ($search)
        {
            $this->db->like('title', $search);
            $query = $this->db->get('forum_topic', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return TRUE;
        }
    }
    
    // Функция отображает количество найденных тем в результате поиска
    public function count_all_search($search = '')
    {
        if ($search === '')
        {
            return 0;
        }
        elseif ($search)
        {
            $this->db->like('title', $search);
            $query = $this->db->get('forum_topic');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    
    // Функция отображает список тем на форуме + новые темы за сутки
    public function count_all_topic()
    {
        $total = $this->db->count_all('forum_topic');
        
        $this->db->where('moder', '0');
        $this->db->where('time_create >= "' . (now() - 86400) . '"');
        $query = $this->db->get('forum_topic');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        return $total;
    }
    

    
    // Функция выводит список последних активных тем
    public function get_last_active_topic()
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('forum_topic', 3);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
}