<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_City extends CI_Model
{
    // Парсинг стран из БД
    public function get_country($num, $offset)
    {
        $query = $this->db->get('country_', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка страны
    public function check_country($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('country_');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE; 
            }
        }
        else
        {
            return FALSE; 
        }
    }
    
     // Количество регионов в стране
    public function count_all_region($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_country', $id);
            $query =  $this->db->get('region_');
            if ($query->num_rows() > 0)
            {
                return $query->num_rows();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Парсинг регионов по связке со страной
    public function get_region($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_country', $id);
            $query = $this->db->get('region_', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка региона
    public function check_region($id = '', $id_country = '')
    {
        if ($id === '' AND $id_country === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_country > 0)
        {
            $this->db->where('id', $id);
            $this->db->where('id_country', $id_country);
            $this->db->select('id, region_name_ru');
            $query = $this->db->get('region_');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество городов в регионе + привязка страны
    public function count_all_city($id_region = '', $id_country = '')
    {
        if ($id_region === '' AND $id_country === '')
        {
            return FALSE;
        }
        elseif ($id_region > 0 AND $id_country > 0)
        {
            $this->db->where('id_region', $id_region);
            $this->db->where('id_country', $id_country);
            $query =  $this->db->get('city_');
            if ($query->num_rows() > 0)
            {
                return $query->num_rows();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Парсинг городов по связке регион + страна
    public function get_city($id_region = '', $id_country = '', $num, $offset)
    {
        if ($id_region === '' AND $id_country === '')
        {
            return FALSE;
        }
        elseif ($id_region > 0 AND $id_country > 0)
        {
            $this->db->where('id_region', $id_region);
            $this->db->where('id_country', $id_country);
            $query =  $this->db->get('city_', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка города
    public function check_city($id = '', $id_region = '', $id_country = '')
    {
        if ($id === '' AND $id_region === '' AND $id_country === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_region > 0 AND $id_country > 0)
        {
            $this->db->where('id', $id);
            $this->db->where('id_region', $id_region);
            $this->db->where('id_country', $id_country);
            $query = $this->db->get('city_');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            } 
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция выводит список найденных городов в результате поиска
    public function get_search($search = '', $num, $offset)
    {
        if ($search === '')
        {
            return FALSE;
        }
        elseif ($search)
        {
            $this->db->like('city_name_ru', $search);
            $query = $this->db->get('city_', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return TRUE;
        }
    }
    
    // Функция отображает количество найденных тем в результате поиска
    public function count_all_search($search = '')
    {
        if ($search === '')
        {
            return 0;
        }
        elseif ($search)
        {
            $this->db->like('city_name_ru', $search);
            $query = $this->db->get('city_');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    
    // Проверка города для поиска
    public function check_search_city($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('city_');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE; 
            }
        }
        else
        {
            return FALSE;
        }
    }
}