<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Photo extends CI_Model
{
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls_comments' => 10, // Количество баллов за один комментарий
            'balls_photo' => 20); // Количество баллов за одиу выгружену фотку
    }
    
    // Функция добавляет информацию о новом фот в БД
    public function add_photo($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('photo', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод фотографий пользователя
    public function get_photo($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('photo', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество фото у пользователя
    public function count_all_photo_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('photo');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Узнаем можно ли голосовать
    public function check_vote_photo($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_photo', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('photo_vote');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
    }
    
    // Проверим есть ли такая фотография
    public function check_photo($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('photo');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Принимаем голос за новость
    public function add_vote_photo_id($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            if ($this->db->insert('photo_vote', array('id_photo' => $id, 'time' => now(), 'id_user' => $data['id'])))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем фото
    public function update_photo($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('photo', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вставка комментария в БД
    public function add_comments($array)
    { 
        if (is_array($array))
        {
            if ($this->db->insert('photo_comments', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка комментариев из БД
    public function get_comments($id = 0, $num , $offset)
    {
        if ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_photo', $id);
            $query = $this->db->get('photo_comments', $num, $offset);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        }
        return FALSE; 
    }
    
    // Количество комментариев по выбранной новости
    public function count_all_comments_id($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id_photo', $id);
            $query = $this->db->get('photo_comments');
            if ($query->num_rows() > 0) {
                return $query->num_rows();
            }
            return 0;
        }
        return 0; 
    }
    
    // Достаем отдельный комментарий из БД
    public function get_comments_id($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('photo_comments');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
        }
        return FALSE; 
    }
    
    // Удаляем отдельный комментарий
    public function delete_comments_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('photo_comments', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество промодерированных фото
    public function count_all_photo_moder($gender = 'm')
    {
        $this->db->where('gender', $gender);
        $this->db->where('moder', '0');
        $query = $this->db->get('photo');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Количество фото на модерации
    public function count_all_photo_moderations()
    {
        $this->db->where('moder', '1');
        $query = $this->db->get('photo');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    public function count_all_photo()
    {
        $this->db->where('moder', '0');
        $query = $this->db->get('photo');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Выборка фото для модерации
    public function get_photo_moderations($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '1');
        $query = $this->db->get('photo', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление фото
    public function delete_photo($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('photo', array('id' => $id));
            $this->db->delete('photo_comments', array('id_photo' => $id));
            $this->db->delete('photo_vote', array('id_photo' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка фото парней
    public function get_photo_boy($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'm');
        $this->db->where('moder', '0');
        $query = $this->db->get('photo', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка фото дувушек
    public function get_photo_girl($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'w');
        $this->db->where('moder', '0');
        $query = $this->db->get('photo', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function get_photo_chart($num , $offset)
    {
        $this->db->order_by('rating', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('photo', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function count_photo()
    {
        $total = $this->count_all_photo();
        
        $this->db->where('time > "' . (now() - 86400) . '"');
        $this->db->where('moder', '0');
        $query = $this->db->get('photo');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
}