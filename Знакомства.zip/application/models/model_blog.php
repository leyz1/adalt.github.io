<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Blog extends CI_Model
{
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls_comments' => 10, // Количество баллов за один комментарий
            'balls_blog' => 20); // Количество баллов за одиу запись
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем дневник
    public function add_blog($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('blog', $array))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод дневников пользователя
    public function get_blog_id_user($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('blog', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество дневников у пользователя
    public function count_all_blog_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('blog');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Узнаем можно ли голосовать
    public function check_vote_blog($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_blog', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('blog_vote');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
    }
    
    // Проверка дневника
    public function check_blog($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('blog');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Принимаем голос
    public function add_vote_blog($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            if ($this->db->insert('blog_vote', array('id_blog' => $id, 'time' => now(), 'id_user' => $data['id'])))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем блог
    public function edit_blog($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('blog', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем файлы
    public function add_files($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('blog_files', $array))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количечтво файлов в блоге
    public function count_all_blog_files($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_blog', $id);
            $query = $this->db->get('blog_files');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод файлов блога
    public function get_blog_files($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_blog', $id);
            $query = $this->db->get('blog_files', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка файла
    public function check_file_id_user($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('blog_files');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление файла
    public function delete_file($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('blog_files', array('id' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем комментарии
    public function add_comments($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('blog_comments', $array))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка комментариев
    public function get_blog_commments($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_blog', $id);
            $query = $this->db->get('blog_comments', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество комментариев в дневнике
    public function count_all_blog_comments($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_blog', $id);
            $query = $this->db->get('blog_comments');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка поста
    public function check_comments($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('blog_comments');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление комментария
    public function delete_comments($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('blog_comments', array('id' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление дневника
    public function delete_blog($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('blog', array('id' => $id));
            $this->db->delete('blog_comments', array('id_blog' => $id));
            $this->db->delete('blog_files', array('id_blog' => $id));
            $this->db->delete('blog_vote', array('id_blog' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик дневников
    public function count_all_blog()
    {
        $this->db->where('moder', '0');
        $query = $this->db->get('blog');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    public function count_blog()
    {
        $total = $this->count_all_blog();
        
        $this->db->where('time > "' . (now() - 86400) . '"');
        $this->db->where('moder', '0');
        $query = $this->db->get('blog');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
    
    // Количество фото на модерации
    public function count_all_blog_moderations()
    {
        $this->db->where('moder', '1');
        $query = $this->db->get('blog');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Количество промодерированных фото
    public function count_all_blog_moder($gender = 'm')
    {
        $this->db->where('gender', $gender);
        $this->db->where('moder', '0');
        $query = $this->db->get('blog');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Выборка фото для модерации
    public function get_blog_moderations($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '1');
        $query = $this->db->get('blog', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function get_blog_chart($num , $offset)
    {
        $this->db->order_by('rating', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('blog', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function get_blog_boy($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'm');
        $this->db->where('moder', '0');
        $query = $this->db->get('blog', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function get_blog_girl($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'w');
        $this->db->where('moder', '0');
        $query = $this->db->get('blog', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Последние дневы
    public function get_blog_lasted()
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '0');
        $query = $this->db->get('blog', 3);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
}