<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Wall extends CI_Model
{
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls_comments' => 10); // Количество баллов за один комментарий
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Новая запись на стене
    public function add_wall($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('wall', $array))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод записей на стене
    public function get_wall($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('wall', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Проверка поста
    public function check_comments($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('wall');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление отдельной записи
    public function delete_wall_post($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('wall', array('id' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция запишет кто есть к комнате
    public function add_who_wall($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('wall_who', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция удаляет пользователя с комнаты
    public function delete_who_wall_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('wall_who', array('id_user' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция удаляет всех пользователей с комнаты за 10 минут
    public function delete_who_wall($id = '')
    {
        $this->db->where('time < "' . (now() - 600) . '"');
        $this->db->delete('wall_who');
        return TRUE;
    }
    
    // Фугкция выводит список пользователей в комнате
    public function get_who_wall($num, $offset)
    {
        $query = $this->db->get('wall_who', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    public function count_wall()
    {
        $total = $this->db->count_all('wall');
        
        $this->db->where('time > "' . (now() - 86400) . '"');
        $query = $this->db->get('wall');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
}