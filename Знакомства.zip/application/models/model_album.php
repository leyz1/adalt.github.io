<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Album extends CI_Model
{
    public function config()
    {
        return array(
            'access' => FALSE, // Доступ к модулю
            'quarantine_time' => 600, // Время карантина
            'antiflood_time' => 30, // Таймаут между отправкой комментариев
            'balls_comments' => 10, // Количество баллов за один комментарий
            'balls_photo' => 20); // Количество баллов за одиу выгружену фотку
    }
    
    // Добавляем альбом в бд
    public function add_album($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('album', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка фотоальбомов
    public function get_album($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time_create', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('album', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик альбомов у пользователя
    public function count_all_album_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('album');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    public function check_album($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('album');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка фото
    public function check_photo($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('album_photo');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка фото из альбома
    public function get_photo($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_album', $id);
            $query = $this->db->get('album_photo', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик фотографий в альбоме
    public function count_all_album_photo($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_album', $id);
            $query = $this->db->get('album_photo');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем фото в базу
    public function add_photo($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('album_photo', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем альбом
    public function update_album($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }  
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('album', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем фото
    public function update_photo($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('album_photo', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Узнаем можно ли голосовать
    public function check_vote_photo($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_photo', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('album_photo_vote');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
    }
    
    // Принимаем голос за новость
    public function add_vote_photo_id($id = '', $id_album = '')
    {
        $data = $this->user->authorization();
        if ($id === '' AND $id_album === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_album > 0 AND is_array($data))
        {
            if ($this->db->insert('album_photo_vote', array('id_album' => $id_album, 'id_photo' => $id, 'time' => now(), 'id_user' => $data['id'])))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция карантина для новых пользователей
    public function quarantine_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $quarantine_time = $data['date_registration'] + $config['quarantine_time'] - now();
        if ($quarantine_time > 0)
        {
            return trim($quarantine_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Функция антифлуда
    public function antiflood_time()
    {
        $data = $this->user->authorization();
        $config = $this->config();
        $antiflood_time = $data['date_last_post'] + $config['antiflood_time'] - now();
        if ($antiflood_time > 0)
        {
            return trim($antiflood_time);
        }
        else
        {
            return FALSE;
        }
    }
    
    public function count_all_comments_id($id = 0)
    {
        if ($id > 0)
        {
            $this->db->where('id_photo', $id);
            $query = $this->db->get('album_photo_comments');
            if ($query->num_rows() > 0) {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка комментариев из БД
    public function get_comments($id = 0, $num , $offset)
    {
        if ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_photo', $id);
            $query = $this->db->get('album_photo_comments', $num, $offset);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вставка комментария в БД
    public function add_comments($array)
    { 
        if (is_array($array))
        {
            if ($this->db->insert('album_photo_comments', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Достаем отдельный комментарий из БД
    public function get_comments_id($id = 0)
    {
        if ($id === 0)
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('album_photo_comments');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        } 
    }
    
    // Удаляем отдельный комментарий
    public function delete_comments_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('album_photo_comments', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление фото
    public function delete_photo($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('album_photo', array('id' => $id));
            $this->db->delete('album_photo_comments', array('id_photo' => $id));
            $this->db->delete('album_photo_vote', array('id_photo' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление альбома
    public function delete_album($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('album', array('id' => $id));
            $this->db->delete('album_photo', array('id_album' => $id));
            $this->db->delete('album_photo_comments', array('id_album' => $id));
            $this->db->delete('album_photo_vote', array('id_album' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество фото на модерации
    public function count_all_photo_moderations()
    {
        $this->db->where('moder', '1');
        $query = $this->db->get('album_photo');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Выборка фото для модерации
    public function get_photo_moderations($num , $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('moder', '1');
        $query = $this->db->get('album_photo', $num, $offset);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка фотоальбомов
    public function get_album_boy($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'm');
        $query = $this->db->get('album', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик альбомов у пользователя
    public function count_all_album_boy()
    {
        $this->db->where('gender', 'm');
        $query = $this->db->get('album');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Выборка фотоальбомов
    public function get_album_girl($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('gender', 'w');
        $query = $this->db->get('album', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик альбомов у пользователя
    public function count_all_album_girl()
    {
        $this->db->where('gender', 'w');
        $query = $this->db->get('album');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    public function count_album()
    {
        $total = $this->db->count_all('album');
        
        $this->db->where('time_create > "' . (now() - 86400) . '"');
        $query = $this->db->get('album');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
}