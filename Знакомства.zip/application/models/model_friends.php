<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Friends extends CI_Model
{
    // Проверка на добавления в друзья
    public function check_add_friends($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($data = $this->user->parse_id($id))
            {
                if ($data['add_friends'] == 1)
                {
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем в друзья
    public function add_friends($id = '', $toward = 0)
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->insert('friends_add', array('id_user' => $data['id'], 'id_to' => $id, 'time' => now(), 'toward' => $toward));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка нет ли исходящей заявки
    public function check_sent_friend($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $query = $this->db->get('friends_add');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка нет ли входящей заявки
    public function check_inbox_friends($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $id);
            $this->db->where('id_to', $data['id']);
            $query = $this->db->get('friends_add');
            if ($query->num_rows() > 0)
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка на дружбу
    public function check_friends($id = '')
    {
        $data = $this->user->authorization();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $query = $this->db->get('friends_users');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаляем заявку  вдрузья
    public function delete_app_friends($id)
    {
        $data = $this->user->authorization();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->delete('friends_add', array('id_user' => $data['id'], 'id_to' => $id));
            $this->db->delete('friends_add', array('id_user' => $id, 'id_to' => $data['id']));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Подтверждаем заявку в друзья
    public function add_app_friends($id = '', $toward = 0)
    {
        $data = $this->user->authorization();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->insert('friends_users', array('id_user' => $data['id'], 'id_to' => $id, 'time' => now(), 'toward' => $toward)); 
            $this->db->insert('friends_users', array('id_user' => $id, 'id_to' => $data['id'], 'time' => now(), 'toward' => $toward));
            $this->delete_app_friends($id);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Список входящих заявок в друзья
    public function get_app_friends($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $this->db->order_by('time', 'DESC');
            $query = $this->db->get('friends_add', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик входящих заявок
    public function count_all_app_friends($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $query = $this->db->get('friends_add');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Список друзей
    public function get_friends($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $this->db->order_by('time', 'DESC');
            $query = $this->db->get('friends_users', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик друзей
    public function count_all_friends($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $query = $this->db->get('friends_users');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаляем из друзей
    public function delete_friends($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->delete('friends_users', array('id_user' => $data['id'], 'id_to' => $id));
            $this->db->delete('friends_users', array('id_user' => $id, 'id_to' => $data['id']));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}