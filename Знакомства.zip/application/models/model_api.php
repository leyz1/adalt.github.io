<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Api extends CI_Model
{
    public function config()
    {
        return array(
            'WMR' => 'R000000000001',
            'WMZ' => 'Z000000000001', 
            'balls_comments' => 3, // ���������� ������ �� ���� �����������
            'balls_photo' => 20); // ���������� ������ �� ���� ��������� �����
    }
     
    // ��������� ������ � ��
    public function add_country($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('sms_country', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // ��������� �����
    public function add_tarif($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('sms_tarif', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // �������� ������
    public function check_country($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('sms_country');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE; 
            }
        }
        else
        {
            return FALSE; 
        }
    }
    
    // �������� �������
    public function check_tarif($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('sms_tarif');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE; 
            }
        }
        else
        {
            return FALSE; 
        }
    }
    
    // ������� ����� �� ��
    public function get_country($num, $offset)
    {
        $query = $this->db->get('sms_country', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // ������� ��������� ������ � ������
    public function edit_country($id = '', $array)
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('sms_country', $array); 
            // �����������
            $this->dbutil->optimize_table('sms_country');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // �������������� ������
    public function edit_tarif($id = '', $array)
    {
        $this->load->dbutil();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('sms_tarif', $array); 
            // �����������
            $this->dbutil->optimize_table('sms_tarif');
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // ���������� ������� ��� ��������
    public function count_all_number($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_sms_country', $id);
            $query = $this->db->get('sms_tarif');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // ������� �������
    public function get_tarif_id_country($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('id', 'DESC');
            $this->db->where('id_sms_country', $id);
            $query = $this->db->get('sms_tarif', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // �������� ������
    public function delete_tarif($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('sms_tarif', array('id' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // �������� ������
    public function delete_country($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            if ($this->db->delete('sms_country', array('id' => $id)))
            {
                $this->db->delete('sms_tarif', array('id_sms_country' => $id));
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
}