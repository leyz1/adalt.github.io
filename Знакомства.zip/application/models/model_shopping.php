<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Shopping extends CI_Model
{
    // Добавляем каталог
    public function add_catalog($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('shopping', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка каталогов
    public function get_shopping($num, $offset)
    {
        $query = $this->db->get('shopping', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Проверка каталога
    public function check_shopping($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('shopping');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем каталог
    public function edit_shopping($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('shopping', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем подарок
    public function add_gift($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('shopping_gift', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Редактируем подарок
    public function edit_gift($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('shopping_gift', $array); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество подарков в каталоге
    public function count_all_shopping_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_catalog', $id);
            $query = $this->db->get('shopping_gift');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выбор подарков из категории
    public function get_shopping_gift($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_catalog', $id);
            $query = $this->db->get('shopping_gift', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка подарка
    public function check_gift($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('shopping_gift');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Делаем покупку
    public function add_cart($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('shopping_cart', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество покупок у пользователя
    public function count_all_cart_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('shopping_cart');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка покупок
    public function get_present($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('shopping_cart', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка покупки
    public function check_present($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id', $id);
            $this->db->where('id_user', $data['id']);
            $query = $this->db->get('shopping_cart');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление покупки
    public function delete_cart($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->delete('shopping_cart', array('id' => $id, 'id_user' => $data['id']));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Отправка подарка
    public function add_present($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('shopping_user', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество подарков у пользователя
    public function count_all_gift_id_user($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $query = $this->db->get('shopping_user');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выборка подарков
    public function get_gift($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_to', $id);
            $query = $this->db->get('shopping_user', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка подарка пользователя
    public function check_gift_id_user($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->where('id', $id);
            $this->db->where('id_to', $data['id']);
            $query = $this->db->get('shopping_user');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление подарка
    public function delete_gift_id_user($id = '')
    {
        $data = $this->user->authorization();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $this->db->delete('shopping_user', array('id' => $id, 'id_to' => $data['id']));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаление подарка
    public function delete_gift($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('shopping_gift', array('id' => $id));
            $this->db->delete('shopping_cart', array('id_gift' => $id));
            $this->db->delete('shopping_user', array('id_gift' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Полное удаление категории
    public function delete_catalog($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('shopping', array('id' => $id));
            $this->db->delete('shopping_cart', array('id_catalog' => $id));
            $this->db->delete('shopping_gift', array('id_catalog' => $id));
            $this->db->delete('shopping_user', array('id_catalog' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество подарков в каталоге
    public function count_all_shopping_chart()
    {
        $query = $this->db->get('shopping_gift');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Выбор подарков из категории
    public function get_shopping_chart($num, $offset)
    {
        $this->db->order_by('shopping', 'DESC');
        $query = $this->db->get('shopping_gift', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }  
    }
    
    public function get_shopping_new($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('shopping_gift', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }  
    }
}
