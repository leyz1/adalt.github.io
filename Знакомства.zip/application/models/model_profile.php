<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_Profile extends CI_Model
{
    // Телефонные коды стран
    public function get_country_phone_code()
    {
        $this->db->order_by('TitleRU');
        $query = $this->db->get('Sample_CountryPhoneCode');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Проверка телефонного кода страны
    public function check_country_phone_code($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('ID', $id);
            $query = $this->db->get('Sample_CountryPhoneCode');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Список тем оформления
    public function get_style()
    {
        return $map = directory_map('./styles/', TRUE);
    }
    
    // Проверяем есть ли пользователь в черном списке
    public function check_ignore($id)
    {
        $data = $this->user->authorization();
        if ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_ignore', $id);
            $query = $this->db->get('users_ignore');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем в черный список
    public function add_ignore($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('users_ignore', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выводим список поьзователей в черном списке
    public function get_ignore($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_user', $id);
            $query = $this->db->get('users_ignore', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество пользователей в черном списе
    public function count_all_ignore($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('users_ignore');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            } 
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаляем с черного списка
    public function delete_ignore($id = '')
    {
        $data = $this->user->authorization();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            if ($this->db->delete('users_ignore', array('id_user' => $data['id'], 'id_ignore' => $id)))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверим есть ли пользователь в срискке гостей
    public function check_guest($id)
    {
        $data = $this->user->authorization();
        if ($id > 0 AND is_array($data))
        {
            $this->db->where('id_user', $data['id']);
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_guest');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Добавляем в список гостей
    public function add_guest($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('users_guest', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Обновляем время гостя
    public function edit_guest($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $this->db->update('users_guest', array('time' => now(), 'read' => '1'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Выводим список гостей
    public function get_guest($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_guest', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество гостей
    public function count_all_guest_id_to($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_guest');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    public function count_all_guest($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $total = $this->count_all_guest_id_to($id);
        
            $this->db->where('read', '1');
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_guest');
            if ($query->num_rows() > 0)
            {
                return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
            }
            return $total;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод записей журнала событий
    public function get_journal($id = '', $num, $offset)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->order_by('time', 'DESC');
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_journal', $num, $offset);
            if ($query->num_rows() > 0) 
            {
                return $query->result_array();
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество записей в журнале
    public function count_all_journal_id($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_journal');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик записей в журнале
    public function count_all_journal($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $total = $this->count_all_journal_id($id);
        
            $this->db->where('read', '1');
            $this->db->where('id_to', $id);
            $query = $this->db->get('users_journal');
            if ($query->num_rows() > 0)
            {
                return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
            }
            return $total;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Отправка уведомлений в журнал
    public function add_journal($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('users_journal', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Читаем журнал
    public function read_journal($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $this->db->update('users_journal', array('read' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    //Читаем гостей
    public function read_guest($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_to', $id);
            $this->db->update('users_guest', array('read' => '0'));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    // Очистка журнала
    public function trunce_journal()
    {
        $id_user = $this->user->id();
        if ($id_user > 0)
        {
            $this->db->delete('users_journal', array('id_to' => $id_user));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Очистка гостей
    public function trunce_guest()
    {
        $id_user = $this->user->id();
        if ($id_user > 0)
        {
            $this->db->delete('users_guest', array('id_to' => $id_user));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    // Отправка уведомлений о спаме
    public function add_spam($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('users_spam', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод записей журнала событий
    public function get_spam($num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $query = $this->db->get('users_spam', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        } 
        else
        {
            return FALSE;
        }
    }
    
    // Читаем журнал
    public function read_spam()
    {
        $this->db->update('users_spam', array('read' => '0'));
        return TRUE;
    }
    
    public function trunce_spam()
    {
        $this->db->truncate('users_spam');
        return TRUE;
    }
    
    // Счетчик записей в журнале
    public function count_all_spam()
    {
        $total = $this->db->count_all('users_spam');
        $this->db->where('read', '1');
        $query = $this->db->get('users_spam');
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
    
    // Пользователи на сайте
    public function get_user_online($num, $offset)
    {
        $this->db->order_by('date_star_search', 'DESC');
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Парни в сети
    public function get_online_boy($num, $offset)
    {
        $this->db->where('gender', 'm');
        $this->db->order_by('date_star_search', 'DESC');
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return 0;
        }
    }
    
    // Девушки в сети
    public function get_online_girl($num, $offset)
    {
        $this->db->where('gender', 'w');
        $this->db->order_by('date_star_search', 'DESC');
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return 0;
        }
    }
    
    // Счетчик пользователей на сайте
    public function count_user_online()
    {
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Парни в сети
    public function count_online_boy()
    {
        $this->db->where('gender', 'm');
        $this->db->order_by('id', 'DESC');
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Девушки в сети
    public function count_online_girl()
    {
        $this->db->where('gender', 'w');
        $this->db->order_by('id', 'DESC');
        $this->db->where('date_login > "' . (now() - 600) . '"');
        $this->db->where('delete', "0");
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Вывод пользователей
    public function get_users($num, $offset)
    {
        $this->db->order_by('id', 'DESC');
        $this->db->where('delete', "0");
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    public function count_users()
    {
        $total = $this->db->count_all('users');
        
        $this->db->where('date_registration > "' . (now() - 86400) . '"');
        $query = $this->db->get('users');
        
        if ($query->num_rows() > 0)
        {
            return $total . ' <span class="red"> + ' . $query->num_rows() . '</span>';
        }
        else
        {
            return $total;
        }
    }
    
    public function add_ban($array)
    {
        if (is_array($array))
        {
            if ($this->db->insert('users_ban', $array))
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    public function get_users_ban($id = '', $num, $offset)
    {
        $this->db->order_by('time', 'DESC');
        $this->db->where('id_user', $id);
        $query = $this->db->get('users_ban', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Количество нарушений
    public function count_all_ban($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id_user', $id);
            $query = $this->db->get('users_ban');
            if ($query->num_rows() > 0) 
            {
                return $query->num_rows();
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Обнуляем бан
    public function nulled_ban($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $this->db->update('users_ban', array('time' => now()));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Список банов
    public function count_all_banan()
    {
        $this->db->distinct();
        $this->db->select('id_user');
        $query = $this->db->get('users_ban');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Вывод забаненых
    public function get_users_banan($num, $offset)
    {
        $this->db->distinct();
        $this->db->select('id_user');
        $query = $this->db->get('users_ban');
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Удаляем бан
    public function delete_ban($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->delete('users_ban', array('id' => $id));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    public function check_baned($id = '')
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0)
        {
            $this->db->where('id', $id);
            $query = $this->db->get('users_ban');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Вывод результатов поиска
    public function get_search($data = array(), $num, $offset)
    {
        
        $this->db->where('gender', $data['gender']);
        
        if (element('city', $data))
            $this->db->like('city', $data['city']);
            
        if (element('sex_orient', $data))
            $this->db->where('sex_orient', $data['sex_orient']);
            
        if (element('getting_target1', $data))
            $this->db->where('getting_target1', $data['getting_target1']);   
        
        if (element('getting_target2', $data))
            $this->db->where('getting_target2', $data['getting_target2']); 
        
        if (element('getting_target3', $data))
            $this->db->where('getting_target3', $data['getting_target3']); 
            
        if (element('getting_target4', $data))
            $this->db->where('getting_target4', $data['getting_target4']); 

        if (element('getting_target5', $data))
            $this->db->where('getting_target5', $data['getting_target5']); 
            
        if (element('getting_target6', $data))
            $this->db->where('getting_target6', $data['getting_target6']); 
            
        if (element('family', $data))
            $this->db->where('family', $data['family']);
        
        if (element('sex_skill ', $data))
            $this->db->where('sex_skill ', $data['sex_skill ']);
            
        $this->db->where('delete', "0");           
        $this->db->order_by('date_anketa_up', 'DESC');
          
        $query = $this->db->get('users', $num, $offset);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Счетчик пользователей
    public function count_search($data = array())
    {
        $this->db->where('gender', $data['gender']);
        
        if (element('city', $data))
            $this->db->like('city', $data['city']);
            
        if (element('sex_orient', $data))
            $this->db->where('sex_orient', $data['sex_orient']);
            
        if (element('getting_target1', $data))
            $this->db->where('getting_target1', $data['getting_target1']);
        
        if (element('getting_target2', $data))
            $this->db->where('getting_target2', $data['getting_target2']); 
        
        if (element('getting_target3', $data))
            $this->db->where('getting_target3', $data['getting_target3']); 
            
        if (element('getting_target4', $data))
            $this->db->where('getting_target4', $data['getting_target4']); 

        if (element('getting_target5', $data))
            $this->db->where('getting_target5', $data['getting_target5']); 
            
        if (element('getting_target6', $data))
            $this->db->where('getting_target6', $data['getting_target6']); 
        
        if (element('family', $data))
            $this->db->where('family', $data['family']);
        
        if (element('sex_skill ', $data))
            $this->db->where('sex_skill ', $data['sex_skill ']);
            
        $this->db->where('delete', "0");
                                
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) 
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }
    
    // Редактируем профиль
    public function edit_profile($id = '', $array)
    {
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($array))
        {
            $this->db->where('id', $id);
            $this->db->update('users', $array);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Для главной страницы
    public function get_users_main()
    {
        $this->db->order_by('RAND()');
        $this->db->where('hash_avatar != ""');
        $this->db->where('delete', "0");
        $query = $this->db->get('users', 3);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
    
    // Анкета дня
    public function get_users_rand($gender = 'all')
    {
        $this->db->order_by('RAND()');
        
        $this->db->where('date_anketa_day > "' . now() . '"');
        $this->db->where('delete', "0");
        if ($gender == 'm')
        {
            //$this->db->where('anketa_day_type', 'm');
            $this->db->where('anketa_day_type', 'all');
            $this->db->or_where('anketa_day_type', 'm');
        }
        elseif ($gender == 'w')
        {
            $this->db->where('anketa_day_type', 'all');
            $this->db->or_where('anketa_day_type', 'w');
        }
        
        
        $query = $this->db->get('users', 1);
        if ($query->num_rows() > 0) 
        {
            return $query->result_array();
        }
        else
        {
            return FALSE;
        }
    }
}