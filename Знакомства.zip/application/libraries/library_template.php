<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Library_Template
{
    // Шаблон обычной страницы
    public function page($page = 'templates/default_page', $data = array())
    {
        
        $CI =& get_instance();
               
        if ($page === NULL)
        {
            $page = 'templates/default_page';
        }
        
        if (is_dir(APPPATH . './../application/views/styles/' . $data['style'] . '/'))
        {
            
            $CI->load->view('styles/' . $data['style'] . '/templates/header', $data);
            $CI->load->view('styles/' . $data['style'] . '/' . $page, $data);
            $CI->load->view('styles/' . $data['style'] . '/templates/footer', $data);
        }
        else
        {
            if ( ! file_exists('application/views/' . $page . '.php'))
        	{
        		// Whoops, we don't have a page for that!
        		show_404();
        	}
            
            $CI->load->view('templates/header', $data);
            $CI->load->view($page, $data);
            $CI->load->view('templates/footer', $data);
        }
    }
} 