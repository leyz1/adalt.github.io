<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class library_doc 
{
    // Системные настройки по умолчанию
    public function by_default($array = array(), $doc = array())
    {
        $CI =& get_instance();
        $data = $CI->user->authorization();

        return array(
            'email' => 'admin@sizok.ru', // Почта для связи с Администрацией
            'copyright' => 'sizok.ru 2008 -', // Копирайт сайта
            'meta_keywords' => element('meta_keywords', $array) ? $array['meta_keywords'] : 'sex,знакомства,мобильные,вап,wap,интим,найти,проститутка,ночь,город,мой,досуг,интернет', // Ключевые слова заголовков по умолчанию
            'meta_description' => element('meta_description', $array) ? $array['meta_description'] : 'SIZOK.RU - это бесплатный сайт знакомств для любви, интима, разврата, отношений и просто общения!', // Описание заголовков по умолчанию
            'title' => element('title', $array) ? $array['title'] : 'SIZOK.RU - это бесплатный сайт знакомств для любви, интима, разврата, отношений и просто общения!', // Титлы по умолчанию
            'style' => element('style', $data) ? $data['style'] : ($CI->session->userdata('web_style') ? $CI->session->userdata('web_style') : 'default'), // Тема по умолчанию
            'time_zone' => '0', // Часовой пояс
            'page' => element('page', $array) ? $array['page'] : NULL, // URL страницы
            'registration' => FALSE, // Регистрация 
            'data' => is_array($doc) ? $doc : array(), // Массив переданных данных
            'user' => is_array($data) ? $data : FALSE); // Массив пользовательских данных
    }
    
}