<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Library_User 
{
    // Авторизация
    public function authorization()
    {
        $CI =& get_instance();
        
        // Массив с данными для авторизации
        $data = array('id' => FALSE, 'password' => FALSE);
        // Авторизация по сессии
        if ($CI->session->userdata('uid') AND $CI->session->userdata('ups')) 
        {
            $data = array('id' => $CI->session->userdata('uid'), 'password' => $CI->session->userdata('ups'));
        }
        // Авторизация по COOKIE
        elseif($CI->input->cookie('cuid') AND $CI->input->cookie('cups')) 
        {
            $data = array('id' => $CI->encrypt->decode($CI->input->cookie('cuid')), 'password' => $CI->encrypt->sha1($CI->input->cookie('cups')));
        }
        // Принимаем елементы массива и авторизируем
        if (element('id', $data) AND element('password', $data))
        {
            $CI->db->where('id', $data['id']);
            $CI->db->where('password', $data['password']);
            $query = $CI->db->get('users');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            $this->out();
        }
        $this->out();
    }
    
    // Уничтожаем данные авторизации
    public function out()
    {
        $CI =& get_instance();
        // Удаляем сессии
        
        if ($CI->session->userdata('uid'))
        {
            $data = '';
            $data = $this->parse_id($CI->session->userdata('uid'));
            $CI->db->where('id', $data['id']);
            $CI->db->update('users', array('date_login' => now(), 'ip' => $CI->input->ip_address(), 'user_agent' => $CI->input->user_agent()));
        }   
            
        $CI->session->unset_userdata('uid');
        $CI->session->unset_userdata('ups');   
        // Чистим куксы
        delete_cookie('cuid');
        delete_cookie('cups');
        return TRUE;
    }
    
    //Обновляем дату последнего входа на сайт
    public function date_login()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (is_array($data))
        {
            if ($data['date_login'] < (now() - 600))
            {
                $CI->db->where('id', $data['id']);
                $CI->db->update('users', array('date_login' => now(), 'ip' => $CI->input->ip_address(), 'user_agent' => $CI->input->user_agent()));
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Получаем ID авторизированного пользователя
    public function id()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('id', $data))
        {
            return trim($data['id']);
        }
        return FALSE;
    }
    
    // Получаем Login авторизированного пользователя
    public function login()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('login', $data))
        {
            return trim($data['login']);
        }
        return FALSE;
    }
    
    // Хеш для отображения аватара
    public function hash_avatar()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('hash_avatar', $data))
        {
            return trim($data['hash_avatar']);
        }
        return FALSE;
    }
    
    public function gender()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('gender', $data))
        {
            return trim($data['gender']);
        }
        else
        {
            return FALSE;
        }
    }
    
    public function total_balls()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('balls', $data))
        {
            return trim($data['balls']);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Отображаем мобильный номер
    public function mobile_phone()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        if (element('country_code', $data) AND element('mobile_phone', $data))
        {
            return trim($data['mobile_phone']);
        }
        else
        {
            return FALSE;
        }
    }
    
    // Получаем Time Zone авторизированного пользователя
    public function time_zone()
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (element('time_zone', $data))
        {
            return trim($data['time_zone']);
        }
        return FALSE;
    }
    
    // Должность пользователя
    public function access_user($data)
    {
        if (is_array($data))
        {
            if ($data['level'] == 0)
            {
                return 'Пользователь';
            }
            elseif ($data['level'] == 1)
            {
                return 'Модератор форума';
            }
            elseif ($data['level'] == 2)
            {
                return 'Модератор чата';
            }
            elseif ($data['level'] == 3)
            {
                return 'Модератор фото';
            }
            elseif ($data['level'] == 4)
            {
                return 'Модератор дневников';
            }
            elseif ($data['level'] == 5)
            {
                return 'Модератор стены';
            }
            elseif ($data['level'] == 6)
            {
                return 'Модератор библиотеки';
            }
            elseif ($data['level'] == 7)
            {
                return 'Модератор обьявлений';
            }
            elseif ($data['level'] == 8)
            {
                return '<span class="blue">Модератор</span>';
            }
            elseif ($data['level'] == 9)
            {
                return '<span class="green">Администратор</span>';
            }
            elseif ($data['level'] == 10)
            {
                return '<span class="red">Главный Администратор</span>';
            }
            else
            {
                return 'Пользователь';
            }
        }
        else
        {
            return 'Пользователь';
        }
    }
    
    // Количество пунктов на страницу
    public function per_page($per_page = 10)
    {
        $data = $this->authorization();
        
        if (element('per_page', $data))
        {
            if ($data['per_page'] === '')
            {
                return trim($per_page);
            }
            elseif ($data['per_page'] === FALSE)
            {
                return trim($per_page);
            }
            elseif ($data['per_page'] === NULL)
            {
                return trim($per_page);
            }
            else
            {
                return trim($data['per_page']);
            }
        }
        return trim($per_page);
    }
    
    // Обновляем данные пользователя
    public function update($array)
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if (is_array($data) AND is_array($array))
        {
            if (element('id', $data))
            {
                $CI->db->where('id', $data['id']);
                $CI->db->update('users', $array); 
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Определяем пользователя
    public function is_user()
    {
        if ($this->authorization())
        {
            return TRUE;                
        }
        return FALSE;
    }
    
    // Определяем Администрацию
    public function is_admin($level = array())
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if ($this->is_user())
        {
            if (empty($level)) $level = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
            if (in_array($data['level'], $level))
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Регистрация нового пользователя
    public function registration($array)
    {
        $CI =& get_instance();
        
        if (is_array($array))
        {
            if (element('login', $array) AND element('password', $array) AND element('gender', $array))
            {
                if ($CI->db->insert('users', $array)) 
                {
                    return TRUE;
                }
                return FALSE;
            }
            return FALSE;
        }
        return FALSE;
    }
    
    // Проверка логина в системе
    public function check_login($array)
    {
        $CI =& get_instance();
        
        if (is_array($array))
        {
            if (element('login', $array) AND element('password', $array))
            {
                $CI->db->where('login', $array['login']);
                $CI->db->where('password', $array['password']);
                $query = $CI->db->get('users');
                if ($query->num_rows() > 0) 
                {
                    return $query->row_array();
                }
                return FALSE;
            }
            return FALSE;
        }
        return FALSE;
    }
    
    // Проверка свободен ли логин
    public function check_login_registration($login = NULL)
    {
        $CI =& get_instance();
        
        if ($login === NULL)
        {
            return TRUE;
        }
        
        if ($login)
        {
            $CI->db->where('login', $login);
            $query = $CI->db->get('users');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            }
        }
        return FALSE;
    }
    
    // Парсинг данных по ID
    public function parse_id($id = '')
    {
        $CI =& get_instance();
        
        if ($id === '')
        {
            $id = 0;
        }
        elseif ($id === FALSE)
        {
            $id = 0;
        }
        elseif ($id === NULL)
        {
            $id = 0;
        }
        
        if ($id > 0)
        {
            $CI->db->where('id', $id);
            $query = $CI->db->get('users');
            if ($query->num_rows() > 0) 
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Засчитываем баллы пользователю
    public function balls($balls = 0)
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if ($balls > 0 AND is_array($data))
        {
            $CI->db->where('id', $data['id']);
            $CI->db->update('users', array('balls' => $data['balls'] + $balls)); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    public function minus_balls($balls = 0)
    {
        $CI =& get_instance();
        $data = $this->authorization();
        
        if ($balls > 0 AND is_array($data))
        {
            $CI->db->where('id', $data['id']);
            $CI->db->update('users', array('balls' => $data['balls'] - $balls)); 
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка пароля
    public function check_password($password = NULL)
    {
        $CI =& get_instance();
        $data = $this->authorization();
        if (is_array($data))
        {
            if ($data['password'] == $password)
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверяем нет ли пользователя в черном списке
    public function check_ignore($id = '')
    {
        $id_user = $this->id();
        $data = $this->authorization();
        $CI =& get_instance();
        
        if ($id === '')
        {
            return FALSE;
        }
        elseif (is_array($data) AND $data['level'] > 0)
        {
            return FALSE;
        }
        elseif ($id > 0 AND $id_user > 0)
        {
            $CI->db->where('id_user', $id);
            $CI->db->where('id_ignore', $id_user);
            $query = $CI->db->get('users_ignore');
            if ($query->num_rows() > 0) 
            {
                return TRUE;
            } 
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка на дружбу
    public function check_friends($id = '')
    {
        $data = $this->authorization();
        $CI =& get_instance();
        if ($id === '')
        {
            return FALSE;
        }
        elseif ($id > 0 AND is_array($data))
        {
            $CI->db->where('id_user', $id);
            $CI->db->where('id_to', $data['id']);
            $query = $CI->db->get('friends_users');
            if ($query->num_rows() > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Проверка на бан
    public function check_ban()
    {
        $data = $this->authorization();
        $CI =& get_instance();
        
        $CI->db->where('id_user', $data['id']);
        $CI->db->where('time > "' . now() . '"');
        $query = $CI->db->get('users_ban');
        if ($query->num_rows() > 0)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    
    // Восстановление пароля
    public function check_pswdreminder($login = '', $mail = '')
    {
        $CI =& get_instance();
        
        if ($login === '' AND $mail === '')
        {
            return FALSE;
        }
        elseif ($login)
        {
            $CI->db->where('login', $login);
            $CI->db->where('email', $mail);
            $query = $CI->db->get('users');
            if ($query->num_rows() > 0)
            {
                return $query->row_array();
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }
}