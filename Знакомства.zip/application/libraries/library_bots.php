<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Library_Bots 
{
    // Бот умник
    public function nerd($room, $set)
    {
        $CI =& get_instance();
        
        if (is_array($room) AND is_array($set))
        {
            $CI->db->order_by('id', 'DESC');
            $CI->db->where('id_room', $room['id']);
            $CI->db->where('nerd <>', '0');
            $query = $CI->db->get('chat_post');
            
            if ($query->num_rows() > 0)
            {
                $nerd = $query->row_array();
            }
            else
            {
                $nerd = FALSE;
            }
            
            // Принимаем верный ответ
            if ($nerd !== FALSE AND $nerd['nerd'] != 4)
            {
                $CI->db->where('id', $nerd['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $question = $query->row_array();
                    $CI->db->where('id_room', $room['id']);
                    $CI->db->like('description', $question['reply']);
                    $CI->db->where('nerd', '0');
                    $CI->db->order_by('id', 'DESC');
                    $query = $CI->db->get('chat_post');
                    if ($query->num_rows() > 0)
                    {
                        $reply = $query->row_array();
                        
                        // Если не использовали подсказку
                        if($nerd['nerd'] == 1){
                            $add_balls = 25;
                            $add_iq = 25;
                            $pods = 'не используя подсказок';
                        }
                        // Если использовал одну подсказку
                        elseif($nerd['nerd'] == 2){
                            $add_balls = 15;
                            $add_iq = 15;
                            $pods = 'используя одну подсказку';
                        }
                        // Если использовал две подсказки
                        elseif($nerd['nerd'] == 3){
                            $add_balls = 5;
                            $add_iq = 5;
                            $pods = 'используя обе подсказки';
                        }
                        
                        if ($CI->chat->add_post(array('id_room' => $room['id'], 'id_reply' => $reply['id_user'], 'description' => $CI->function->variables('Молодец, [b]' . $CI->user->login() . '[/b], Вы дали верный ответ [b]' . $question['reply'] . '[/b] первее всех, ' . $pods . '. [b]' . $CI->user->login() . '[/b] получает ' . $add_balls . ' баллов и ' . $add_iq . ' IQ. Следующий вопрос через [b]' . $set['timeout_questions'] . '[/b] сек'), 'time' => now(), 'nerd' => 4)))
                        {
                            $CI->user->balls($add_balls);
                            $CI->chat->iq($add_iq);
                            redirect(current_url());
                        }
                    }
                }
            }
            
            // Задаем вопрос
            if ($nerd === FALSE OR $nerd['nerd'] == 4 AND $nerd['time'] < now() - $set['timeout_questions'])
            {
                $total_question = $CI->db->count_all('chat_question');
                $CI->db->where('id', rand(1, $total_question));
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $question = $query->row_array();
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $question['question'] . ' [b]Ответ:[/b] слово из ' . mb_strlen($question['reply']) . ' букв.'), 'time' => now(), 'question' => $question['id'], 'nerd' => 1)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Первая подсказка УМНИКА
            if ($nerd !== FALSE AND $nerd['nerd'] == 1 AND $nerd['time'] < now() - $set['timeout_help'])
            {
                $CI->db->where('id', $nerd['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $reply = $query->row_array();
                    $help = iconv_substr($reply['reply'], 0, 1, 'utf-8');
                    
                    for($i=0; $i < mb_strlen($reply['reply']) - 1; $i++)
                    {
                        $help .='*';
                    }
                    
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $reply['question'] . ' [b]Первая подсказка:[/b] ' . $help . ' [b]Ответ:[/b] слово из ' . mb_strlen($reply['reply']) . ' букв.'), 'time' => now(), 'question' => $reply['id'], 'nerd' => 2)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Вторая подсказка УМНИКА
            elseif ($nerd !== FALSE AND $nerd['nerd'] == 2 AND $nerd['time'] < now() - $set['timeout_help'])
            {
                $CI->db->where('id', $nerd['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $reply = $query->row_array();
                    $help = iconv_substr($reply['reply'], 0, 2, 'utf-8');
                    
                    for($i=0; $i < mb_strlen($reply['reply']) - 2; $i++)
                    {
                        $help .='*';
                    }
                    
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $reply['question'] . ' [b]Вторая подсказка:[/b] ' . $help . ' [b]Ответ:[/b] слово из ' . mb_strlen($reply['reply']) . ' букв.'), 'time' => now(), 'question' => $reply['id'], 'nerd' => 3)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Если никто не ответил
            elseif ($nerd !== FALSE AND $nerd['nerd'] == 3 AND $nerd['time'] < now() - $set['timeout_help'])
            {
                if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('На вопрос никто не ответил. Следующий вопрос через: [b]' . $set['timeout_questions'] . '[/b] сек'), 'time' => now(), 'nerd' => 4)))
                {
                    redirect(current_url());
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
    
    // Бот Дядя Вася
    public function nerd2($room, $set)
    {
        $CI =& get_instance();
        
        if (is_array($room) AND is_array($set))
        {
            $CI->db->order_by('id', 'DESC');
            $CI->db->where('id_room', $room['id']);
            $CI->db->where('nerd2 <>', '0');
            $query = $CI->db->get('chat_post');
            
            if ($query->num_rows() > 0)
            {
                $nerd2 = $query->row_array();
            }
            else
            {
                $nerd2 = FALSE;
            }
            
             // Принимаем верный ответ
            if ($nerd2 !== FALSE AND $nerd2['nerd2'] != 4)
            {
                $CI->db->where('id', $nerd2['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $question = $query->row_array();
                    $CI->db->where('id_room', $room['id']);
                    $CI->db->like('description', $question['reply']);
                    $CI->db->where('nerd2', '0');
                    $CI->db->order_by('id', 'DESC');
                    $query = $CI->db->get('chat_post');
                    
                    if ($query->num_rows() > 0)
                    {
                        $reply = $query->row_array();
                        
                        // Если не использовали подсказку
                        if($nerd2['nerd2'] == 1){
                            $add_balls = 25;
                            $add_iq = 25;
                            $pods = 'не используя подсказок';
                        }
                        // Если использовал одну подсказку
                        elseif($nerd2['nerd2'] == 2){
                            $add_balls = 15;
                            $add_iq = 15;
                            $pods = 'используя одну подсказку';
                        }
                        // Если использовал две подсказки
                        elseif($nerd2['nerd2'] == 3){
                            $add_balls = 5;
                            $add_iq = 5;
                            $pods = 'используя обе подсказки';
                        }
                        
                        $quotes = array(
                        'Уёбище ' . $CI->user->login() . ' успешно отсосало ' . rand(10, 100) . ' хуев, и оно занимает в рейтинге хуесосов [b]1[/b] место.',
                        'В рейтинге эта сука занимает место за пределами первых трех десятков хуюмников.',
                        'Вы великолепно отсосали хуй.',
                        'Ты хуйнул в тему, баклан!',
                        'Ну ты и ботаник. Что типа умный? Дай другим ответить гандон.');
                        
                        if ($CI->chat->add_post(array('id_room' => $room['id'], 'id_reply' => $reply['id_user'], 'description' => $CI->function->variables(random_element($quotes) . ' Вы дали верный ответ [b]' . $question['reply'] . '[/b] первее всех, ' . $pods . '. [b]' . $CI->user->login() . '[/b] получает ' . $add_balls . ' баллов и ' . $add_iq . ' IQ. Следующий вопрос через [b]' . $set['timeout_questions'] . '[/b] сек'), 'time' => now(), 'nerd2' => 4)))
                        {
                            $CI->user->balls($add_balls);
                            $CI->chat->iq($add_iq);
                            redirect(current_url());
                        }
                    }
                }
            }
            
            // Задаем вопрос
            if ($nerd2 === FALSE OR $nerd2['nerd2'] == 4 AND $nerd2['time'] < now() - $set['timeout_questions'])
            {
                $total_question = $CI->db->count_all('chat_question');
                $CI->db->where('id', rand(1, $total_question));
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $question = $query->row_array();
                    $quotes = array(
                        '[b]Ответ:[/b] слово из ' . rand(1, 8) . ' букв, да нет, напиздел ' . mb_strlen($question['reply']) . ' или ' . rand(2, 10) . ', Хуй знает.',
                        '[b]Ответ:[/b] слово из ' . mb_strlen($question['reply']) . ' букв.',
                        '[b]Ответ:[/b] слово из 100 или 500 букв гг. Пизжу. Не помню я.',
                        '[b]Ответ:[/b] слово из нихуя не скажу...',
                        '[b]Ответ:[/b] слово из ' . mb_strlen($question['reply']) . ' букв. Наверное...',
                        '[b]Ответ:[/b] слово из сами считайте гг...',
                        '[b]Ответ:[/b] слово из букв мало. Или много. Короче похуй.');
                        
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $question['question'] . ' ' . random_element($quotes)), 'time' => now(), 'question' => $question['id'], 'nerd2' => 1)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Первая подсказка УМНИКА
            elseif ($nerd2 !== FALSE AND $nerd2['nerd2'] == 1 AND $nerd2['time'] < now() - $set['timeout_help'])
            {
                $CI->db->where('id', $nerd2['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $reply = $query->row_array();
                    $help = iconv_substr($reply['reply'], 0, 1, 'utf-8');
                    
                    for($i=0; $i < mb_strlen($reply['reply']) - 1; $i++)
                    {
                        $help .='*';
                    }
                    
                    $quotes = array(
                        ' [b]Пинок под срач всем тупорылым ублюдосинам:[/b] ',
                        ' [b]Подсказка всем конченным долбоёбищам:[/b] ',
                        ' [b]Хуй с вами, мудозвоны, ловите подсказку:[/b] ',
                        ' [b]Ебанутые вы. Для дебилов охуевших - подсказка:[/b] ',
                        ' [b]Подсказка:[/b] Слышите, бляди тупорылые? Еще повторить? Теперь дошло, дебилы? ',
                        ' [b]Подсказка нах:[/b] ',
                        ' [b]Подъёбка:[/b] ',
                        ' [b]Че, дрочите, слабоумные? Вот подсказка:[/b] ',
                        ' [b]Подсказку захотели? А отсосать?[/b] ',
                        ' [b]Че бля подсказку хуйнуть? А без нее сосете? Тогда сосите с ней:[/b] ',
                        ' [b]Вы меня заебали! Подъёбка:[/b] ');
                        
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $reply['question'] . random_element($quotes) . $help . ' [b]Ответ:[/b] слово из ' . mb_strlen($reply['reply']) . ' букв.'), 'time' => now(), 'question' => $reply['id'], 'nerd2' => 2)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Вторая подсказка УМНИКА
            elseif ($nerd2 !== FALSE AND $nerd2['nerd2'] == 2 AND $nerd2['time'] < now() - $set['timeout_help'])
            {
                $CI->db->where('id', $nerd2['question']);
                $query = $CI->db->get('chat_question');
                if ($query->num_rows() > 0)
                {
                    $reply = $query->row_array();
                    $help = iconv_substr($reply['reply'], 0, 2, 'utf-8');
                    
                    for($i=0; $i < mb_strlen($reply['reply']) - 2; $i++)
                    {
                        $help .='*';
                    }
                    
                    $quotes = array(
                        ' [b]Пинок под срач всем тупорылым ублюдосинам:[/b] ',
                        ' [b]Подсказка всем конченным долбоёбищам:[/b] ',
                        ' [b]Хуй с вами, мудозвоны, ловите подсказку:[/b] ',
                        ' [b]Ебанутые вы. Для дебилов охуевших - подсказка:[/b] ',
                        ' [b]Подсказка:[/b] Слышите, бляди тупорылые? Еще повторить? Теперь дошло, дебилы? ',
                        ' [b]Подсказка нах:[/b] ',
                        ' [b]Подъёбка:[/b] ',
                        ' [b]Че, дрочите, слабоумные? Вот подсказка:[/b] ',
                        ' [b]Подсказку захотели? А отсосать?[/b] ',
                        ' [b]Че бля подсказку хуйнуть? А без нее сосете? Тогда сосите с ней:[/b] ',
                        ' [b]Вы меня заебали! Подъёбка:[/b] ');
                        
                    if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables('[b]Вопрос:[/b] ' . $reply['question'] . random_element($quotes) . $help . ' [b]Ответ:[/b] слово из ' . mb_strlen($reply['reply']) . ' букв.'), 'time' => now(), 'question' => $reply['id'], 'nerd2' => 3)))
                    {
                        redirect(current_url());
                    }
                }
            }
            
            // Если никто не ответил
            elseif ($nerd2 !== FALSE AND $nerd2['nerd2'] == 3 AND $nerd2['time'] < now() - $set['timeout_help'])
            {
                $quotes = array(
                        'Отсосите, чмошники! Уебывайте не дожидаясь следующего вопроса.',
                        'Проебали вы время, дуболомы! Ждите следующего заёба.',
                        'И снова победила тупость печальных мудозвонов, называющих себя знатоками...',
                        'Время вышло долбоёбы. Идите книги читать бля...',
                        'И снова нихуя не знаете. Вас учили только хуй сосать?',
                        'Время истекло.',
                        'Нету ответа? Нету! Куриные мозги местных уебков расплавились и завоняли. Пиздец.',
                        'Ни один пидор не дал правильного ответа. Вы посылаетесь нахуй.');
                        
                if ($CI->chat->add_post(array('id_room' => $room['id'], 'description' => $CI->function->variables(random_element($quotes) . ' Следующий вопрос через: [b]' . $set['timeout_questions'] . '[/b] сек'), 'time' => now(), 'nerd2' => 4)))
                {
                    redirect(current_url());
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
}