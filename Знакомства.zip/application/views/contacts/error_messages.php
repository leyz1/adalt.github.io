<b>ОПС!</b>

<?=br(2)?>

<div class="dotted">Сообщение не найдено.</div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

