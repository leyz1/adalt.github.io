<b>Мои контакты</b> 

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_to']), 'contacts/messages')?> <?=($this->contact->count_all_new_messages_id($item['id_to']) ? $this->contact->count_all_new_messages_id($item['id_to']) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=form_open(current_url())?>
<?=form_hidden('id_to', $item['id_to'])?>
<?=form_submit('submit', 'Удалить контакт', 'class="form"')?>
<?=form_close()?> 
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Список контактов пуст.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/search.png') . nbs() . anchor('page/search', 'Поиск')?>
<br />
<?=img('images/icons/users.gif') . nbs() . anchor('page/users', 'Пользователи')?> <span class="count">(<?=$this->profile->count_users()?>)</span>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>