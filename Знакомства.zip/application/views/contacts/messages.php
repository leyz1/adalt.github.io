<b>Личные сообщения</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
[<?=anchor(current_url(), 'ОБНОВИТЬ', 'class="blue"')?>] <?=anchor('page/smileys', 'Смайлы', 'class="orange"')?> | <?=anchor('contacts/trunce_messages/' . $data['user_data']['id'], 'Очистить переписку', 'class="green"')?>
</div>

<?php if ($quarantine_time = $this->contact->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете писать сообщения. Подождите 3 минуты.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Сообщение (от 1 до 1000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Написать', 'class="form"')?>
</div>

<?=form_close()?>
<?php endif; ?>


<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
<br />
<?php
	if ($item['read'] == 0)
    {
        echo '<span class="green">Прочитано</span>';
    }
    elseif ($item['read'] == 1)
    {
        echo '<span class="red">Не прочитано</span>';
    }
?>

<br />

<?=($user['id'] != $item['id_user'] ? anchor('contacts/add_spam/' . $item['id'], 'Спам', 'class="red"') : '')?>

</div>


<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет переписки.</b></div>
<?php endif; ?>

<?php if ($this->contact->check_contacts($data['user_data']['id'])) : ?>
<div class="dotted">
<?=img('images/icons/user_delete.png') . nbs() . anchor('contacts/add_ignored/' . $data['user_data']['id'], 'Добавить в список игнора')?>
</div>
<?php else : ?>
<div class="dotted">
<?=img('images/icons/user_delete.png') . nbs() . anchor('contacts/add_contacted/' . $data['user_data']['id'], 'Добавить в список контактов')?>
</div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('contacts/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>