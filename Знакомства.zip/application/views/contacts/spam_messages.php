<b>Спам/Жалоба</b> | Отправка заявки

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Жалоба на:</b>
<br />
<?=show_text($data['messages_data']['description'])?>
</div>

<div class="dotted">
<b>Причина жалобы:</b>
<br />
<?=form_dropdown('type_spam', $data['type_spam'], 0, 'class="form"')?>
</div>

<div class="dotted">
Сообщение (от 10 до 1000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Отправить жалобу', 'class="form"')?>
</div>
<?=form_close()?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('contacts/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>