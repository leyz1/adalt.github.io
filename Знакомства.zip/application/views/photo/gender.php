<b>Фото</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($this->user->is_admin(array(3, 10))) : ?>

<div class="dotted"><?=anchor('photo/moderations', 'Модерация фото', 'class="red"')?> <span class="count">(<?=$this->photo->count_all_photo_moderations()?>)</span></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>
<div class="dotted"><?=anchor('photo/add_photo', 'Добавить новое фото', 'class="orange"')?></div>

<div class="dotted"><?=img('images/icons/chart.png') . nbs() . anchor('photo/chart', 'Популярные')?> <span class="count">(<?=$this->photo->count_photo()?>)</span></div>
<div class="dotted"><?=img('images/icons/boy.png') . nbs() . anchor('photo/boy', 'Парни')?> <span class="count">(<?=$this->photo->count_all_photo_moder('m')?>)</span></div>
<div class="dotted"><?=img('images/icons/girl.png') . nbs() . anchor('photo/girl', 'Девушки')?> <span class="count">(<?=$this->photo->count_all_photo_moder('w')?>)</span></div>

<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>