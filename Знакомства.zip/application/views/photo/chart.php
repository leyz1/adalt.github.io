<b>Фото</b> | Популярные

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Добавил:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<?=img('images/icons/comments.png') . nbs() . anchor('photo/comments/' . $item['id'], show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->photo->count_all_comments_id($item['id'])?>)</span>
<br />
<?=img('files/photos/' . $item['id_user'] . '/thumbs/' . $item['hash_file'] . '_thumb.png')?>
<br />---<br />
<b>Описание:</b> <?=($item['description'] ? show_text($item['description']) : 'Без описания.')?>
<br />
<b>Рейтинг:</b> <?=$item['rating']?>
<br />
<?php if ($this->photo->check_vote_photo($item['id']) === FALSE) : ?>
<a class="green" href="<?=base_url() . 'index.php/photo/vote_photo/' . $item['id'] . '/plus'?>">Мне нравится</a> | <a class="red" href="<?=base_url() . 'index.php/photo/vote_photo/' . $item['id'] . '/minus'?>">Не нравится</a>
<br />
<?php endif; ?>
<?=img('images/icons/download.png') . nbs() . anchor('photo/download_file/' . $item['id_user'] . '/' . $item['hash_file'], 'Скачать оригинал (' . $item['file_size'] .' кб)', 'class="green"')?>
<br />
<?=($user['id'] == $item['id_user'] ? '---<br />' . anchor('photo/edit_photo/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('photo/delete_photo/' . $item['id'], 'Удалить', 'class="red"') : '')?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет фотографий.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('photo/gender/', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>