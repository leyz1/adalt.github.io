<b>Дневники пользователей</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($this->user->is_admin(array(4, 10))) : ?>

<div class="dotted"><?=anchor('blog/moderations', 'Модерация дневников', 'class="red"')?> <span class="count">(<?=$this->blog->count_all_blog_moderations()?>)</span></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>
<div class="dotted"><?=anchor('blog/add_blog', 'Написать дневник', 'class="orange"')?></div>

<div class="dotted"><?=img('images/icons/chart.png') . nbs() . anchor('blog/chart', 'Популярные')?> <span class="count">(<?=$this->blog->count_blog()?>)</span></div>
<div class="dotted"><?=img('images/icons/boy.png') . nbs() . anchor('blog/boy', 'Парни')?> <span class="count">(<?=$this->blog->count_all_blog_moder('m')?>)</span></div>
<div class="dotted"><?=img('images/icons/girl.png') . nbs() . anchor('blog/girl', 'Девушки')?> <span class="count">(<?=$this->blog->count_all_blog_moder('w')?>)</span></div>


<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>