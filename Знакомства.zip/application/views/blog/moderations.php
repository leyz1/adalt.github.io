<b>Дневники</b> | Модерация дневников

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/comments.png') . nbs() . anchor('blog/comments/' . $item['id'] . '/', show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->blog->count_all_blog_comments($item['id'])?>)</span>
<br />---<br />
<b>Добавил:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />
<b>Рейтинг:</b> <?=$item['rating']?>
<br />---<br />
<?=form_open(current_url())?>
<?=form_hidden('id', $item['id'])?>
<?=form_submit('submit', 'Промодерировать', 'class="form"')?> <?=form_submit('delete', 'Удалить дневник', 'class="form"')?>
<?=form_close()?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет дневников.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>