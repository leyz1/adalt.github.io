<b>Дневники</b> | Редактировать запись

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($quarantine_time = $this->blog->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Подождите немного.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Заголовок (от 3 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 10 до 3000 символов):
<br />
<?=form_textarea($data['description'], FALSE)?>
<br />
<?=form_submit('submit', 'Редактировать', 'class="form"')?>
</div>


<?=form_close()?>
<?php endif; ?>


<?php else : ?>
<div class="error"><b>Доступ к дневникам временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('blog/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>