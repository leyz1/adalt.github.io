<b>Мой профиль</b> | Знакомства

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Ориентация:</b>
<br />
<?=form_dropdown('sex_orient', $data['sex_orient'], $user['sex_orient'], 'class="form"')?>
</div>

<div class="dotted">
<b>Цель знакомства:</b>
<br />
<?=form_checkbox($data['getting_target1'], '', '', 'class="form"')?> Дружба и общение
<br />
<?=form_checkbox($data['getting_target2'], '', '', 'class="form"')?> Флирт, СМС-переписка
<br />
<?=form_checkbox($data['getting_target3'], '', '', 'class="form"')?> Любовь, отношения
<br />
<?=form_checkbox($data['getting_target4'], '', '', 'class="form"')?> Брак, создание семьи
<br />
<?=form_checkbox($data['getting_target5'], '', '', 'class="form"')?> Виртуальный секс
<br />
<?=form_checkbox($data['getting_target6'], '', '', 'class="form"')?> Секс в реале
<br />
</div>

<div class="dotted">
<b>Семейное положение:</b>
<br />
<?=form_dropdown('family', $data['family'], $user['family'], 'class="form"')?>
</div>

<div class="dotted">
<b>Дети:</b>
<br />
<?=form_dropdown('children', $data['children'], $user['children'], 'class="form"')?>
</div>

<div class="dotted">
<b>Материальная поддержка:</b>
<br />
<?=form_dropdown('sponsor', $data['sponsor'], $user['sponsor'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/anketa', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>