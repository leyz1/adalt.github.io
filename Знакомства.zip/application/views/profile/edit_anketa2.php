<b>Мой профиль</b> | Типаж

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Рост</b> (см.):
<br />
<?=form_input($data['growth'])?>
</div>

<div class="dotted">
<b>Вес</b> (кг.):
<br />
<?=form_input($data['weight'])?>
</div>

<div class="dotted">
<b>Цвет глаз:</b> (до 20 символов)
<br />
<?=form_input($data['eye_color'])?>
</div>

<div class="dotted">
<b>Цвет волос:</b> (до 20 символов)
<br />
<?=form_input($data['hair_color'])?>
</div>

<div class="dotted">
<b>Телосложение:</b>
<br />
<?=form_dropdown('body_build', $data['body_build'], $user['body_build'], 'class="form"')?>
</div>

<div class="dotted">
<b>Характер:</b> (до 20 символов)
<br />
<?=form_input($data['nature'])?>
</div>

<div class="dotted">
<b>Режим дня:</b>
<br />
<?=form_dropdown('regimen', $data['regimen'], $user['regimen'], 'class="form"')?>
</div>

<div class="dotted">
<b>Профессия:</b> (до 64 символов)
<br />
<?=form_input($data['prof'])?>
</div>

<div class="dotted">
<b>Жизненные цели:</b> (до 1000 символов)
<br />
<?=form_textarea($data['life'])?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/anketa', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>