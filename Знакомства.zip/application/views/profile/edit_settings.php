<b>Мой профиль</b> | Персонализация

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
Пунктов на страницу:
<br />
<?=form_dropdown('per_page', $data['per_page'], $user['per_page'], 'class="form"')?>
</div>

<div class="dotted">
Смайлы:
<br />
<?=form_dropdown('view_smileys', $data['view_smileys'], $user['view_smileys'], 'class="form"')?>
</div>

<div class="dotted">
HTML теги:
<br />
<?=form_dropdown('view_tags', $data['view_tags'], $user['view_tags'], 'class="form"')?>
</div>

<div class="dotted">
Ссылки в тексте:
<br />
<?=form_dropdown('view_http', $data['view_http'], $user['view_http'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>