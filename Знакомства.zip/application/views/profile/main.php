<b>Мой профиль</b>

<?=br(2)?>
<div class="menu"><?=img('images/icons/anketa.png') . nbs() . anchor('profile/anketa', 'Анкета')?></div>
<div class="menu"><?=img('images/icons/avatar.png') . nbs() . anchor('profile/edit_avatar', 'Обновить главное фото')?></div>
<div class="menu"><?=img('images/icons/lock_edit.png') . nbs() . anchor('profile/edit_pass', 'Изменить пароль')?></div>
<div class="menu"><?=img('images/icons/e-mail.png') . nbs() . anchor('profile/edit_e_mail', 'Настройки E-mail')?></div>
<div class="menu"><?=img('images/icons/mobile.png') . nbs() . anchor('profile/edit_mobile', 'Номер телефона')?></div>
<div class="menu"><?=img('images/icons/anonymous.png') . nbs() . anchor('profile/edit_privacy', 'Настройки приватности')?></div>
<div class="menu"><?=img('images/icons/user_black.png') . nbs() . anchor('profile/edit_ignore', 'Черный список')?> <span class="count">(<?=$this->profile->count_all_ignore($user['id'])?>)</span></div>
<div class="menu"><?=img('images/icons/palette.png') . nbs() . anchor('profile/edit_style', 'Тема оформления')?></div>
<div class="menu"><?=img('images/icons/settings.png') . nbs() . anchor('profile/edit_settings', 'Персонализация')?></div>
<div class="menu"><?=img('images/icons/clock.png') . nbs() . anchor('profile/edit_time', 'Время')?></div>
<div class="menu"><?=img('images/icons/city.png') . nbs() . anchor('city/index', 'Изменить город проживания')?></div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

