<b>Мой профиль</b> | Анкеты пользователя

<?=br(2)?>
<div class="menu"> - <?=anchor('profile/edit_anketa1', 'Основная')?></div>
<div class="menu"> - <?=anchor('profile/edit_anketa2', 'Типаж')?></div>
<div class="menu"> - <?=anchor('profile/edit_anketa3', 'Знакомства')?></div>
<div class="menu"> - <?=anchor('profile/edit_anketa4', 'Сексуальные предпочтения')?></div>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>