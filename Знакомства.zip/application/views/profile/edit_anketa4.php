<b>Мой профиль</b> | Сексуальные предпочтения

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Сексуальный опыт:</b>
<br />
<?=form_dropdown('sex_skill', $data['sex_skill'], $user['sex_skill'], 'class="form"')?>
</div>

<div class="dotted">
<b>Как часто хотелось бы заниматься сексом:</b>
<br />
<?=form_dropdown('sex_often', $data['sex_often'], $user['sex_often'], 'class="form"')?>
</div>

<div class="dotted">
<b>В сексе я люблю:</b> (до 255 символов)
<br />
<?=form_input($data['sex_like'])?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>


<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/anketa', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>