<b>Мой профиль</b> | Изменить пароль

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?=form_open(current_url())?>

<div class="dotted">
Введите ваш текущий пароль:
<br />
<?=form_password($data['password'])?>
</div>

<div class="dotted">
Введите новый пароль:
<br />
<?=form_input($data['new_password'])?>
</div>

<div class="dotted">
Повторите новый пароль:
<br />
<?=form_input($data['repeat_password'])?>
<br />
<?=form_submit('submit', 'Изменить пароль', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>