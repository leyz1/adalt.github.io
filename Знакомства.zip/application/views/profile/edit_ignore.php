<b>Мой профиль</b> | Черный список

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
ID:
<br />
<?=form_input($data['id_user'])?>
<br />
<?=form_submit('submit', 'Добавить', 'class="form"')?>
</div>

<?=form_close()?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<?=data_user($this->user->parse_id($item['id_ignore']))?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=form_open(current_url())?>
<?=form_hidden('id_ignore', $item['id_ignore'])?>
<?=form_submit('delete', 'Удалить из списка', 'class="form"')?>
<?=form_close()?>

</div>
<? endforeach; ?>
<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Пользователи в данном списке не смогут смотреть Ваши фото, писать Вам сообщения, комментарии и ответы.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>