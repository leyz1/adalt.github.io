<b>Мой профиль</b> | Номер телефона

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<?php if ($user['country_code'] AND $user['mobile_phone']) : ?>
<div class="dotted">
<b>Ваш номер телефона:</b> +(<?=$user['country_code']?>)<?=$user['mobile_phone']?>
</div>
<? endif; ?>

<div class="dotted">
Код страны:
<br />
<select name="country_code" class="form">
<?php foreach ($this->profile->get_country_phone_code() AS $item) : ?>
<?php
	$selected = ($item['PhoneCode'] == $user['country_code']) ? ' selected="selected"' : '';
?>
<option value="<?=$item['ID']?>" <?=$selected?>><?='+(' . $item['PhoneCode'] . ')' . nbs(). $item['TitleRU']?></option>
<br />

<? endforeach; ?>

</select>
<br />
</div>

<div class="dotted">
Номер телефона:
<br />
<?=form_input($data['mobile_number'])?>
<br />
</div>

<div class="dotted">
<span class="red">Номер телефона не будет виден другим пользователям. Он служит для установления владельца аккаунта если вы забудете пароль.</span>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>