<b>Мой профиль</b> | Время

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
Часовой пояс (+-12):
<br />
<?=form_dropdown('time_zone', $data['time_zone'], $user['time_zone'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>