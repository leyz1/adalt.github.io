<b>Мой профиль</b> | Настройки E-mail

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
Введите новый E-mail:
<br />
<?=form_input($data['real_mail'])?>
</div>

<div class="dotted">
<span class="red">
Внимание! Правильно указывайте свой адрес электронной почты!
<br />
Именно на него будет высылаться Ваш пароль. 
<br />
Ваш адрес электронной почты не будет виден другим пользователям.
</span>
<br />
<?=form_submit('submit', 'Сохранить E-mail', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>