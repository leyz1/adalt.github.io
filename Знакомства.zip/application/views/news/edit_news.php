<b>Новости</b> | Редактировать

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?=form_open(current_url())?>

<div class="dotted">
Заголовок (от 10 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 10 до 3000 символов):
<br />
<?=form_textarea($data['description'], FALSE)?>
</div>

<div class="dotted">
Резрешить писать комментарии ? <?=form_checkbox($data['access'])?>
<br />
<?=form_submit('submit', 'Редактировать новость', 'class="form"')?>
</div>


<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('news/comments/' . $data['news_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>