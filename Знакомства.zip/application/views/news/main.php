<b>Новости</b>

<?=br(2)?>

<?php if ($this->user->is_admin(array(10))) : ?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted"><?=anchor('news/add_news', 'Добавить новость')?></div>

<?php endif; ?>



<?php if($data['config']['access'] === FALSE) : ?>



<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=anchor('news/comments/' . $item['id'], show_text($item['title']))?> <span class="count">(<?=$this->news->count_all_comments_id($item['id'])?>)</span>
<br />
<?=show_text($item['description'])?>
<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<b>Разместил:</b> <?=data_user($this->user->parse_id($item['id_admin']))?>
<br />
<b>Рейтинг:</b> <?=$item['rating']?>

</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Нет новостей</b></div>

<?php endif; ?>



<?php else : ?>

<div class="error"><b>Доступ к новостям временно закрыт</b></div>

<?php endif; ?>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>
