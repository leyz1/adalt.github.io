<b>Новости</b> | Комментарии

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=show_text($data['news_data']['title'])?>
<br />---<br />
<?=show_text($data['news_data']['description'])?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($data['news_data']['time'])?>
<br />
<b>Разместил:</b> <?=data_user($this->user->parse_id($data['news_data']['id_admin']))?>
<br />

<?php if ($data['news_data']['edit_who']) : ?>
<span class="red">Отредактировал: <b><?=$data['news_data']['edit_who']?></b>, <?=show_display_date($data['news_data']['edit_time']) . ',' .nbs(). $data['news_data']['edit_count']?> раз(а).</span>
<br />
<?php endif; ?>

<?php if ($this->news->check_vote_news($data['news_data']['id']) === FALSE) : ?>
<a class="green" href="<?=base_url() . 'index.php/news/vote_news/' . $data['news_data']['id'] . '/plus'?>">Мне нравится</a> | <a class="red" href="<?=base_url() . 'index.php/news/vote_news/' . $data['news_data']['id'] . '/minus'?>">Не нравится</a>
<?php endif; ?>

</div>

<?php if ($this->user->is_admin(array(10))) : ?>

<div class="dotted"><?=anchor('news/edit_news/' . $data['news_data']['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('news/delete_news/' . $data['news_data']['id'], 'Удалить', 'class="red"') . nbs() . '|' . nbs() . anchor('news/trunce/' . $data['news_data']['id'], 'Очистить комментарии', 'class="blue"')?></div>

<?php endif; ?>



<?php if($data['config']['access'] === FALSE) : ?>



<?php if ($this->user->is_user()) : ?>



<?php if ($quarantine_time = $this->news->quarantine_time()) : ?>

<div class="error"><b>На сайте включен карантин для новых пользователей.</b></div>

<?php elseif($data['news_data']['access'] == 0) : ?>

<div class="error"><b>Обсуждение данной новости закрыто Администрацией.</b></div>

<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Отправить', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>



<?php endif; ?>



<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>

<?php if ($item['edit_who']) : ?>
<br />
<span class="red">Отредактировал: <b><?=$item['edit_who']?></b>, <?=show_display_date($item['edit_time']) . ',' .nbs(). $item['edit_count']?> раз(а).</span>
<?php endif; ?>
<br />---<br />

<?php if ($this->user->is_user() AND $user['id'] != $item['id_user'] AND $data['news_data']['access'] == 1) : ?>
[<?=anchor('news/reply_comments/' . $item['id'], 'ОТВЕТ', 'class="blue"')?>]
<?php endif; ?>
<?php if ($this->user->is_admin(array(10))) : ?>
<?=anchor('news/edit_comments/' . $item['id'], 'РЕДАКТИРОВАТЬ', 'class="orange"')?> | <?=anchor('news/delete_comments/' . $item['id'], 'УДАЛИТЬ', 'class="red"')?>
<?php endif; ?>

</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Нет комментариев</b></div>

<?php endif; ?>




<?php else : ?>

<div class="error"><b>Доступ к новостям временно закрыт.</b></div>

<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('news/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>