<b>Ошибка!</b>

<?=br(2)?>

<div class="error"><?=img('images/smileys/ops.gif')?> <b>Ето не твой фотоальбом.</b></div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

