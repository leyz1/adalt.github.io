<b>Фото</b> | Модерация фото

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Добавил:</b> <?=data_user($this->user->parse_id($item['id_user']))?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<?=img('images/icons/comments.png') . nbs() . anchor('photo/comments/' . $item['id'], show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->album->count_all_comments_id($item['id'])?>)</span>
<br />
<?=img('files/albums/' . $item['id_album'] . '/thumbs/' . $item['hash_file'] . '_thumb.png')?>
<br />---<br />
<b>Рейтинг:</b> <?=$item['rating']?>
<br />
<?=img('images/icons/download.png') . nbs() . anchor('album/download_file/' . $item['id_album'] . '/' . $item['hash_file'], 'Скачать оригинал (' . $item['file_size'] .' кб)', 'class="green"')?>
<br />---<br />
<?=form_open(current_url())?>
<?=form_hidden('id', $item['id'])?>
<?=form_submit('submit', 'Промодерировать', 'class="form"')?> <?=form_submit('delete', 'Удалить фото', 'class="form"')?>
<?=form_close()?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет фотографий.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>