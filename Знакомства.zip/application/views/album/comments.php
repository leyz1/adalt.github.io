<b>Фото</b> | Комментарии

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">
<b>Добавил:</b> <?=data_user($this->user->parse_id($data['user_data']['id']))?>
<br />
<b>Дата:</b> <?=show_display_date($data['photo_data']['time'])?>
<br />---<br />
<?=show_text($data['photo_data']['title'])?>
<br />
<?=img('files/albums/' . $data['album_data']['id'] . '/thumbs/' . $data['photo_data']['hash_file'] . '_thumb.png')?>
<br />---<br />
<b>Рейтинг:</b> <?=$data['photo_data']['rating']?>
<br />
<?=img('images/icons/download.png') . nbs() . anchor('album/download_file/' . $data['album_data']['id'] . '/' . $data['photo_data']['hash_file'], 'Скачать оригинал (' . $data['photo_data']['file_size'] .' кб)', 'class="green"')?>
<br />
</div>

<?php if ($quarantine_time = $this->album->quarantine_time()) : ?>

<div class="error"><b>На сайте включен карантин для новых пользователей.</b></div>

<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Отправить', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>



<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
<br />

<?php if ($user['id'] != $item['id_user']) : ?>
[<?=anchor('album/reply_comments/' . $item['id'], 'ОТВЕТ', 'class="blue"')?>]
<? endif; ?>
<?php if ($user['id'] == $data['user_data']['id']) : ?>
<?=anchor('album/delete_comments/' . $item['id'], 'Удалить', 'class="red"')?>
<? endif; ?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>
<div class="dotted"><b>Нет комментариев</b></div>
<?php endif; ?>



<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('album/photo/' . $data['album_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>