<b>Ошибка!</b>

<?=br(2)?>

<div class="error"><?=img('images/smileys/ops.gif')?> <b>Комментирование фотографий отключено пользователем.</b></div>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
<br />
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>
<div class="dotted"><b>Нет комментариев</b></div>
<?php endif; ?>



<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

