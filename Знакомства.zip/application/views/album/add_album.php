<b>Фотоальбомы</b> | Создать альбом

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?=form_open(current_url())?> 

<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 5 до 255 символов, необязательно):
<br />
<?=form_input($data['description'])?>
<br />
<?=form_submit('submit', 'Создать альбом', 'class="form"')?>
</div>

<?=form_close()?> 

<?php else : ?>
<div class="error"><b>Доступ к фотоальбомам временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('album/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>