<b>Чат</b> | Редактировать комнату

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>



<?=form_open(current_url())?>

<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 10 до 255 символов):
<br />
<?=form_input($data['description'])?>
</div>

<div class="dotted">
Боты:
<?php
	
    if ($data['room_data']['nerd'] == 1)
    {
        $bot = 1;
    }
    elseif ($data['room_data']['nerd2'] == 1)
    {
        $bot = 2;
    }
    else
    {
        $bot = 0;
    }
?>
<br />

<?=form_dropdown('bot', $data['bot'], $bot, 'class="form"')?>
</div>

<div class="dotted">
Доступ к комнате включить/отключить <?=form_checkbox($data['access'])?>
<br />
Принимать ответы с компьютера ? <?=form_checkbox($data['pc_answers'])?>
<br />
<?=form_submit('submit', 'Редактировать комнату', 'class="form"')?>
</div>

<?=form_close()?>



<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('chat/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>