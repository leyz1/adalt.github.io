<?=anchor('chat/index', '<b>Чат</b>')?> | <?=anchor('chat/room/' . $data['room_data']['id'], $data['room_data']['title'])?> | Кто здесь?

<?=br(2)?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>В комнате только Вы.</b></div>
<?php endif; ?>


<?php else : ?>
<div class="error"><b>Доступ к чату временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('chat/room/' . $data['room_data']['id'], 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>