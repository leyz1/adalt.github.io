<?=anchor('chat/index', '<b>Чат</b>')?> | <?=$data['room_data']['title']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">[<?=anchor(current_url(), 'ОБНОВИТЬ', 'class="blue"')?>] <?=anchor('chat/who_room/' . $data['room_data']['id'], 'Кто здесь?', 'class="green"')?></div>

<?php if($data['room_data']['access'] == 0) : ?>
<div class="error"><b>Извините. Данная комната времено закрыта модератором.</b></div>
<?php elseif ($quarantine_time = $this->chat->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете общаться в комнатах чата.</b></div>
<?php elseif ($data['room_data']['pc_answers'] == 0 AND (strpos($this->input->user_agent(), "Opera") !== FALSE OR strpos($this->input->user_agent(), "M3Gate") !== FALSE OR strpos($this->input->user_agent(), "emulator") !== FALSE OR strpos($this->input->user_agent(), "WinWAP") !== FALSE OR strpos($this->input->user_agent(), "Wapsilon") !== FALSE OR strpos($this->input->user_agent(), "Mozilla") !== FALSE OR strpos($this->input->user_agent(), "M3GATE") !== FALSE)) : ?>
<div class="error"><b>Пользователям ПК нет возможности писать в данной комнате.</b></div>
<?php elseif ($this->user->is_user()) : ?>


<?=form_open(current_url())?>

<div class="dotted">
Сообщение (от 1 до 1000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Написать', 'class="form"')?>
</div>

<?=form_close()?>


<?php endif; ?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?php if ($item['id_user'] > 0) : ?>
<?=data_user($this->user->parse_id($item['id_user']))?>
<?php elseif ($item['id_user'] == 0 AND $data['room_data']['nerd'] == 1) : ?>
<?=img('images/icons/m.png') . nbs() . anchor(current_url(), $data['config']['bot_nerd']) . nbs() . img('images/icons/qip_online.png')?>
<?php elseif ($item['id_user'] == 0 AND $data['room_data']['nerd2'] == 1) : ?>
<?=img('images/icons/m.png') . nbs() . anchor(current_url(), $data['config']['bot_nerd2']) . nbs() . img('images/icons/qip_online.png')?>
<?php endif; ?>

<?php if ($item['id_private'] == $user['id']) : ?>
<span class="red"><b>!ПРИВАТНО!</b></span>
<br />
<?=show_text($item['description'])?>
<?php elseif ($item['id_private'] > 0 AND $item['id_private'] != $user['id']) : ?>
<b>приватно для:</b> <?=data_user($this->user->parse_id($item['id_private']))?>
<br />
Сообщение доступно только получателю.
<?php elseif ($item['id_private'] == 0 AND $item['id_reply'] > 0) : ?>
<b>ответ для:</b> <?=data_user($this->user->parse_id($item['id_reply']))?>
<br />
<?=show_text($item['description'])?>
<?php else : ?>
<br />
<?=show_text($item['description'])?>
<?php endif; ?>

<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?php if ($this->user->is_user() AND $item['id_user'] != $user['id'] AND $item['id_user'] > 0 AND $data['room_data']['pc_answers'] == 1 AND $data['room_data']['access'] == 1) : ?>
<?=anchor('chat/reply_post/' . $item['id'], 'ОТВЕТ', 'class="blue"')?> | <?=anchor('chat/private_post/' . $item['id'], 'ПРИВАТНО', 'class="orange"')?>
<?php endif; ?>


<?php if ($this->user->is_admin(array(2, 10))) : ?>
<?=anchor('chat/delete_post/' . $item['id'], 'УДАЛИТЬ', 'class="red"')?>
<?php endif; ?>

</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Нет сообщений</b></div>
<?php endif; ?>


<?php else : ?>
<div class="error"><b>Доступ к чату временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('chat/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>