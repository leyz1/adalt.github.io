<div class="title"><b>Новые сообщения</b> </div>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_to']), 'contacts/messages')?> <?=$this->contact->count_all_new_messages_id($item['id_to'])?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Новых сообщений нет.</b></div>
<?php endif; ?>


<div class="menu">
<?=anchor('contacts/index', img('images/icons/back.png') . nbs() . 'Вернуться назад')?>
</div>

<div class="menu">
<?=anchor(base_url(), img('images/icons/home.png') . nbs() . 'Главная')?>
</div>