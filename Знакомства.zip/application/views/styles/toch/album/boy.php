<b>Альбомы</b> | Парни

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/photo_album.png') . nbs() . anchor('album/photo/' . $item['id'] . '/', show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->album->count_all_album_photo($item['id'])?>)</span>
<br />

<b>Описание:</b> <?=($item['description'] ? show_text($item['description']) : 'Без описания.')?>
<br />---<br />
<b>Добавил:</b> <?=data_user($this->user->parse_id($item['id_user']))?>  <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />
<b>Создан:</b> <?=show_display_date($item['time_create'])?>
<br />
<b>Обновлен:</b> <?=($item['time'] ? show_display_date($item['time']) : 'Не обновлялся.')?>
<br />
<?=($user['id'] == $item['id_user'] ? '---<br />' . anchor('album/edit_album/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('album/delete_album/' . $item['id'], 'Удалить', 'class="red"') : '')?>

</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет фотоальбомов.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('album/gender/', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>