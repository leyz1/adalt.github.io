<b>Фото</b> | Комментарии

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($quarantine_time = $this->album->quarantine_time()) : ?>

<div class="error"><b>На сайте включен карантин для новых пользователей.</b></div>

<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Ответить', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>



<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('album/comments/' . $data['photo_data']['id'], 'Вернуться назазд')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>