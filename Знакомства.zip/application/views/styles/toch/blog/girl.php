<b>Дневники</b> | Девушки

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/comments.png') . nbs() . anchor('blog/comments/' . $item['id'] . '/', show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->blog->count_all_blog_comments($item['id'])?>)</span>
<br />---<br />
<b>Добавила:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />
<b>Рейтинг:</b> <?=$item['rating']?>
<br />
<?=img('images/icons/folder.png') . nbs() . anchor('blog/files/' . $item['id'] . '/', 'Файлы', 'class="orange"')?> <span class="count">(<?=$this->blog->count_all_blog_files($item['id'])?>)</span>
<br />
<?php if ($this->blog->check_vote_blog($item['id']) === FALSE) : ?>
<a class="green" href="<?=base_url() . 'index.php/blog/vote_blog/' . $item['id'] . '/plus'?>">Мне нравится</a> | <a class="red" href="<?=base_url() . 'index.php/blog/vote_blog/' . $item['id'] . '/minus'?>">Не нравится</a>
<br />
<?php endif; ?>
<?=($user['id'] == $item['id_user'] ? '---<br />' . anchor('blog/edit_blog/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('blog/delete_blog/' . $item['id'], 'Удалить', 'class="red"') : '')?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет дневников.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('blog/gender/', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>