<b>Дневники</b> | Комментарии

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">
<?=show_text($data['blog_data']['title'])?>

<?php
	 if (file_exists(APPPATH . '../files/blogs/' . $data['blog_data']['id'] . '/' . $this->function->htmlspecialchars($data['blog_data']['hash_file']) . '.png'))
     {
?>
<br />
<?=img('files/blogs/' . $data['blog_data']['id'] . '/thumbs/' . $data['blog_data']['hash_file'] . '_thumb.png')?>
<?
     }     
?>
<br />---<br />
<?=($data['word'] == 'word_limiter' ? show_text(word_limiter($data['blog_data']['description'], 30, '...')) . '<br />' . anchor('blog/comments/' . $data['blog_data']['id'] . '/word/', 'Читать полностью &raquo;') : show_text($data['blog_data']['description']) . '<br />' . anchor('blog/comments/' . $data['blog_data']['id'] . '/word_limiter/', 'Сократить текст &raquo;'))?>
<br />
<b>Добавил:</b> <?=data_user($this->user->parse_id($data['blog_data']['id_user']))?> <?=(city($this->user->parse_id($data['blog_data']['id_user'])) !== FALSE ? city($this->user->parse_id($data['blog_data']['id_user'])) : '')?>
<br />
<b>Дата:</b> <?=show_display_date($data['blog_data']['time'])?>
<br />
<b>Рейтинг:</b> <?=$data['blog_data']['rating']?>
<br />---<br />
<?=($user['id'] == $data['user_data']['id'] ? anchor('blog/add_image/' . $data['blog_data']['id'], '+ Прикрепить картинки +<br />', 'class="green"') : '')?>
<?=img('images/icons/folder.png') . nbs() . anchor('blog/files/' . $data['blog_data']['id'] . '/', 'Файлы', 'class="orange"')?> <span class="count">(<?=$this->blog->count_all_blog_files($data['blog_data']['id'])?>)</span>
</div>


<?php if ($quarantine_time = $this->blog->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 3 до 1024 символов): <?=anchor('page/smileys', 'Смайлы', 'class="orange"')?>
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Отправить', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>

<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
<br />

<?php if ($user['id'] != $item['id_user']) : ?>
[<?=anchor('blog/reply_comments/' . $item['id'], 'ОТВЕТ', 'class="blue"')?>]
<? endif; ?>
<?php if ($user['id'] == $data['user_data']['id']) : ?>
<?=anchor('blog/delete_comments/' . $item['id'], 'Удалить', 'class="red"')?>
<? endif; ?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>
<div class="dotted"><b>Нет комментариев</b></div>
<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к дневникам временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('blog/index/' . $data['user_data']['id'], 'Вернуться назазд')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>