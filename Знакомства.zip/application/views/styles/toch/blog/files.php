<b>Дневники</b> | Файлы

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">
<?=show_text($data['blog_data']['title'])?>
<br />---<br />
<?=($user['id'] == $data['user_data']['id'] ? anchor('blog/add_image/' . $data['blog_data']['id'], '+ Прикрепить картинки +<br />', 'class="green"') : '')?>
</div>

<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=img('files/blogs/' . $item['id_blog'] . '/thumbs/' . $item['hash_file'] . '_thumb.png')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=img('images/icons/download.png') . nbs() . anchor('blog/download_file/' . $item['id_blog'] . '/' . $item['hash_file'], 'Скачать оригинал (' . $item['file_size'] .' кб)', 'class="green"')?>
<br />
<?php if ($user['id'] == $data['user_data']['id']) : ?>
<?=form_open(current_url())?>
<?=form_hidden('id_file', $item['id'])?>
<?=form_submit('submit', 'Сделать логотипом дневника', 'class="form"')?> 
<?=form_submit('delete', 'Удалить файл', 'class="form"')?>
<?=form_close()?>
<?php endif; ?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>
<div class="dotted"><b>Нет файлов</b></div>
<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к дневникам временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('blog/comments/' . $data['blog_data']['id'], 'Вернуться назазд')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>