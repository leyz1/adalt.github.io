<b>Стена сообщений</b>

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">
[<?=anchor(current_url(), 'ОБНОВИТЬ', 'class="blue"')?>] <?=anchor('page/smileys', 'Смайлы', 'class="orange"')?> | <?=anchor('wall/who_wall/', 'Кто здесь?', 'class="green"')?>
</div>

<?php if ($quarantine_time = $this->wall->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Подождите немного.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Сообщение (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'], FALSE)?>
<br />
<?=anchor('wall/add_image/', '+ Прикрепить файл +', 'class="green"')?>
<br />
<?=form_submit('submit', 'Написать', 'class="form"')?>
</div>


<?=form_close()?>
<?php endif; ?>


<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />

<?php
	 if (file_exists(APPPATH . '../files/walls/' . $this->function->htmlspecialchars($item['hash_file']) . '.png'))
     {
?>
<?=img('files/walls/thumbs/' . $item['hash_file'] . '_thumb.png')?>
<br />
<?=img('images/icons/download.png') . nbs() . anchor('wall/download_file/' . $item['hash_file'], 'Скачать оригинал (' . $item['file_size'] .' кб)', 'class="green"')?>
<br />
<?
     }     
?>

<?=show_text($item['description'])?>
<br />
<?php if ($user['id'] != $item['id_user']) : ?>
[<?=anchor('wall/reply_post/' . $item['id'], 'ОТВЕТ', 'class="blue"')?>]
<?php endif; ?>

<?php if ($this->user->is_admin(array(2, 5, 10))) : ?>
<?=anchor('wall/delete_post/' . $item['id'], 'Удалить', 'class="red"')?>
<?php endif; ?>

</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет сообщений.</b></div>
<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к стене сообщений временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>