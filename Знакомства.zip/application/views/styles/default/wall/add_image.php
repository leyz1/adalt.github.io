<b>Стена</b> | Добавить файлы

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($quarantine_time = $this->wall->quarantine_time()) : ?>

<div class="error"><b>На сайте включен карантин для новых пользователей. Заполните анкету!</b></div>

<?php else : ?>

<?=form_open_multipart(current_url())?> 

<div class="dotted">
Выберите файл для загрузки (JPEG, JPG, GIF, PNG):
<br />
<?=form_upload($data['upload_photo'], '', 'class="form"')?>

<br />
</div>

<div class="dotted">
Сообщение (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Добавить файл', 'class="form"')?>
</div>

<?=form_close()?> 
<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к стене временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('wall/index/', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>