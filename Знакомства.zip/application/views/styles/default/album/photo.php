<b>Фотоальбомы</b> | <?=$data['album_data']['title']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?=($user['id'] == $data['user_data']['id'] ? '<div class="dotted">' . anchor('album/add_photo/' . $data['album_data']['id'], 'Добавить фото в альбом', 'class="orange"') . '</div>' : '')?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Добавил:</b> <?=data_user($this->user->parse_id($item['id_user']))?>
<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<?=img('images/icons/comments.png') . nbs() . anchor('album/comments/' . $item['id'], show_text($item['title']), 'class="blue"')?> <span  class="count">(<?=$this->album->count_all_comments_id($item['id'])?>)</span>
<br />
<?=img('files/albums/' . $item['id_album'] . '/thumbs/' . $item['hash_file'] . '_thumb.png')?>
<br />---<br />
<b>Рейтинг:</b> <?=$item['rating']?>
<br />
<?php if ($this->album->check_vote_photo($item['id']) === FALSE) : ?>
<a class="green" href="<?=base_url() . 'index.php/album/vote_photo/' . $item['id'] . '/plus'?>">Мне нравится</a> | <a class="red" href="<?=base_url() . 'index.php/album/vote_photo/' . $item['id'] . '/minus'?>">Не нравится</a>
<br />
<?php endif; ?>
<?=img('images/icons/download.png') . nbs() . anchor('album/download_file/' . $item['id_album'] . '/' . $item['hash_file'], 'Скачать оригинал (' . $item['file_size'] .' кб)', 'class="green"')?>
<br />
<?=($user['id'] == $item['id_user'] ? '---<br />' . anchor('album/edit_photo/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('album/delete_photo/' . $item['id'], 'Удалить', 'class="red"') : '')?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет фотографий.</b></div>
<?php endif; ?>

<?php else : ?>
<div class="error"><?=img('images/smileys/ops.gif')?><b> Доступ к фотоальбомам временно закрыт.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('album/index/' . $data['user_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>