<b>Ошибка!</b>

<?=br(2)?>

<div class="error"><?=img('images/smileys/ops.gif')?> <b>Фотоальбом не найден в базе данных.</b></div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

