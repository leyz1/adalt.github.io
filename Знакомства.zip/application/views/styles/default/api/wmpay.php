<b>Оплата через Webmoney</b>

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>




<?php if ($this->input->post('submit') AND empty($data['error'])) : ?>

<form method="POST" action="https://merchant.webmoney.ru/lmi/payment.asp">
<input type="hidden" name="LMI_PAYMENT_AMOUNT" value="<?=$this->session->userdata('amount')?>"/>
<input type="hidden" name="LMI_PAYMENT_DESC_BASE64" value="<?=base64_encode('Игровые деньги Sizok.ru ' . $this->session->userdata('balls') . ' баллов для анкеты: ' .$this->session->userdata('user_id'))?>"/>
<input type="hidden" name="LMI_PAYMENT_NO" value="1"/>
<input type="hidden" name="LMI_PAYEE_PURSE" value="<?=$this->session->userdata('payee')?>"/>
<input type="hidden" name="anketaID" value="<?=$this->session->userdata('user_id')?>"/>
    
<div class="dotted">

Вы собираетесь приобрести <b><?=$this->session->userdata('balls')?></b> <?=img('images/icons/coins.png')?>, для анкеты <b><?=$this->session->userdata('user_id')?></b>. Цена <b><?=$this->session->userdata('amount')?></b> <?=$this->session->userdata('paytype')?>

</div>

<div class="dotted">
<?=form_submit('submit', 'Оплатить', 'class="form"')?>
</div>

<?=form_close()?>

<? else: ?>

<div class="dotted">
Расценки:
<br />
1 WMR = 100 <?=img('images/icons/coins.png')?>
<br /> 
1 WMZ = 3000 <?=img('images/icons/coins.png')?>
</div>

<?=form_open(current_url())?>

<div class="dotted">
Укажите ID анкеты (ID Вашей анкеты: <?=$user['id']?>):
<br />
<?=form_input($data['user_id'])?>
</div>

<div class="dotted">
Укажите сумму, которую вы собираетесь заплатить:
<br />
<?=form_input($data['amount'])?> <?=form_dropdown('paytype', $data['paytype'], 'WMR', 'class="form"')?>
</div>

<div class="dotted">
<?=form_submit('submit', 'Оплатить', 'class="form"')?>
</div>

<?=form_close()?>

<? endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>