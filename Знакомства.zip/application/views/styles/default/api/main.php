<b>Пополнить баланс:</b>

<br />

<div class="dotted">
[<?=img('images/icons/coins_add.gif') . nbs() . anchor(base_url() . 'index.php/api/addcash', 'Пополнить по SMS', 'class="green"')?>]
</div>

<div class="dotted">
[<?=img('images/icons/coins_add.gif') . nbs() . anchor(base_url() . 'index.php/api/wmpay', 'Пополнить по WebMoney', 'class="green"')?>]
</div>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>