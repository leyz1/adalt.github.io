<b>Пополнить баланс</b> | <?=$data['country_data']['country']?>

<br />

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($this->user->is_admin(array(10))) : ?>
<div class="dotted"><?=anchor('api/add_tarif/' . $data['country_data']['id'], 'Добавить тарифы для (' . $data['country_data']['country'] . ')')?></div>
<?php endif; ?>

<div class="dotted">
<b>Чтобы пополнить баланс, отправьте SMS с мобильного телефона с текстом:</b> <span class="red">845678+<?=$user['id']?></span>
</div>

<?php if ($data['foreach']) : ?>
<b><span class="blue">На номер</span></b> | <b><span class="orange">Получите</span></b> | <b><span class="red">Стоимость смс (руб.)</span> <a href="http://www.a1help.ru/t/" target="_blank">[точная стоимость]</a></b>
<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<b><?=$item['number']?></b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><?=$item['balls']?></b> <?=img('images/icons/coins.png')?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><?=$item['price']?></b>
<?php if ($this->user->is_admin(array(10))) : ?>
<br />---<br />
<?=anchor('api/edit_tarif/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs(). anchor('api/delete_tarif/' . $item['id'], 'Удалить', 'class="red"')?>
<?php endif; ?>
</div>
<? endforeach; ?>


<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Сервер базы данных сейчас не доступен.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>