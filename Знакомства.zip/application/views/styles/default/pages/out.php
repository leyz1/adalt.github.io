<b>Выход</b>

<?=br(2)?>

<?=form_open(current_url())?>

<div class="dotted">

Вы действительно хотите покинуть сайт?
<br />

<?=form_submit('submit', 'Выход', 'class="form"')?>

<?=br(2)?>

<?=form_submit('cancell', 'Отмена', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>
