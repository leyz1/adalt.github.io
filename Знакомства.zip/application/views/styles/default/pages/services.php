<b>Сервисы/Услуги</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=img('images/icons/draw_star.png') . nbs() . anchor('page/star_search', 'Звезда поиска', 'class="orange"')?>
</div>

<div class="dotted">
<?=img('images/icons/anketa.png') . nbs() . anchor('page/anketa_day', 'Анкета дня', 'class="orange"')?>
</div>

<div class="dotted">
<?=img('images/icons/search.png') . nbs() . anchor('page/anketa_up', 'Поднять анкету', 'class="orange"')?>
</div>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>