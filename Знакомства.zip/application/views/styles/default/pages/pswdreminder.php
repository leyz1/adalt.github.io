<div class="head"><?=anchor(base_url(), 'SIZOK.RU')?></div>

<b>Восстановление пароля</b>

<?=br(2)?>
<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
Логин:
<br />
<?=form_input($data['login'])?>
</div>

<div class="dotted">
E-mail:
<br />
<?=form_input($data['mail'])?>
<br />
<b><span class="red">Если у вас в анкете отсутствует запись о вашем e-mail, восстановление пароля невозможно.</span></b>
<br />
<?=form_submit('submit', 'Выслать пароль', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>
