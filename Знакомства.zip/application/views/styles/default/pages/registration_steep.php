<div class="head"><?=anchor(base_url(), 'SIZOK.RU')?></div>

<?=($this->session->userdata('login') !== FALSE ? '<b>Регистрация</b> Шаг 2 из 2' : '<b>Регистрация</b> Шаг 1 из 2')?>

<?=br(2)?>
<?=validation_errors()?>
<?=error($data['error'])?>
<?php if ($registration === FALSE) : ?>


<?php if ($this->session->userdata('login') !== FALSE) : ?>

<?=form_open(current_url())?>

<div class="dotted"> 
<b>Ваш логин:</b> <?=$this->session->userdata('login')?>
</div>

<div class="dotted">
Введите Ваше имя или ник (от 3 до 20 символов, может содержать ТОЛЬКО буквы русского или ТОЛЬКО латинского алфавита, а так же пробел), имя можно будет изменить:
<br />
<?=form_input($data['name'])?>
</div>

<div class="dotted">
Пароль (от 6 до 40 символов, должен состоять только из букв латинского алфавита и цифр):
<br />
<?=form_password($data['password'])?>
</div>

<div class="dotted">
Пол:
<br />
<?=form_dropdown('gender', $data['gender'], 'm', 'class="form"')?>
</div>

<div class="dotted">
Дата рождения (в формате ДД.ММ.ГГГГ):
<br />
<?=form_input($data['day']) . nbs() . form_input($data['month']) . nbs() . form_input($data['year'])?>
</div>

<div class="dotted">
Код:
<br />
<?=$data['code']['image']?>
<br />            
<?=form_input($data['captcha'])?>
</div>

<div class="dotted">
<?=form_submit('submit', 'Регистрация', 'class="form"')?>
<br />
Нажимая кнопку "Регистрация" Вы автомачески соглашаетесь с <?=anchor('page/service', 'Правилами сайта')?>.
</div>

<?=form_close()?>

<? else: ?>

<?=form_open(current_url())?>

<div class="dotted">
Введите желаемый логин (от 3 до 20 символов, может содержать буквы ТОЛЬКО латинского алфавита и цифры):
<br />
<?=form_input($data['login'])?>
<br />
<?=form_submit('submit', 'Далее', 'class="form"')?>
</div>

<?=form_close()?>
<?php endif; ?>


<?php else : ?>
<div class="error"><b>Регистрация временно приостановлена</b></div>
<?php endif; ?>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>
