<b>Пользователи</b> | Все

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id']))?>  <?=(birt($this->user->parse_id($item['id'])) !== FALSE ? birt($this->user->parse_id($item['id'])) : '')?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>

</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Никого нет.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/search.png') . nbs() . anchor('page/search', 'Поиск')?>
<br />
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $user['id'], 'Профиль ' . $user['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>