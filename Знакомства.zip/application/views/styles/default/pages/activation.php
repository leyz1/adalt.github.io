<b>Ошибка</b>

<?=br(2)?>
<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<b><span class="red">Анкета деактивирована.</span></b>
<br />
Для выяснения причины деактивации пишите на <span class="green"><?=$email?></span>, с указанием в теме вашего Логина на сайте.
</div>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>
