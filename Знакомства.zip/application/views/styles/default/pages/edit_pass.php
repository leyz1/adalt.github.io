<b>Изменение пароля</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Новый пароль:</b>
<br />
<?=form_input($data['password'])?>
<br />
<?=form_submit('submit', 'Изменить пароль', 'class="form"')?>
</div>
<?=form_close()?>



<div class="dotted">
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>