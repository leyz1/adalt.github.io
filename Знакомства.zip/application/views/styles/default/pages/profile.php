<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['user_data']['delete'] == 1) : ?>
<div class="dotted"><b><span class="red">Анкета етого пользователя деактивирована.</span></b></div>
<?php endif; ?>

<?php if ($user['id'] != $data['user_data']['id']) : ?>
<div class="dotted"><?=img('images/icons/mail.png') . nbs() . anchor('contacts/messages/' . $data['user_data']['id'], 'Написать сообщение', 'class="blue"')?></div>
<?php endif; ?>

<div class="dotted">
<b>ID:</b> <span class="blue"><?=$data['user_data']['id']?></span>
<br />
<!--<b>Логин:</b> <span class="blue"><?=$data['user_data']['login']?></span>
<br />
-->
<b>Имя:</b> <span class="orange"><?=($data['user_data']['name'] === '' ? $data['user_data']['login'] : $data['user_data']['name'])?></span>
<br />
<b>Пол:</b> <?=($data['user_data']['gender'] == 'm' ? 'Мужской' : 'Женский')?>
<br />
<b>Возраст:</b> <?=(birt($data['user_data']) !== FALSE ? birt($data['user_data']) : '<span class="red">Анкетные данные не заполнены.</span>')?>
<br />
<b>Знак зодиака:</b> <?=(zodiak($data['user_data']) !== FALSE ? zodiak($data['user_data']) : '<span class="red">Анкетные данные не заполнены.</span>')?>
<br />
<b>Город:</b> <?=(city($data['user_data']) !== FALSE ? city($data['user_data']) : '<span class="red">Город проживания не выбран.</span>') . nbs() . ($user['id'] == $data['user_data']['id'] ? '[' . anchor('city/country', 'Редактировать', 'class="green"') . ']' : NULL)?>
<br />
<!--<b>Должность:</b>--> <? //=$this->user->access_user($data['user_data'])?>
</div>

<?=($data['user_data']['welcome_msg'] ? '<div class="dotted">' . show_text($data['user_data']['welcome_msg']) . '</div>' : '')?>

<div class="dotted">
<?=show_avatar($data['user_data'])?>
</div>

<div class="dotted"><?=img('images/icons/anketa.png') . nbs() . anchor('page/anketa/' . $data['user_data']['id'], 'Анкета', 'class="orange"')?></div>

<?php if ($user['id'] != $data['user_data']['id']) : ?>
<div class="dotted"><?=img('images/icons/present.png') . nbs() . anchor('shopping/present/' . $data['user_data']['id'], 'Сделать подарок', 'class="blue"')?></div>
<?php endif; ?>

<?php if ($this->user->check_friends($data['user_data']['id'])) : ?>
<div class="dotted"><?=img('images/icons/delete_friends.png') . nbs() . anchor('friends/delete_friends/' . $data['user_data']['id'], 'Удалить из друзей', 'class="red"')?></div>
<?php elseif ($user['id'] != $data['user_data']['id']) : ?>
<div class="dotted"><?=img('images/icons/app_friends.png') . nbs() . anchor('friends/add_friends/' . $data['user_data']['id'], 'Добавить в друзья', 'class="orange"')?></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/gift.png') . nbs() . anchor('page/present/' . $data['user_data']['id'], 'Подарки')?> <span class="count">(<?=$this->shop->count_all_gift_id_user($data['user_data']['id'])?>)</span>
<br />
<?=img('images/icons/friends.png') . nbs() . anchor('friends/index/' . $data['user_data']['id'], 'Друзья')?> <span class="count">(<?=$this->friend->count_all_friends($data['user_data']['id'])?>)</span>
<br />
<?=img('images/icons/photo.png') . nbs() . anchor('photo/index/' . $data['user_data']['id'], 'Галерея')?> <span class="count">(<?=$this->photo->count_all_photo_id($data['user_data']['id'])?>)</span>
<br />
<?=img('images/icons/photo_album.png') . nbs() . anchor('album/index/' . $data['user_data']['id'], 'Фотоальбомы')?> <span class="count">(<?=$this->album->count_all_album_id_user($data['user_data']['id'])?>)</span>
<br />
<?=img('images/icons/blog.png') . nbs() . anchor('blog/index/' . $data['user_data']['id'], 'Дневники')?> <span class="count">(<?=$this->blog->count_all_blog_id_user($data['user_data']['id'])?>)</span>
</div>

<?php if ($user['id'] == $data['user_data']['id']) : ?>
<div class="dotted"><?=img('images/icons/config.png') . nbs() . anchor('profile/index', 'Мой профиль')?></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/coins.png')?> Баллы: <span class="count">(<?=$data['user_data']['balls']?>)</span>
<?=img('images/icons/iq.png')?> IQ: <span class="count">(<?=$data['user_data']['iq']?>)</span>

</div>

<div class="dotted">
<?=(now() > $data['user_data']['date_login'] + 600 ? '<b>Последний визит:</b>' . nbs() . '<span class="green">' . show_display_date($data['user_data']['date_login']) . '</span>' : img('images/icons/qip_online.png') . nbs() . '<b><span class="green">Сейчас на сайте</span></b>')?>
<br />
<b>Регистрация:</b> <?=show_display_date($data['user_data']['date_registration'])?>
</div>

<div class="dotted">
Ссылка на профиль: <input type="text" value="<?=htmlspecialchars(current_url())?>" class="form" size="64" />
</div>
<?php if ($this->user->is_admin(array(10))) : ?>
<div class="menu"><?=img('images/icons/edit.png') . nbs() . anchor('page/edit_user/' . $data['user_data']['id'], 'Редактировать профиль')?> | <?=anchor('page/edit_login/' . $data['user_data']['id'], 'Логин')?> | <?=anchor('page/edit_pass/' . $data['user_data']['id'], 'Пароль')?></div>
<?php endif; ?>

<?php if ($this->user->is_admin(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) AND ($user['id'] != $data['user_data']['id'])) : ?>
<div class="menu"><?=img('images/icons/siren.png') . nbs() . anchor('page/baned/' . $data['user_data']['id'], 'Забанить Урку')?></div>
<div class="dotted">
<b>UA:</b> <?=$data['user_data']['user_agent']?>
<br />
<b>IP:</b> <?=$data['user_data']['ip']?>
</div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>