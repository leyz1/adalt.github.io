<div class="logo"><?=img('styles/' . $style . '/img/wapdoza.png')?></div>

<div class="top">Сайт знакомств Sizok.Ru это анкеты девушек и парней со всего света. <a href="<?=base_url()?>index.php/page/registration/">Регистрируйтесь</a>  и начинайте знакомиться.</div>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="vhod">
Логин:
<br />
<?=form_input($data['login'])?>
<br />
Пароль: <?=anchor('page/pswdreminder', 'Забыли пароль?', 'class="reg"')?>
<br />
<?=form_password($data['password'])?>
<br />
<?=form_submit('submit', 'Войти на сайт', 'class="form"')?>
</div>

<?=form_close()?>

<div class="menu"><b><?=anchor('page/registration', 'Бесплатная регистрация &raquo;', 'class="reg"')?></b></div>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="menu">

<?=data_user($this->user->parse_id($item['id']))?>  <?=(birt($this->user->parse_id($item['id'])) !== FALSE ? birt($this->user->parse_id($item['id'])) : '')?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>
<br />
<?=show_avatar($this->user->parse_id($item['id']))?>

</div>

<? endforeach; ?>


<?php else : ?>
<div class="dotted"><b>Никого нет.</b></div>
<?php endif; ?>

<div class="menu"><b><?=anchor('page/registration', 'Бесплатная регистрация &raquo;', 'class="reg"')?></b></div>
