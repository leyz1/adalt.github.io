<b>Редактирование профиля</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Пол:</b>
<br />
<?=form_dropdown('gender', $data['gender'], $data['user_data']['gender'], 'class="form"')?>
</div>

<div class="dotted">
<b>Приветствие:</b>
<br />
<?=form_input($data['welcome_msg'])?>
</div>

<div class="dotted">
<b>Баллы:</b>
<br />
<?=form_input($data['balls'])?>
</div>

<div class="dotted">
<b>Статус анкеты:</b>
<br />
<?=form_dropdown('deleted', $data['deleted'], $data['user_data']['delete'], 'class="form"')?>
</div>

<div class="dotted">
<b>Должность:</b>
<br />
<?=form_dropdown('level', $data['level'], $data['user_data']['level'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Редактировать', 'class="form"')?>
</div>
<?=form_close()?>



<div class="dotted">
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>