<b>Сервисы/Услуги</b> | Поднять анкету

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
- <?=anchor('page/services', 'Назад в (Сервисы/Услуги)', 'class="green"')?>
</div>

<div class="dotted">
<b>Услуга:</b> Поднять анкету
<br />
<b>Статус:</b> 

<?php
	if ($user['date_anketa_up'] >= now())
    {
        echo 'Активирована до: ' . show_display_date($user['date_anketa_up']);
    }
    else
    {
        echo '<span class="red">Не активирована.</span>';
    }
?>

<br />---<br />
Чтобы подняться в результатах поиска, просто активируйте данную услугу. Обратите внимание, что при появлении каждого нового участника, ваша анкета будет смещаться на одну позицию вниз. 
<br />
Так же ваша анкета будет смещаться вниз, при активации данной услуги другими участниками из вашего города.
<br />
Услуга действует в течение одной недели.
<br />---<br />
Стоимость услуги составляет <?=img('images/icons/coins.png')?> 10000 баллов.
</div>

<div class="dotted">
<?=form_open(current_url())?>
<span class="red">Внимание:</span> с Вашего баланса будет списано 10000 баллов, после нажатия кнопки "Активировать услугу".
<br />
<?=form_submit('submit', 'Активировать услугу', 'class="form"')?>
</div>

<?=form_close()?>
</div>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>