<b>Мой журнал событий</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
</div>

<? endforeach; ?>

<div class="dotted"><?=img('images/icons/trash.png') . nbs() . anchor('page/trunce_journal', 'Очистить журнал', 'class="green"')?></div>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет событий.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>