<b>Анкета</b> | <?=anchor('page/profile/' . $data['user_data']['id'], $data['user_data']['login'])?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<b>ID:</b> <span class="blue"><?=$data['user_data']['id']?></span>
<br />
<b>Логин:</b> <span class="orange"><?=$data['user_data']['login']?></span>
<br />
<?=($data['user_data']['name'] ? '<b>Имя:</b>' . $data['user_data']['name'] . '<br />' : '')?>
<b>Пол:</b> <?=($data['user_data']['gender'] == 'm' ? 'Мужской' : 'Женский')?>
<br />
<b>Возраст:</b> <?=(birt($data['user_data']) !== FALSE ? birt($data['user_data']) : '<span class="red">Анкетные данные не заполнены.</span>')?>
<br />
<b>Знак зодиака:</b> <?=(zodiak($data['user_data']) !== FALSE ? zodiak($data['user_data']) : '<span class="red">Анкетные данные не заполнены.</span>')?>
<br />
<b>Город:</b> <?=(city($data['user_data']) !== FALSE ? city($data['user_data']) : '<span class="red">Город проживания не выбран.</span>') . nbs() . ($user['id'] == $data['user_data']['id'] ? '[' . anchor('city/country', 'Редактировать', 'class="green"') . ']' : NULL)?>
<br />
<b>Должность:</b> <?=$this->user->access_user($data['user_data'])?>
<?=($data['user_data']['skype'] ? '<br /><b>Skype:</b> ' . $data['user_data']['skype'] : '')?>
<?=($data['user_data']['icq'] ? '<br /><b>ICQ:</b> ' . $data['user_data']['icq'] : '')?>
<?=($data['user_data']['vk'] ? '<br /><b>VK:</b> id' . $data['user_data']['vk'] : '')?>
<?=($user['id'] == $data['user_data']['id'] ? '<br />' . img('images/icons/edit.png') .nbs() . anchor('profile/edit_anketa1', 'Редактировать', 'class="green"') : '')?>
</div>

<?=($data['user_data']['welcome_msg'] ? '<div class="dotted">' . show_text($data['user_data']['welcome_msg']) . '</div>' : '')?>

<div class="dotted">
<?=show_avatar($data['user_data'])?>
</div>

<div class="dotted">
<?=($data['user_data']['growth'] ? '<b>Рост:</b> ' . $data['user_data']['growth'] . ' см.<br />' : '')?>
<?=($data['user_data']['weight'] ? '<b>Вес:</b> ' . $data['user_data']['weight'] . ' кг.<br />' : '')?>
<?=($data['user_data']['eye_color'] ? '<b>Цвет глаз:</b> ' . $data['user_data']['eye_color'] . '<br />' : '')?>
<?=($data['user_data']['hair_color'] ? '<b>Цвет волос:</b> ' . $data['user_data']['hair_color'] . '<br />' : '')?>
<?php
	if ($data['user_data']['body_build'] == 1)
    {
        $body_build = 'Обычное';
    }
    elseif ($data['user_data']['body_build'] == 2)
    {
        $body_build = 'Худощавое';
    }
    elseif ($data['user_data']['body_build'] == 3)
    {
        $body_build = 'Спортивное';
    }
    elseif ($data['user_data']['body_build'] == 4)
    {
        $body_build = 'Мускулистое';
    }
    elseif ($data['user_data']['body_build'] == 5)
    {
        $body_build = 'Плотное';
    }
    elseif ($data['user_data']['body_build'] == 6)
    {
        $body_build = 'Полное';
    }
    elseif ($data['user_data']['body_build'] == 0)
    {
        $body_build = 'Не указано';
    }
?>
<b>Телосложение:</b> <?=$body_build?>
<br />
<?=($data['user_data']['nature'] ? '<b>Характер:</b> ' . $data['user_data']['nature'] . '<br />' : '')?>
<?php
	if ($data['user_data']['regimen'] == 1)
    {
        $regimen = 'Я - сова';
    }
    elseif ($data['user_data']['regimen'] == 2)
    {
        $regimen = 'Я - жаворонок';
    }
    elseif ($data['user_data']['regimen'] == 0)
    {
        $regimen = 'Не указано';
    }
?>
<b>Режим дня:</b> <?=$regimen?>
<br />
<?=($data['user_data']['prof'] ? '<b>Профессия:</b> ' . $data['user_data']['prof'] . '<br />' : '')?>
<?=($data['user_data']['life'] ? '<b>Жизненные цели:</b> ' . $data['user_data']['life'] . '<br />' : '')?>
<?=($user['id'] == $data['user_data']['id'] ? img('images/icons/edit.png') .nbs() . anchor('profile/edit_anketa2', 'Редактировать', 'class="green"') : '')?>
</div>

<div class="dotted">
<?php
	if ($data['user_data']['sex_orient'] == 1)
    {
        $sex_orient = 'Гетеро';
    }
    elseif ($data['user_data']['sex_orient'] == 2)
    {
        $sex_orient = 'Гей';
    }
    elseif ($data['user_data']['sex_orient'] == 3)
    {
        $sex_orient = 'Би';
    }
    elseif ($data['user_data']['sex_orient'] == 0)
    {
        $sex_orient = 'Не указано';
    }
?>
<b>Ориентация:</b> <?=$sex_orient?>
<br />
<?php
	if ($data['user_data']['getting_target1'] == 1)
    {
        $getting_target1 = 'Дружба и общение.';
    }
    else
    {
        $getting_target1 = '';
    }
    if ($data['user_data']['getting_target2'] == 1)
    {
        $getting_target2 = ' Флирт, СМС-переписка.';
    }
    else
    {
        $getting_target2 = '';
    }
    if ($data['user_data']['getting_target3'] == 1)
    {
        $getting_target3 = ' Любовь, отношения.';
    }
    else
    {
        $getting_target3 = '';
    }
    if ($data['user_data']['getting_target4'] == 1)
    {
        $getting_target4 = ' Брак, создание семьи.';
    }
    else
    {
        $getting_target4 = '';
    }
    if ($data['user_data']['getting_target5'] == 1)
    {
        $getting_target5 = ' Виртуальный секс.';
    }
    else
    {
        $getting_target5 = '';
    }
    if ($data['user_data']['getting_target6'] == 1)
    {
        $getting_target6 = ' Секс в реале.';
    }
    else
    {
        $getting_target6 = '';
    }
?>
<b>Цель знакомства:</b> <?=$getting_target1 . $getting_target2 . $getting_target3 . $getting_target4 . $getting_target5 . $getting_target6?>
<br />
<?php
	if ($data['user_data']['family'] == 1)
    {
        $family = 'Женат/Замужем';
    }
    elseif ($data['user_data']['family'] == 2)
    {
        $family = 'Холост/Не замужем';
    }
    elseif ($data['user_data']['family'] == 3)
    {
        $family = 'Живем раздельно';
    }
    elseif ($data['user_data']['family'] == 0)
    {
        $family = 'Не указано';
    }
?>
<b>Семейное положение:</b> <?=$family?>
<br />
<?php
	if ($data['user_data']['children'] == 1)
    {
        $children = 'Детей нет';
    }
    elseif ($data['user_data']['children'] == 2)
    {
        $children = 'Нет, но хотелось бы';
    }
    elseif ($data['user_data']['children'] == 3)
    {
        $children = 'Есть';
    }
    elseif ($data['user_data']['children'] == 0)
    {
        $children = 'Не указано';
    }
?>
<b>Дети:</b> <?=$children?>
<br />
<?php
	if ($data['user_data']['sponsor'] == 1)
    {
        $sponsor = 'Не нуждаюсь в спонсоре';
    }
    elseif ($data['user_data']['sponsor'] == 2)
    {
        $sponsor = 'Готов(а) стать спонсором';
    }
    elseif ($data['user_data']['sponsor'] == 3)
    {
        $sponsor = 'Ищу спонсора';
    }
    elseif ($data['user_data']['sponsor'] == 0)
    {
        $sponsor = 'Не указано';
    }
?>
<b>Материальная поддержка:</b> <?=$sponsor?>
<br />
<?=($user['id'] == $data['user_data']['id'] ? img('images/icons/edit.png') .nbs() . anchor('profile/edit_anketa3', 'Редактировать', 'class="green"') : '')?>
</div>

<div class="dotted">
<?php
	if ($data['user_data']['sex_skill'] == 1)
    {
        $sex_skill = 'Большой';
    }
    elseif ($data['user_data']['sex_skill'] == 2)
    {
        $sex_skill = 'Небольшой';
    }
    elseif ($data['user_data']['sex_skill'] == 3)
    {
        $sex_skill = 'Нету';
    }
    elseif ($data['user_data']['sex_skill'] == 0)
    {
        $sex_skill = 'Не указано';
    }
?>
<b>Сексуальный опыт:</b> <?=$sex_skill?>
<br />
<?php
	if ($data['user_data']['sex_often'] == 1)
    {
        $sex_often = 'Хотя бы раз в день';
    }
    elseif ($data['user_data']['sex_often'] == 2)
    {
        $sex_often = 'Несколько раз в день';
    }
    elseif ($data['user_data']['sex_often'] == 3)
    {
        $sex_often = 'Несколько раз в неделю';
    }
    elseif ($data['user_data']['sex_often'] == 0)
    {
        $sex_often = 'Не указано';
    }
?>
<b>Как часто хотелось бы заниматься сексом:</b> <?=$sex_often?>
<br />
<?=($data['user_data']['sex_like'] ? '<b>В сексе я люблю:</b> ' . show_text($data['user_data']['sex_like']) . '<br />' : '')?>
<?=($user['id'] == $data['user_data']['id'] ? img('images/icons/edit.png') .nbs() . anchor('profile/edit_anketa4', 'Редактировать', 'class="green"') : '')?>
</div>

<div class="dotted">
<?=img('images/icons/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>