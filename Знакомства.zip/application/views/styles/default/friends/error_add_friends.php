<b>Доступ ограничен</b>

<?=br(2)?>

<div class="dotted">Пользователь не принимает запросы на добавление в друзья.</div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

