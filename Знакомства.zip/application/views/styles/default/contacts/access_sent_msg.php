<b>Доступ ограничен</b>

<?=br(2)?>

<div class="error"><b>Доступ к почте закрыт пользователем.</b></div>

<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>
<br />
<?php
	if ($item['read'] == 0)
    {
        echo '<span class="green">Прочитано</span>';
    }
    elseif ($item['read'] == 1)
    {
        echo '<span class="red">Не прочитано</span>';
    }
?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет переписки.</b></div>
<?php endif; ?>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>