<?=doctype('html5')?>

<html>
    <head>
        <?=meta('keywords', $meta_keywords)?>
        <?=meta('description', $meta_description)?>
        <?=meta('Content-type', 'text/html; charset=utf-8', 'equiv')?>
        <link rel="stylesheet" href="<?=base_url()?>styles/<?=$style?>/style.css" type="text/css" />
        <link rel="shortcut icon" href="<?=base_url()?>favicon.ico" />
        <title><?=$title?></title>
    </head>
<body>

<?php if ($this->user->is_user()) : ?>

<?php $this->user->date_login(); ?>

<?php if ($this->user->check_ban() AND ($page != 'bans' AND $page != 'service')) : ?>
<?php redirect(base_url() . 'index.php/page/bans'); ?>
<?php exit(); ?>
<?php endif; ?>

<?php if ($user['delete'] == 1 AND ($page != 'activation')) : ?>
<?php redirect(base_url() . 'index.php/page/activation'); ?>
<?php exit(); ?>
<?php endif; ?>

<?php if ($user['city'] === '' AND ($page != 'my_profie')) : ?>
<?php redirect(base_url() . 'index.php/city/country'); ?>
<?php exit(); ?>
<?php elseif ($user['name'] === '' AND ($page != 'my_profie')) : ?>
<?php redirect(base_url() . 'index.php/profile/edit_anketa1'); ?>
<?php exit(); ?>
<?php endif; ?>

<div class="head">

<?=anchor('page/profile/' . $this->user->id(), $this->user->login())?>

<?php if ($this->model_contacts->count_all_new_messages($user['id']) > 0 AND ($page != 'contacts' AND $page != 'menu')) : ?>
<?=nbs() . '|' . nbs() . anchor('contacts/new_messages', img('images/icons/email.png') . '+' .$this->model_contacts->count_all_new_messages($user['id']), 'class="blue"')?>
<?php endif; ?>

</div>


<?php endif; ?>