<div class="foot"><?=img(array('src' => 'styles/' . $style . '/img/f.gif', 'class' => 'ico'))?> 

&copy; <?=$copyright . nbs() .date("Y")?>, <?=anchor('page/sitemap', 'Sitemap', 'class="orange"')?>
</div>

<br />

<div class="center">

<?php if ($page == 'main'): ?>
18+<br/>
<script type="text/javascript" src="http://c.waptut.ru/6703/small.js"></script><noscript><a href="http://waptut.ru/in.go?id=6703"><img src="http://c.waptut.ru/6703/small.png" alt="Waptut.ru - Рейтинг мобильных сайтов" /></a></noscript><br/>
<a href="http://waplog.net/c.shtml?525150"><img src="http://c.waplog.net/525150.cnt" alt="waplog" /></a>

<?php else: ?>
18+<br/>
<script type="text/javascript" src="http://c.waptut.ru/6703/small.js"></script><noscript><a href="http://waptut.ru/in.go?id=6703"><img src="http://c.waptut.ru/6703/small.png" alt="Waptut.ru - Рейтинг мобильных сайтов" /></a></noscript><br/>
<a href="http://waplog.net/c.shtml?525150"><img src="http://c.waplog.net/525150.cnt" alt="waplog" /></a>

<?php endif;?>

<?php if ( ! $this->user->is_user()) : ?>
<br />
<b><? //=anchor(base_url() . 'index.php/main/index/web', 'Компьютерная версия', 'class="orange"')?></b>
<br />
<? //=anchor('http://xwab.mobi', 'xwab - форум разработчиков', 'class="red"')?>
<?php endif; ?>
</div>

<br />

</body>
</html>
