<b>Доступ ограничен</b>

<?=br(2)?>

<div class="dotted">Пользователь добавил Вас в черный список. Информация недоступна.</div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>

