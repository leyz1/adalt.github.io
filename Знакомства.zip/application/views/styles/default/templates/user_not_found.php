<b>ОПС!</b>

<?=br(2)?>

<div class="dotted">Такого пользователя нет в базе данных.</div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>