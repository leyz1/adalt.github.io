<b>Форум</b> | Создать категорию

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?=form_open(current_url())?>

<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 10 до 255 символов, не обязательно):
<br />
<?=form_input($data['description'])?>
<br />
<?=form_submit('submit', 'Создать категорию', 'class="form"')?>
</div>


<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/category/' . $data['forum_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>