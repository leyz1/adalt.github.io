<b>Фото</b> | Добавить новое фото

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?=form_open_multipart(current_url())?> 

<div class="dotted">
Выберите фото для загрузки:
<br />
<?=form_upload($data['upload_photo'], '', 'class="form"')?>
<br />
<span class="red">Модератор заблокирует:</span>
<br /> 
1. Фотографии на которых не видно лица или некачественные фотографии.
<br /> 
2. Фотографии на которых изображены ваши девушки, парни, дети, бабушки, дедушки, собаки, кошки, машины, мотоциклы и т.п. Кто/что угодно, только не Вы.
<br /> 
3. Групповые снимки (без указания кто именно на ней Вы).
<br />
4. Порнографию.
<br />
5. Рекламу (на фотографии ссылки на другие сайты).
<br />
</div>
<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 5 до 255 символов, необязательно):
<br />
<?=form_input($data['description'])?>
<br />
<?=form_submit('submit', 'Добавить фото', 'class="form"')?>
</div>

<?=form_close()?> 

<?php else : ?>
<div class="error"><b>Доступ к фото временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('photo/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>