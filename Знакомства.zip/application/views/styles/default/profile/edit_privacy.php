<b>Мой профиль</b> | Настройки приватности

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
Кто может посылать мне личные сообщения?
<br />
<?=form_dropdown('sent_msg', $data['sent_msg'], $user['sent_msg'], 'class="form"')?>
</div>

<div class="dotted">
Кто может комментировать мои фото?
<br />
<?=form_dropdown('comment_photo', $data['comment_photo'], $user['comment_photo'], 'class="form"')?>
</div>

<div class="dotted">
Кто может комментировать мои записи дневниках?
<br />
<?=form_dropdown('comment_blog', $data['comment_blog'], $user['comment_blog'], 'class="form"')?>
</div>

<div class="dotted">
Кто может видеть список моих подарков?
<br />
<?=form_dropdown('view_present', $data['view_present'], $user['view_present'], 'class="form"')?>
</div>

<div class="dotted">
Кто может видеть список моих друзей?
<br />
<?=form_dropdown('view_friends', $data['view_friends'], $user['view_friends'], 'class="form"')?>
</div>

<div class="dotted">
Кто может отправлять мне запросы о добавлении в друзья?
<br />
<?=form_dropdown('add_friends', $data['add_friends'], $user['add_friends'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>