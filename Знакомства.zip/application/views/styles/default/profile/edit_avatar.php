<b>Мой профиль</b> | Обновить главное фото

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
Ваше фото:
<br />
<?=show_avatar($user)?>
</div>

<?=form_open_multipart(current_url())?> 

<div class="dotted">
Выберите фото для загрузки:
<br />
<?=form_upload($data['avatar'], '', 'class="form"')?>
<br />
<span class="red">Модератор заблокирует:</span>
<br /> 
1. Фотографии на которых не видно лица или некачественные фотографии.
<br /> 
2. Фотографии на которых изображены ваши девушки, парни, дети, бабушки, дедушки, собаки, кошки, машины, мотоциклы и т.п. Кто/что угодно, только не Вы.
<br /> 
3. Групповые снимки (без указания кто именно на ней Вы).
<br />
4. Порнографию.
<br />
5. Рекламу (на фотографии ссылки на другие сайты).
<br />
<?=form_submit('submit', 'Обновить фото', 'class="form"')?>
<br />
</div>

<?=form_close()?> 

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>