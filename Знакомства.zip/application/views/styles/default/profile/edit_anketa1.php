<b>Мой профиль</b> | Основная

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<span class="red">*</span> - Поле обязательное для заполнения.
</div>

<div class="dotted">
<b>Имя:</b> * (<span class="red">может содержать ТОЛЬКО буквы русского или ТОЛЬКО латинского алфавита</span>)
<br />
<?=form_input($data['name'])?>
</div>

<div class="dotted">
<b>Приветствие:</b>
<br />
<?=form_input($data['welcome_msg'])?>
</div>

<div class="dotted">
<b>Пол:</b>
<br />
<?=form_dropdown('gender', $data['gender'], $user['gender'], 'class="form"')?>
</div>

<div class="dotted">
<b>Дата рождения</b> (в формате ДД.ММ.ГГГГ):
<br />
<?=form_input($data['day']) . nbs() . form_input($data['month']) . nbs() . form_input($data['year'])?>
</div>

<div class="dotted">
<b>Skype:</b>
<br />
<?=form_input($data['skype'])?>
</div>

<div class="dotted">
<b>ICQ:</b>
<br />
<?=form_input($data['icq'])?>
</div>

<div class="dotted">
<b>VK.COM/ID:</b>
<br />
<?=form_input($data['vk'])?>
<br />
<?=form_submit('submit', 'Сохранить', 'class="form"')?>
</div>
<?=form_close()?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/anketa', 'Вернуться назазд')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>