<b>Новости</b> | Комментарии

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>


<?php if($data['config']['access'] === FALSE) : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 3 до 1024 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Редактировать', 'class="form"')?>
</div>

<?=form_close()?>

<?php else : ?>

<div class="error"><b>Доступ к новостям временно закрыт.</b></div>

<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('news/comments/' . $data['comments_data']['id_news'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>