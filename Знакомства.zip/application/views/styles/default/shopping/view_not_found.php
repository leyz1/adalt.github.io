<b>Ошибка!</b>

<?=br(2)?>

<div class="error"><?=img('images/smileys/ops.gif')?> <b>Просмотр подарков закрыт пользователем.</b></div>

<div class="dotted"><?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?></div>