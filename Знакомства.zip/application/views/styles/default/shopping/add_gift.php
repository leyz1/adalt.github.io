<b>Магазин подарков</b> | Добавить подарок

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open_multipart(current_url())?> 

<div class="dotted">
Выберите файл для загрузки (JPEG, JPG, PNG, GIF):
<br />
<?=form_upload($data['gift'], '', 'class="form"')?>
</div>

<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 5 до 255 символов, необязательно):
<br />
<?=form_input($data['description'])?>
</div>

<div class="dotted">
Цена (стоимость в баллах):
<br />
<?=form_input($data['balls'])?>
<br />
<?=form_submit('submit', 'Добавить подарок', 'class="form"')?>
</div>

<?=form_close()?> 


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('shopping/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>