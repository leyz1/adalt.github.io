<b>Мой профиль</b> | Мой город

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<?=anchor('city/home/' . $item['id'], $item['city_name_ru'])?>
</div>
<? endforeach; ?>
<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Сервер базы данных сейчас не доступен.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>