<b>Подарки</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('files/gifts/' . $item['id_catalog'] . '/' . $item['hash_file'] . '.png')?>
<br />---<br />
<b>Название:</b> <?=show_text($item['title'])?>
<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?php if ($item['anonymous'] == 0) : ?>
<b>От:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<?php endif; ?>

<?php if (($user['id'] == $data['user_data']['id']) AND $item['anonymous'] == 1) : ?>
<b>От:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<?php elseif(($user['id'] != $data['user_data']['id']) AND $item['anonymous'] == 1) : ?>
<b>От Приватного отправителя</b> 
<?php endif; ?>

<?php if ($item['anonymous'] == 2) : ?>
<b>От Анонимного пользователя</b> 
<?php endif; ?>

<?=($item['description'] ? '<br />' . show_text($item['description']) . '<br />---<br />' : '<br />---<br />')?>

<?php if ($user['id'] == $data['user_data']['id']) : ?>
<?=form_open(current_url())?>
<?=form_hidden('id_present', $item['id'])?>
<?=form_submit('delete', 'Удалить подарок', 'class="form"')?>
<?=form_close()?>
<?php endif; ?>

</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Подарки никто не дарил.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>