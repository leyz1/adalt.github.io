<b>Смайлы</b>

<?=br(2)?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<?php $smile = preg_replace('#^(.*?).(gif|jpg|png)$#isU', '$1', $item, 1); ?>
<div class="dotted">
<?=img('images/smileys/' . $item) . nbs() . ':' . $smile . ':' . nbs()?>
</div>
<? endforeach; ?>

<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Смайлы не найдены.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>