<b>Бан</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
Чтобы больше не возникало подобных ситуаций, рекомендуем Вам изучить <?=anchor('page/service', 'Правилами сайта', 'class="red"')?>
</div>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Забанил:</b> <?=data_user($this->user->parse_id($item['id_admin']))?> <?=(city($this->user->parse_id($item['id_admin'])) !== FALSE ? city($this->user->parse_id($item['id_admin'])) : '')?>
<br />
<b>До:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<?=show_text($item['description'])?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет нарушений.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>