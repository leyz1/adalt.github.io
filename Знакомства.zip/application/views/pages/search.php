<b>Поиск</b> | Все пользователи

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Я ищу:</b>
<br />
<?=form_dropdown('gender', $data['gender'], '0', 'class="form"')?>
</div>

<div class="dotted">
<b>Город:</b>
<br />
<?=form_input($data['city'])?>
</div>

<div class="dotted">
<b>Ориентация:</b>
<br />
<?=form_dropdown('sex_orient', $data['sex_orient'], '0', 'class="form"')?>
</div>

<div class="dotted">
<b>Цель знакомства:</b>
<br />
<?=form_checkbox($data['getting_target1'], '', '', 'class="form"')?> Дружба и общение
<br />
<?=form_checkbox($data['getting_target2'], '', '', 'class="form"')?> Флирт, СМС-переписка
<br />
<?=form_checkbox($data['getting_target3'], '', '', 'class="form"')?> Любовь, отношения
<br />
<?=form_checkbox($data['getting_target4'], '', '', 'class="form"')?> Брак, создание семьи
<br />
<?=form_checkbox($data['getting_target5'], '', '', 'class="form"')?> Виртуальный секс
<br />
<?=form_checkbox($data['getting_target6'], '', '', 'class="form"')?> Секс в реале
<br />
</div>

<div class="dotted">
<b>Семейное положение:</b>
<br />
<?=form_dropdown('family', $data['family'], '0', 'class="form"')?>
</div>

<div class="dotted">
<b>Сексуальный опыт:</b>
<br />
<?=form_dropdown('sex_skill', $data['sex_skill'], '0', 'class="form"')?>
<br />
<?=form_submit('submit', 'Поиск', 'class="form"')?>
</div>

<?=form_close()?>


<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/users.gif') . nbs() . anchor('page/users', 'Пользователи')?> <span class="count">(<?=$this->profile->count_users()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/users.png') . nbs() . anchor('page/profile/' . $user['id'], 'Профиль ' . $user['login'])?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>