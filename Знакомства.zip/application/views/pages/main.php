<div class="logo"><?=img('styles/' . $style . '/img/wapdoza.png')?></div>

<div class="top">Сайт знакомств Sizok.Ru это анкеты девушек и парней со всего света. <a href="http://sizok.ru/index.php/page/registration/">Регистрируйтесь</a>  и начинайте знакомиться.</div>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="vhod">
 <form action="http://sizok.ru/" method="post" accept-charset="utf-8">
<img src="styles/default/img/log.png" alt=""/><input type="text" name="login" value="" maxlength="20" class="form" placeholder="Логин "   /><br />

<img src="styles/default/img/par.png" alt=""/><input type="password" name="password" value="" maxlength="40" class="form" placeholder="Пароль"  /><br />
<img src="styles/default/img/vhod.png" alt=""/><input type="submit" name="submit" value="Войти на сайт" class="form" />
<a href="http://sizok.ru/page/pswdreminder.html" title="Забыли пароль?"><img src="img/zab.png" alt=""/></a></form>
</div>


<?=form_close()?>

<div class="menu"><b><?=anchor('page/registration', 'Бесплатная регистрация &raquo;', 'class="reg"')?></b></div>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="menu">

<?=data_user($this->user->parse_id($item['id']))?>  <?=(birt($this->user->parse_id($item['id'])) !== FALSE ? birt($this->user->parse_id($item['id'])) : '')?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>
<br />
<?=show_avatar($this->user->parse_id($item['id']))?>

</div>

<? endforeach; ?>


<?php else : ?>
<div class="dotted"><b>Никого нет.</b></div>
<?php endif; ?>

<div class="menu"><b><?=anchor('page/registration', 'Бесплатная регистрация &raquo;', 'class="reg"')?></b></div>
