<b>Сервисы/Услуги</b> | Анкета дня

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
- <?=anchor('page/services', 'Назад в (Сервисы/Услуги)', 'class="green"')?>
</div>

<div class="dotted">
<b>Услуга:</b> Анкета дня
<br />
<b>Статус:</b> 

<?php
	if ($user['date_anketa_day'] >= now())
    {
        echo 'Активирована до: ' . show_display_date($user['date_anketa_day']);
    }
    else
    {
        echo '<span class="red">Не активирована.</span>';
    }
?>
<br />---<br />
Услуга позволяет показывать вашу анкету (по очереди с другими анкетами дня) на главной странице сайта. Продолжительность услуги вы сможете указать при активации. Активируйте услугу и вас обязательно заметят!
<br />---<br />
Стоимость услуги составляет <?=img(''.base_url().'styles/'.$style.'/img/coins.png')?> 1000 за 1 час.
</div>


<?=form_open(current_url())?>

<div class="dotted">
<b>Кому показывать анкету?</b>
<br />
<?=form_dropdown('anketa_day_type', $data['anketa_day_type'], 'all', 'class="form"')?>
</div>

<div class="dotted">
<b>Количество часов:</b>
<br />
<?=form_dropdown('time_service', $data['time_service'], '6', 'class="form"')?>
</div>


<div class="dotted">
<span class="red"><b>При повторной активации услуги, время будет заданно повторно.</b></span>
<br />
<?=form_submit('submit', 'Активировать услугу', 'class="form"')?>
</div>

<?=form_close()?>


<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>