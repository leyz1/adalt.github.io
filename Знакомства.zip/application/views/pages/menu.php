<div class="logo"><?=img('styles/' . $style . '/img/wapdoza.png')?></div>
<?=validation_errors()?>
<?=notice($data['notice'])?>

<div class="menu">
<?=show_display_time() . nbs() . '[' . anchor(current_url(), 'ОБНОВИТЬ') . ']'?>

<br />
<?php if ($this->contact->count_all_new_messages($user['id']) > 0) : ?>
<?=img(''.base_url().'styles/'.$style.'/img/email.png') . nbs() . anchor('contacts/new_messages', 'Новые сообщения', 'class="blue"')?> <span class="count">(<?=$this->contact->count_all_new_messages($user['id'])?>)</span>
<?php else : ?>
<?=img(''.base_url().'styles/'.$style.'/img/email.png')?> <span class="gray">Нет сообщений</span>
<?php endif; ?>

</div>

<div class="menu">
<b><?=img(''.base_url().'styles/'.$style.'/img/rss.png') . nbs() . anchor('news/index', 'Новоcти')?></b> <span class="count">(<?=$this->news->count_news()?>)</span>
</div>

<div class="menu">
<b>Сейчас на сайте:</b> <?=anchor('page/all_online', '<span class="count">(' . $this->profile->count_user_online() . ')</span>')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/boy.png') . nbs() . anchor('page/boy', 'Парней')?> <span class="count">(<?=$this->profile->count_online_boy()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/girl.png') . nbs() . anchor('page/girl', 'Девушек')?> <span class="count">(<?=$this->profile->count_online_girl()?>)</span>
</div>

<div class="menu">
<div class="block_top">
<b>Анкета дня:</b>
<br />
<?php if ($this->profile->get_users_rand($user['gender'])) : ?>

<?php foreach ($this->profile->get_users_rand($user['gender']) AS $item) : ?>



<?=data_user($this->user->parse_id($item['id']))?>  <?=(birt($this->user->parse_id($item['id'])) !== FALSE ? birt($this->user->parse_id($item['id'])) : '')?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>
<br />
<?=($item['welcome_msg'] ? show_text($item['welcome_msg']) : 'Я люблю sizok.ru, очень!')?>
<br />---<br />
<?=anchor('page/anketa_day', 'Как сюда попасть?')?>
<br />


<? endforeach; ?>


<?php else : ?>
<b><?=anchor('page/anketa_day', 'Как сюда попасть?')?></b>
<?php endif; ?>
</div>
</div>

<div class="menu"><b><?=img(''.base_url().'styles/'.$style.'/img/config.png') . nbs() . anchor('page/profile/'  . $user['id'], 'Моя страница', 'class="green"')?></b></div>
<div class="menu"><b><?=img(''.base_url().'styles/'.$style.'/img/config.png') . nbs() . anchor('profile/index', 'Мой профиль')?></b></div>
<div class="menu"><?=img(''.base_url().'styles/'.$style.'/img/coins.png') . nbs() . anchor('api/', '<b>Мой баланс:</b>')?> <span class="count">(<?=$user['balls']?>)</span></div>
<div class="menu">
<?=img(''.base_url().'styles/'.$style.'/img/guest.png') . nbs() . anchor('page/guest', 'Мои гости')?> <span class="count">(<?=$this->profile->count_all_guest($user['id'])?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/journal.png') . nbs() . anchor('page/journal', 'Мой журнал')?> <span class="count">(<?=$this->profile->count_all_journal($user['id'])?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/friends.png') . nbs() . anchor('friends/index/' . $user['id'], 'Мои друзья')?> <span class="count">(<?=$this->friend->count_all_friends($user['id'])?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/contacts.png') . nbs() . anchor('contacts/index/' . $user['id'], 'Мои контакты/Почта')?>
<br />
<?=img('images/icons/cart.png') . nbs() . anchor('shopping/present', 'Мои покупки')?> <span class="count">(<?=$this->shop->count_all_cart_id_user($user['id'])?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/gift.png') . nbs() . anchor('page/present/' . $user['id'], 'Мои подарки')?> <span class="count">(<?=$this->shop->count_all_gift_id_user($user['id'])?>)</span>
</div>

<div class="menu">
<b><?=img(''.base_url().'styles/'.$style.'/img/users.gif') . nbs() . anchor('page/users', 'Пользователи', 'class="green"')?></b> <span class="count">(<?=$this->profile->count_users()?>)</span>
<br />
<b><?=img(''.base_url().'styles/'.$style.'/img/search.png') . nbs() . anchor('page/search', 'Поиск', 'class="blue"')?></b>
<br />
<b><?=img(''.base_url().'styles/'.$style.'/img//smileys.png') . nbs() . anchor('page/smileys', 'Смайлы', 'class="orange"')?></b>
</div>


<div class="menu">
<?=img(''.base_url().'styles/'.$style.'/img/forum.png') . nbs() . anchor('forum/index', 'Форум')?> <span class="count">(<?=$this->forum->count_all_topic()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/chat.png') . nbs() . anchor('chat/index', 'Чат')?> <span class="count">(<?=$this->chat->count_all_who()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/blog.png') . nbs() . anchor('blog/gender', 'Дневники')?> <span class="count">(<?=$this->blog->count_blog()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/wall.png') . nbs() . anchor('wall/index', 'Стена/Беседка')?> <span class="count">(<?=$this->wall->count_wall()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/photos.png') . nbs() . anchor('photo/gender', 'Галерея')?> <span class="count">(<?=$this->photo->count_photo()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/photo_album.png') . nbs() . anchor('album/gender', 'Фотоальбомы')?> <span class="count">(<?=$this->album->count_album()?>)</span>
</div>

<div class="menu"><?=img(''.base_url().'styles/'.$style.'/img/shopping.png') . nbs() . anchor('shopping/index', 'Магазин')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/cart2.png') . nbs() . anchor('page/services', 'Сервисы/Услуги')?>
<br />
</div>

<div class="menu">
<b><span class="green">Сейчас обсуждают</span></b>
</div>

<?php if ($this->model_forum->get_last_active_topic()) : ?>

<?php foreach ($this->model_forum->get_last_active_topic() AS $item) : ?>

<div class="menu">
<?=img(''.base_url().'styles/'.$style.'/img/them_' . $item['up'] . $item['close'] . '.png') . nbs() . anchor('forum/post/' . $item['id'] . '/word_limiter', show_text($item['title']))?> <span class="count">(<?=$this->model_forum->count_all_post_id($item['id'])?>)</span>
<br />
<b>Дата:</b> <?=show_display_date($item['time_create'])?>
<br />
<b>Автор:</b> <?=data_user($this->user->parse_id($item['id_user']))?>
</div>

<? endforeach; ?>

<?php else: ?>
<div class="error"><b>Ничего не обсуждают.</b></div>
<?php endif; ?>


<?php if ($this->user->is_admin(array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))) : ?>
<div class="menu"><?=img(''.base_url().'styles/'.$style.'/img/siren.png') . nbs() . anchor('page/spam', 'Спам/Жалобы')?> <span class="count">(<?=$this->profile->count_all_spam()?>)</span></div>
<?php endif; ?>

<?php if ($this->user->is_admin(array(10))) : ?>
<div class="menu"><?=img(''.base_url().'styles/'.$style.'/img/banan.png') . nbs() . anchor('page/banan', 'Бан - Панель')?> <span class="count">(<?=$this->profile->count_all_banan()?>)</span></div>
<?php endif; ?>

<div class="menu"><?=img(''.base_url().'styles/'.$style.'/img/exit.png') . nbs() . '[' . anchor('page/out', 'ВЫХОД') . ']'?></div>

