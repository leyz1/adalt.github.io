<b>Изменение Логина</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Новый Логин:</b>
<br />
<?=form_input($data['login'])?>
<br />
<?=form_submit('submit', 'Редактировать', 'class="form"')?>
</div>
<?=form_close()?>



<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>