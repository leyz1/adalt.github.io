<h1>Знакомства SIZOK.RU - Бесплатный сайт знакомств</h1>


<?php foreach ($this->seo->get_users() AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id']))?>  <?=(birt($this->user->parse_id($item['id'])) !== FALSE ? birt($this->user->parse_id($item['id'])) : '')?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>
<br />
<?=$item['login']?>
</div>

<? endforeach; ?>