<b>Мои гости</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?>  <?=(birt($this->user->parse_id($item['id_user'])) !== FALSE ? birt($this->user->parse_id($item['id_user'])) : '')?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />---<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
</div>

<? endforeach; ?>

<div class="dotted"><?=img(''.base_url().'styles/'.$style.'/img/trash.png') . nbs() . anchor('page/trunce_guest', 'Очистить гостей', 'class="green"')?></div>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Вашу страничку ещё не посещали.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/users.gif') . nbs() . anchor('page/users', 'Пользователи')?> <span class="count">(<?=$this->profile->count_users()?>)</span>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/search.png') . nbs() . anchor('page/search', 'Поиск')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>