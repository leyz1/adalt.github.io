<b>Сервисы/Услуги</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/draw_star.png') . nbs() . anchor('page/star_search', 'Звезда поиска', 'class="orange"')?>
</div>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/anketa.png') . nbs() . anchor('page/anketa_day', 'Анкета дня', 'class="orange"')?>
</div>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/search.png') . nbs() . anchor('page/anketa_up', 'Поднять анкету', 'class="orange"')?>
</div>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>