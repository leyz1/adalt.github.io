<b>Забанить Урку</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Время бана:</b>
<br />
<?=form_dropdown('time_ban', $data['time_ban'], '3', 'class="form"')?>
</div>

<div class="dotted">
<b>Напишите Урке причину бана:</b> (до 255 символов)
<br />
<?=form_input($data['description'])?>
<br />
<?=form_submit('submit', 'Забанить Урку', 'class="form"')?>
</div>

<?=form_close()?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>Забанил:</b> <?=data_user($this->user->parse_id($item['id_admin']))?> <?=(city($this->user->parse_id($item['id_admin'])) !== FALSE ? city($this->user->parse_id($item['id_admin'])) : '')?>
<br />
<b>До:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<?=show_text($item['description'])?>
<br />
<?=form_open(current_url())?>
<?=form_hidden('id_ban', $item['id'])?>
<?=form_submit('nulled', 'Обнулить время', 'class="form"')?> <?=form_submit('delete', 'Удалить нарушение', 'class="form"')?>
<?=form_close()?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет нарушений.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/users.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Профиль ' . $data['user_data']['login'])?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>