<b>Спам/Жалобы</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<b>ОТ:</b> <?=data_user($this->user->parse_id($item['id_user']))?> <b>НА:</b> <?=data_user($this->user->parse_id($item['id_to']))?>
<br />---<br />
<b>Дата:</b> <?=show_display_date($item['time'])?>
<br />---<br />
<b>Текст жалобы:</b>
<br />
<?=show_text($item['spam'])?>
<br />
<?php
	
    if ($item['type'] == 1)
    {
        $type = 'СПАМ, Реклама';
    }
    elseif ($item['type'] == 2)
    {
        $type = 'Нецензурная лексика';
    }
    elseif ($item['type'] == 3)
    {
        $type = 'Грубость и оскорбления';
    }
    elseif ($item['type'] == 4)
    {
        $type = 'Педофилия';
    }
    else
    {
        $type = 'Иное';
    }
?>
<b>Жалоба на:</b> <?=$type?>
<br />---<br />
<b>Комментарий:</b>
<br />
<?=show_text($item['description'])?>
</div>

<? endforeach; ?>

<?php if ($this->user->is_admin(array(8, 9, 10))) : ?>
<div class="dotted"><?=img(''.base_url().'styles/'.$style.'/img/trash.png') . nbs() . anchor('page/trunce_spam', 'Очистить Спам/Жалобы', 'class="green"')?></div>
<?php endif; ?>

<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Нет событий.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>