<b>Мои покупки</b> <?=(is_array($data['user_data']) ? '| Подарок для: ' . anchor('page/profile/' . $data['user_data']['id'], $data['user_data']['login']) : '')?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('files/gifts/' . $item['id_catalog'] . '/' . $item['hash_file'] . '.png')?>
<br />---<br />
<b>Название:</b> <?=show_text($item['title'])?>
<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=(is_array($data['user_data']) ? img('images/icons/present.png') . nbs() . anchor('shopping/cart_present/' . $item['id'], 'Подробнее &raquo;', 'class="blue"') : '---<br />')?>
<?=form_open(current_url())?>
<?=form_hidden('id_present', $item['id'])?>
<?=form_submit('delete', 'Удалить покупку', 'class="form"')?>
<?=form_close()?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет покупок.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/shopping.png') . nbs() . anchor('shopping/index', 'Вернуться в магазин')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>