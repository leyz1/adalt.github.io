<b>Магазин подарков</b> | <?=anchor('shopping/catalog/' . $data['catalog_data']['id'], $data['catalog_data']['title'], 'class="orange"')?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=img('files/gifts/' . $data['catalog_data']['id'] . '/' . $data['gift_data']['hash_file'] . '.png')?>
<br />---<br />
<b>Название:</b> <?=show_text($data['gift_data']['title'])?>
<br />
<b>Описание:</b> <?=($data['gift_data']['description'] ? show_text($data['gift_data']['description']) : 'Без описания.')?>
<br />
<b>Цена:</b> <?=$data['gift_data']['balls']?>
<br />
<b>Всего купили:</b> <?=$data['gift_data']['shopping']?> раз.
<br />---<br />
<?=form_open(current_url())?>
<?=form_hidden('id', $data['gift_data']['id'])?>
<?=form_submit('submit', 'Купить подарок', 'class="form"')?>
<?=form_close()?>
</div>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('shopping/catalog/' . $data['catalog_data']['id'], $data['catalog_data']['title'], 'class="orange"')?>
<br />
<?=img('images/icons/shopping.png') . nbs() . anchor('shopping/index', 'Вернуться в магазин')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>