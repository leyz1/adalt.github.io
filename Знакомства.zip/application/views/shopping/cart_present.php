<b>Отправка подарка</b>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=img('files/gifts/' . $data['catalog_data']['id'] . '/' . $data['present_data']['hash_file'] . '.png')?>
<br />---<br />
<b>Название:</b> <?=show_text($data['present_data']['title'])?>
</div>

<?=form_open(current_url())?> 

<div class="dotted">
Комментарий (от 5 до 1000 символов, необязательно):
<br />
<?=form_textarea($data['description'])?>
<br />
</div>

<div class="dotted">
Выберите параметры отправки:
<br />
<?=form_dropdown('anonymous', $data['anonymous'], '0', 'class="form"')?>
<br />

<?=form_submit('submit', 'Отправить', 'class="form"')?>
</div>

<?=form_close()?> 


<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>