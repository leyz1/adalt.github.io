<b>Магазин подарков</b> | Новые добавления

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('files/gifts/' . $item['id_catalog'] . '/' . $item['hash_file'] . '.png')?>
<br />
<b>Название:</b> <?=show_text($item['title'])?>
<br />
<b>Описание:</b> <?=($item['description'] ? show_text($item['description']) : 'Без описания.')?>
<br />
<b>Цена:</b> <?=$item['balls']?>
<br />
<b>Всего купили:</b> <?=$item['shopping']?> раз.
<br />---<br />
<?=img('images/icons/cart.png') . nbs() . anchor('shopping/cart/' . $item['id'], 'Подробнее &raquo;', 'class="blue"')?>
<?php if ($this->user->is_admin(array(10))) : ?>
<br />---<br />
<?=anchor('shopping/edit_gift/' . $item['id'], 'Редактировать', 'class="orange"')?> | <?=anchor('shopping/delete_gift/' . $item['id'], 'Удалить', 'class="red"')?>
<br />

<? endif; ?>
</div>

<? endforeach; ?>

<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Нет подарков.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('shopping/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>