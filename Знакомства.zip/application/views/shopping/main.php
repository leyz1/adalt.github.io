<b>Магазин подарков</b>

<?=br(2)?>

<?php if ($this->user->is_admin(array(10))) : ?>
<div class="dotted"><?=anchor('shopping/add_catalog', 'Добавить категорию', 'class="red"')?></div>
<? endif; ?>

<div class="dotted"><?=img('images/icons/folder.png') . nbs() . anchor('shopping/new_gift', 'Новые добавления')?></div>
<div class="dotted"><?=img('images/icons/chart.png') . nbs() . anchor('shopping/chart', 'Популярные покупки')?></div>


<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/shopping.png') . nbs() . anchor('shopping/catalog/' . $item['id'], show_text($item['title']), 'class="blue"')?> <span class="count">(<?=$this->shop->count_all_shopping_id($item['id'])?>)</span>
<?=($item['description'] ? '<br />' . show_text($item['description']) : '')?>
<br />
<?php if ($this->user->is_admin(array(10))) : ?>
<?=anchor('shopping/edit_catalog/' . $item['id'], 'Редактировать', 'class="orange"') .nbs() . '|' . nbs() . anchor('shopping/delete_catalog/' . $item['id'], 'Удалить', 'class="red"')?>
<? endif; ?>
</div>

<? endforeach; ?>



<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Каталоги не созданы.</b></div>
<?php endif; ?>
<div class="dotted">
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>