<b>Магазин подарков</b> | Редактировать подарок

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?> 

<div class="dotted">
Название (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание (от 5 до 255 символов, необязательно):
<br />
<?=form_input($data['description'])?>
</div>

<div class="dotted">
Цена (стоимость в баллах):
<br />
<?=form_input($data['balls'])?>
<br />
<?=form_submit('submit', 'Редактировать подарок', 'class="form"')?>
</div>

<?=form_close()?> 


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('shopping/catalog/' . $data['catalog_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>

</div>