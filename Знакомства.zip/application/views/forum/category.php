<?=anchor('forum/index', '<b>Форум</b>')?> | <?=$data['forum_data']['title']?>

<?=br(2)?>

<?php if ($this->user->is_admin(array(1, 10))) : ?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted"><?=anchor('forum/add_category/' . $data['forum_data']['id'], 'Создать категорию')?></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>



<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/category.png') . nbs() . anchor('forum/topic/' . $item['id'], show_text($item['title']))?> <span class="count">(<?=$this->forum->count_all_topic_id($item['id'])?>)</span>
<br />
<?=($item['description'] ? show_text($item['description']) . '<br />' : NULL)?>

<?php if ($this->user->is_admin(array(1, 10))) : ?>
<?=anchor('forum/up_category/' . $item['id'], 'Выше', 'class="blue"') . nbs() . '|' . nbs(). anchor('forum/down_category/' . $item['id'], 'Ниже', 'class="blue"') . nbs() . '|' . nbs(). anchor('forum/edit_category/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs(). anchor('forum/delete_category/' . $item['id'], 'Удалить', 'class="red"')?>
<?php endif; ?>


</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Категории не созданы</b></div>

<?php endif; ?>



<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>