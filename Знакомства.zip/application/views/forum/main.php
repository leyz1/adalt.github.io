<b>Форум</b>

<?=br(2)?>

<?php if ($this->user->is_admin(array(1, 10))) : ?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted"><?=anchor('forum/add_forum', 'Создать форум')?><br /><?=anchor('forum/topic_moderation', 'Темы на модерации', 'class="red"')?> <span class="count">(<?=$this->forum->count_all_moder()?>)</span></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted">
<?=img('images/icons/bookmark.png') . nbs() . anchor('forum/bookmark/', 'Мои закладки', 'class="orange"') . nbs() . '|' . nbs() . anchor('forum/my_topic/', 'Мои темы', 'class="blue"') . nbs() . '|' . nbs() . anchor('forum/active_topic/', 'Активные темы', 'class="green"') . nbs() . '|' . nbs() . anchor('forum/search/', 'Поиск', 'class="red"')?>
</div>

<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/categories.png') . nbs() . anchor('forum/category/' . $item['id'], show_text($item['title']))?> <span class="count">(<?=$this->forum->count_all_category_id($item['id'])?>)</span>
<br />
<?=show_text($item['description'])?>
<br />

<?php if ($this->user->is_admin(array(1, 10))) : ?>
<?=anchor('forum/up_forum/' . $item['id'], 'Выше', 'class="blue"') . nbs() . '|' . nbs(). anchor('forum/down_forum/' . $item['id'], 'Ниже', 'class="blue"') . nbs() . '|' . nbs(). anchor('forum/edit_forum/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs(). anchor('forum/delete_forum/' . $item['id'], 'Удалить', 'class="red"')?>
<?php endif; ?>


</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Форумы не созданы</b></div>

<?php endif; ?>



<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>

<div class="dotted">
<?=img('images/icons/help.png') . nbs() . anchor('forum/rules', 'Правила Форума')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>