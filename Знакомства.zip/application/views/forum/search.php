<b>Форум</b> | Поиск

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?=form_open(current_url())?>

<div class="dotted">
Запрос (от 3 до 10 символов):
<br />
<?=form_input($data['title'])?>
<br />
<?=form_submit('submit', 'Поиск', 'class="form"')?>
</div>

<?=form_close()?>


<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=img('images/icons/them_' . $item['up'] . $item['close'] . '.png') . nbs() . anchor('forum/post/' . $item['id'] . '/word_limiter', ReplaceKeywords($data['search_forum'], show_text($item['title'])))?> <span class="count">(<?=$this->forum->count_all_post_id($item['id'])?>)</span>

<br />
<b>ДАТА:</b> <?=show_display_date($item['time_create'])?>
<br />
<b>Автор:</b> <?=data_user($this->user->parse_id($item['id_user']))?>
</div>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Поиск не дал результатов.</b></div>

<?php endif; ?>


<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>