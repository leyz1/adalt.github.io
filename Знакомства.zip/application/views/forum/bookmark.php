<?=anchor('forum/index', '<b>Форум</b>')?> | Мои закладки

<?=br(2)?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?php
	$forum = $this->forum->check_forum($item['id_forum']);
    $category = $this->forum->check_category($item['id_category']);
    $topic = $this->forum->check_topic($item['id_topic']);
?>
<?=img('images/icons/them_' . $topic['up'] . $topic['close'] . '.png') . nbs() . anchor('forum/post/' . $topic['id'] . '/word_limiter', show_text($topic['title']))?> <span class="count">(<?=$this->forum->count_all_post_id($topic['id'])?>)</span>
<?=($item['up'] > 0 ? '<span class="red"><b>Есть новые ответы.</b></span>' : '')?>
<br />
<b>Добавлена:</b> <?=show_display_date($item['time'])?>
<br />
<b>Автор:</b> <?=data_user($this->user->parse_id($topic['id_user']))?>
</div>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Нет тем в закладках.</b></div>

<?php endif; ?>

<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>