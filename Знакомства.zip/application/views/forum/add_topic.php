<?=anchor('forum/index', '<b>Форум</b>')?> | <?=anchor('forum/category/' . $data['forum_data']['id'], $data['forum_data']['title'])?> | <?=anchor('forum/topic/' . $data['category_data']['id'], $data['category_data']['title'])?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($this->user->is_user()) : ?>

<?php if ($quarantine_time = $this->forum->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете создавать темы для обсуждения.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Название темы (от 5 до 255 символов):
<br />
<?=form_input($data['title'])?>
</div>

<div class="dotted">
Описание темы (от 10 до 10000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=($data['config']['moder'] > 0 ? '<br />' . anchor('/forum/moder', 'Включена предварительная модерация новых тем!', 'class="red"') . '<br /><br />' : NULL)?>

<?=form_submit('submit', 'Новая тема', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>

<?php endif; ?>




<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>



<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/topic/' . $data['category_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>