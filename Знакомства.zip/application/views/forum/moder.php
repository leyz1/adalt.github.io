<b>Форум</b> | Модерация новых тем

<?=br(2)?>

<div class="dotted">
В данной ветке форума включена предварительная модерация создаваемых тем. Это значит, что ваша тема появится после проверки модератором на соответствие правилам.
</div>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>