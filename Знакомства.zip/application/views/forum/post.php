<?=anchor('forum/index', '<b>Форум</b>')?> | <?=anchor('forum/category/' . $data['forum_data']['id'], $data['forum_data']['title'])?> | <?=anchor('forum/topic/' . $data['category_data']['id'], $data['category_data']['title'])?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">

<?=show_text($data['topic_data']['title'])?>
<br />---<br />

<?=($data['word'] == 'word_limiter' ? show_text(word_limiter($data['topic_data']['description'], 50, '...')) . '<br />' . anchor('forum/post/' . $data['topic_data']['id'] . '/word/', 'Читать полностью &raquo;') : show_text($data['topic_data']['description']) . '<br />' . anchor('forum/post/' . $data['topic_data']['id'] . '/word_limiter/', 'Сократить текст &raquo;'))?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($data['topic_data']['time_create'])?>
<br />
<b>Автор:</b> <?=data_user($this->user->parse_id($data['topic_data']['id_user']))?>
<br />
<?php if ($data['topic_data']['edit_who']) : ?>
<span class="red">Отредактировал: <b><?=$data['topic_data']['edit_who']?></b>, <?=show_display_date($data['topic_data']['edit_time']) . ',' .nbs(). $data['topic_data']['edit_count']?> раз(а).</span>
<br />
<?php endif; ?>

</div>

<?php if ($this->user->is_admin(array(1, 10))) : ?>

<div class="dotted"><?=anchor('forum/edit_topic/' . $data['topic_data']['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs() . anchor('forum/delete_topic/' . $data['topic_data']['id'], 'Удалить', 'class="red"') . nbs() . '|' . nbs() . anchor('forum/trunce/' . $data['topic_data']['id'], 'Очистить комментарии', 'class="blue"')?></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>


<?php if ($this->user->is_user()) : ?>
<?php if ($quarantine_time = $this->forum->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете обсуждать темы.</b></div>
<?php elseif ($data['topic_data']['close'] > 0) : ?>
<div class="error"><b>Тема закрыта для обсуждения.</b></div>
<?php elseif ($data['topic_data']['moder'] > 0) : ?>
<div class="error"><b>Тема еще не проверена модератором.</b></div>
<?php else : ?>

<?=form_open(current_url())?>

<div class="dotted">
Комментарий (от 10 до 1000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Написать', 'class="form"')?>
</div>

<?=form_close()?>

<?php endif; ?>

<?php endif; ?>



<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user'])) . ($item['id_reply'] > 0 ? nbs() . '<b>ответ для:</b>' . nbs() . data_user($this->user->parse_id($item['id_reply'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_text($item['description'])?>

<?php if ($item['edit_who']) : ?>
<br />
<span class="red">Отредактировал: <b><?=$item['edit_who']?></b>, <?=show_display_date($item['edit_time']) . ',' .nbs(). $item['edit_count']?> раз(а).</span>
<?php endif; ?>
<br />---<br />

<?php if ($this->user->is_user() AND $user['id'] != $item['id_user'] AND $data['topic_data']['close'] == 0) : ?>
[<?=anchor('forum/reply_post/' . $item['id'], 'ОТВЕТ', 'class="blue"')?>] [<?=anchor('forum/quote_post/' . $item['id'], 'ЦИТИРОВАТЬ', 'class="green"')?>]
<?php endif; ?>


<?php if ($this->user->is_admin(array(1, 10))) : ?>
<?=anchor('forum/edit_post/' . $item['id'], 'РЕДАКТИРОВАТЬ', 'class="orange"')?> | <?=anchor('forum/delete_post/' . $item['id'], 'УДАЛИТЬ', 'class="red"')?>
<?php elseif($this->user->is_user() AND $user['id'] == $item['id_user'] AND $data['topic_data']['close'] == 0 AND $item['time'] > now() - 600) : ?>
<?=anchor('forum/edit_post/' . $item['id'], 'РЕДАКТИРОВАТЬ', 'class="orange"')?>
<?php endif; ?>


</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Нет комментариев</b></div>

<?php endif; ?>




<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>



<div class="dotted">
<?=($this->forum->check_bookmark($data['topic_data']['id']) === TRUE ? img('images/icons/bookmark_delete.png') . nbs() . anchor('forum/delete_bookmark/' . $data['topic_data']['id'], 'Удалить из закладок') : img('images/icons/bookmark_add.png') . nbs() . anchor('forum/add_bookmark/' . $data['topic_data']['id'], 'Добавить в закладки'))?>
<br />
<?=img('images/icons/back.png') . nbs() . anchor('forum/topic/' . $data['category_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>