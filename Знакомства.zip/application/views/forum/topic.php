<?=anchor('forum/index', '<b>Форум</b>')?> | <?=anchor('forum/category/' . $data['forum_data']['id'], $data['forum_data']['title'])?> | <?=$data['category_data']['title']?>

<?=br(2)?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($this->user->is_user()) : ?>

<?php if ($quarantine_time = $this->forum->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете создавать темы для обсуждения.</b></div>
<?php else : ?>
<div class="dotted">[<?=anchor('forum/add_topic/' . $data['category_data']['id'], 'НОВАЯ ТЕМА', 'class="green"')?>]</div>
<?php endif; ?>

<?php endif; ?>


<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/them_' . $item['up'] . $item['close'] . '.png') . nbs() . anchor('forum/post/' . $item['id'] . '/word_limiter', show_text($item['title']))?> <span class="count">(<?=$this->forum->count_all_post_id($item['id'])?>)</span>
<br />
<b>ДАТА:</b> <?=show_display_date($item['time_create'])?>
<br />
<b>Автор:</b> <?=data_user($this->user->parse_id($item['id_user']))?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Темы не созданы</b></div>

<?php endif; ?>



<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>



<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/category/' . $data['forum_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>