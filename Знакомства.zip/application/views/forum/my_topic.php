<?=anchor('forum/index', '<b>Форум</b>')?> | Мои темы

<?=br(2)?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($data['config']['access'] === FALSE) : ?>


<?php if ($data['foreach']) : ?>



<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/them_' . $item['up'] . $item['close'] . '.png') . nbs() . anchor('forum/post/' . $item['id'] . '/word_limiter', show_text($item['title']))?> <span class="count">(<?=$this->forum->count_all_post_id($item['id'])?>)</span>
<br />
<b>ДАТА:</b> <?=show_display_date($item['time_create'])?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>



<?php else : ?>

<div class="dotted"><b>Темы не созданы</b></div>

<?php endif; ?>



<?php else : ?>

<div class="error"><b>Доступ к форуму временно закрыт</b></div>

<?php endif; ?>



<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('forum/index/', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>