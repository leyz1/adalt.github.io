<b>Пополнить баланс:</b>

<br />

<div class="dotted">
[<?=img(''.base_url().'styles/'.$style.'/img/coins_add.gif') . nbs() . anchor(base_url() . 'index.php/api/addcash', 'Пополнить по SMS', 'class="green"')?>]
</div>

<div class="dotted">
[<?=img(''.base_url().'styles/'.$style.'/img/coins_add.gif') . nbs() . anchor(base_url() . 'index.php/api/wmpay', 'Пополнить по WebMoney', 'class="green"')?>]
</div>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>