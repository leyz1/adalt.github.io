<b>Админка</b> | Редактирование тарифа

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?=form_open(current_url())?>

<div class="dotted">
<b>Номер телефона на который будут отправляться смс:</b> (до 10 символов)
<br />
<?=form_input($data['number'])?>
</div>

<div class="dotted">
<b>Вознаграждение в баллах:</b> (до 10 символов)
<br />
<?=form_input($data['balls'])?>
</div>

<div class="dotted">
<b>Стоимость отправки смс:</b> (до 10 символов)
<br />
<?=form_input($data['price'])?>
</div>

<div class="dotted">
<?=form_submit('submit', 'Редактировать тариф для (' . $data['country_data']['country'] . ')', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>