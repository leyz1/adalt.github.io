<b>Админка</b> | Редактирование стрраны

<br />

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>


<?=form_open(current_url())?>

<div class="dotted">
<b>Название страны:</b> (до 60 символов)
<br />
<?=form_input($data['country'])?>
</div>

<div class="dotted">
<b>ID страны:</b> (до 11 символов)
<br />
<?=form_input($data['id_country'])?>
</div>

<div class="dotted">
<?=form_submit('submit', 'Редактировать', 'class="form"')?>
</div>

<?=form_close()?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>