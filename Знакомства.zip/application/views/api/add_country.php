<b>Админка</b> | Добавление стрраны

<br />

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<?=show_flag($item['oid']) .anchor('api/add_country/' . $item['id'], $item['country_name_ru'])?>
</div>
<? endforeach; ?>

<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Сервер базы данных сейчас не доступен.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>