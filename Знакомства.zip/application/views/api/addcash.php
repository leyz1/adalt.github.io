<b>Пополнить баланс</b> | СМС

<br />

<?=error($data['error'])?>
<?=notice($data['notice'])?>
<!--<div class="dotted"><b><span class="red">Пополнение через смс не работает.</span></b></div>-->
<?php if ($this->user->is_admin(array(10))) : ?>
<div class="dotted"><?=anchor('api/add_country', 'Добавить страну')?></div>
<?php endif; ?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<?=show_flag($item['id_country']) .anchor('api/country/' . $item['id'], $item['country'])?> <span class="count">(<?=$this->api->count_all_number($item['id'])?>)</span>
<?php if ($this->user->is_admin(array(10))) : ?>
<br />---<br />
<?=anchor('api/edit_country/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs(). anchor('api/delete_country/' . $item['id'], 'Удалить', 'class="red"')?>
<?php endif; ?>
</div>
<? endforeach; ?>


<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Сервер базы данных сейчас не доступен.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>