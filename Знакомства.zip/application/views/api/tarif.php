<b>Страна</b> | <?=$data['country_data']['country']?>

<br />

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
Расценки:
<br />
<b><span class="blue">Короткий номер:</span></b> <?=$data['tarif_data']['number']?>
<br />
<b><span class="orange">Вознаграждение в баллах:</span></b> <?=$data['tarif_data']['balls']?> <?=img(''.base_url().'styles/'.$style.'/img/coins.png')?>
<br />
<b><span class="red">Стоимость смс (руб/грн):</span></b> <?=$data['tarif_data']['price']?>
</div>

<?=form_open('https://partner.a1pay.ru/a1lite/input')?>
<input type="hidden" name="key" value="gwR+hoArhxhA1BLYFekABvMBqqN2H6zZ//IrceU+wd0=" />

<input type="hidden" name="cost" value="<?=$data['tarif_data']['price']?>" />
<input type="hidden" name="name" value="Пополнение баланса" />
<input type="hidden" name="default_email" value="bykuznecphp@mail.ru" />
<input type="hidden" name="order_id" value="0" />

<div class="dotted">
<?=form_submit('submit', 'Оплатить', 'class="form"')?>
</div>

<?=form_close()?>


<div class="dotted">
<?=img(''.base_url().'styles/'.$style.'/img/back.png') . nbs() . anchor('api/addcash', 'Вернуться назад')?>
<br />
<?=img(''.base_url().'styles/'.$style.'/img/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>