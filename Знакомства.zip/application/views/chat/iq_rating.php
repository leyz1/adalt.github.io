<b>Чат</b> | Рейтинг Умников

<?=br(2)?>


<?php if($data['config']['access'] === FALSE) : ?>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=data_user($this->user->parse_id($item['id']))?> <?=(city($this->user->parse_id($item['id'])) !== FALSE ? city($this->user->parse_id($item['id'])) : '')?>
<br />
<b>IQ:</b> <?=$item['iq']?>
</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Нет умников</b></div>
<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к чату временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('chat/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>