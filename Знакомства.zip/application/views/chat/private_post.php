<?=anchor('chat/index', '<b>Чат</b>')?> | <?=anchor('chat/room/' . $data['room_data']['id'], $data['room_data']['title'])?> | Приватно

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>


<?php if($data['config']['access'] === FALSE) : ?>

<?php if($data['room_data']['access'] == 0) : ?>
<div class="error"><b>Извините. Данная комната времено закрыта модератором.</b></div>
<?php elseif ($quarantine_time = $this->chat->quarantine_time()) : ?>
<div class="error"><b>На сайте включен карантин для новых пользователей. Пока что Вы не можете общаться в комнатах чата.</b></div>
<?php elseif ($data['room_data']['pc_answers'] == 0 AND (strpos($this->input->user_agent(), "Opera") !== FALSE OR strpos($this->input->user_agent(), "M3Gate") !== FALSE OR strpos($this->input->user_agent(), "emulator") !== FALSE OR strpos($this->input->user_agent(), "WinWAP") !== FALSE OR strpos($this->input->user_agent(), "Wapsilon") !== FALSE OR strpos($this->input->user_agent(), "Mozilla") !== FALSE OR strpos($this->input->user_agent(), "M3GATE") !== FALSE)) : ?>
<div class="error"><b>Пользователям ПК нет возможности писать в данной комнате.</b></div>
<?php elseif ($this->user->is_user()) : ?>


<?=form_open(current_url())?>

<div class="dotted">
Сообщение (от 1 до 1000 символов):
<br />
<?=form_textarea($data['description'])?>
<br />
<?=form_submit('submit', 'Приватно', 'class="form"')?>
</div>

<?=form_close()?>


<?php endif; ?>

<?php else : ?>
<div class="error"><b>Доступ к чату временно закрыт.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('chat/room/' . $data['room_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>