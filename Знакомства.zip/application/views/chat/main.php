<b>Чат</b>

<?=br(2)?>

<?php if ($this->user->is_admin(array(2, 10))) : ?>

<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted"><?=anchor('chat/add_room', 'Создать комнату')?></div>

<?php endif; ?>


<?php if($data['config']['access'] === FALSE) : ?>

<div class="dotted"><?=img('images/icons/iq.png') . nbs() . anchor('chat/iq_rating', 'Рейтинг Умников')?> <span class="count">(<?=$this->db->count_all('users')?>)</span></div>

<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">
<?=img('images/icons/room.png') . nbs() . anchor('chat/room/' . $item['id'], show_text($item['title']))?> <span class="count">(<?=$this->chat->count_all_who_room($item['id'])?>)</span>
<br />
<?=show_text($item['description'])?>
<br />

<?php if ($this->user->is_admin(array(2, 10))) : ?>
<?=anchor('chat/up_room/' . $item['id'], 'Выше', 'class="blue"') . nbs() . '|' . nbs(). anchor('chat/down_room/' . $item['id'], 'Ниже', 'class="blue"') . nbs() . '|' . nbs(). anchor('chat/edit_room/' . $item['id'], 'Редактировать', 'class="orange"') . nbs() . '|' . nbs(). anchor('chat/delete_room/' . $item['id'], 'Удалить', 'class="red"') . nbs() . '|' . nbs(). anchor('chat/trunce_room/' . $item['id'], 'Очистить', 'class="green"')?>
<?php endif; ?>

</div>

<? endforeach; ?>
<?=$this->pagination->create_links()?>

<?php else : ?>

<div class="dotted"><b>Комнаты не созданы</b></div>

<?php endif; ?>

<?php else : ?>

<div class="error"><b>Доступ к чату временно закрыт.</b></div>

<?php endif; ?>


<div class="dotted">
<?=img('images/icons/help.png') . nbs() . anchor('chat/rules', 'Правила чата')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>