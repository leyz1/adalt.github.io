<b>Мой профиль</b> | Моя страна

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if (city($user) !== FALSE) : ?>
<div class="dotted">
<b>Ваш город:</b> <?=city($user)?>
</div>
<?php endif; ?>


<?php if ($data['foreach']) : ?>

<?php foreach ($data['foreach'] AS $item) : ?>
<div class="dotted">
<?=show_flag($item['oid']) .anchor('city/country/' . $item['id'], $item['country_name_ru'])?>
</div>
<? endforeach; ?>

<?=form_open(current_url())?>

<div class="dotted">
Название города (от 3 до 10 символов):
<br />
<?=form_input($data['title'])?>
<br />
<?=form_submit('submit', 'Поиск', 'class="form"')?>
</div>

<?=form_close()?>

<?=$this->pagination->create_links()?>

<?php else : ?>
<div class="dotted"><b>Сервер базы данных сейчас не доступен.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>