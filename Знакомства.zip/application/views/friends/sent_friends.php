<b>Друзья</b> | Отправка заявки в друзья

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=show_avatar($data['user_data'])?>
<br />
<b><?=$data['user_data']['login']?></b>, должен подтвердить что вы друзья.
</div>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>