<b>Друзья</b> | Предложения на дружбу

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_avatar($this->user->parse_id($item['id_user']))?>
<br />
<?=form_open(current_url())?>
<?=form_hidden('id_user', $item['id_user'])?>
<br />
<?=form_dropdown('toward', $data['toward'], $item['toward'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Подтвердить дружбу', 'class="form"')?>

<?=form_submit('cencell', 'Отклонить заявку', 'class="form"')?>
<?=form_close()?> 

</div>

<? endforeach; ?>



<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Дружбу никто не предлогал.</b></div>
<?php endif; ?>

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('friends/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>