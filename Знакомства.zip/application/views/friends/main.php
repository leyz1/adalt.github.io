<b>Друзья</b> | <?=$data['user_data']['login']?>

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<?php if($user['id'] == $data['user_data']['id']) : ?>
<div class="dotted"><?=img('images/icons/app_friends.png') . nbs() . anchor('friends/app_friends', 'Предложения на дружбу', 'class="orange"')?> <span class="count">(<?=$this->friend->count_all_app_friends($user['id'])?>)</span></div>
<?php endif; ?>

<?php if ($data['foreach']) : ?>


<?php foreach ($data['foreach'] AS $item) : ?>

<div class="dotted">

<?=data_user($this->user->parse_id($item['id_user']))?> <?=(city($this->user->parse_id($item['id_user'])) !== FALSE ? city($this->user->parse_id($item['id_user'])) : '')?>
<br />---<br />
<b>ДАТА:</b> <?=show_display_date($item['time'])?>
<br />
<?=show_avatar($this->user->parse_id($item['id_user']))?>
<br />
<?php
	
    if ($item['toward'] == 0)
    {
        $toward = '<span class="green">Друзья на Wapdoza.Ru</span>';
    }
    elseif ($item['toward'] == 1)
    {
        $toward = '<span class="orange">Лучшие друзья</span>';
    }
    elseif ($item['toward'] == 2)
    {
        $toward = 'Колеги';
    }
    elseif ($item['toward'] == 3)
    {
        $toward = 'Одноклассники';
    }
    elseif ($item['toward'] == 4)
    {
        $toward = 'Однокурссники';
    }
    elseif ($item['toward'] == 5)
    {
        $toward = '<span class="red">Родственники</span>';
    }
    elseif ($item['toward'] == 6)
    {
        $toward = '<span class="blue">Братья Сестры</span>';
    }
?>
<b>Отношения:</b> <?=$toward?>
<br />
<?php if ($user['id'] == $data['user_data']['id']) : ?>
<?=form_open(current_url())?>
<?=form_hidden('id_user', $item['id_user'])?>
<?=form_submit('submit', 'Удалить из друзей', 'class="form"')?>
<?=form_close()?> 
<?php endif; ?>
</div>

<? endforeach; ?>



<?=$this->pagination->create_links()?>


<?php else : ?>
<div class="dotted"><b>Дружбу никто не предлогал.</b></div>
<?php endif; ?>


<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>