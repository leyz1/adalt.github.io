<b>Друзья</b> | Отправка заявки в друзья

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=show_avatar($data['user_data'])?>
</div>

<?=form_open(current_url())?> 

<div class="dotted">
<b><?=$data['user_data']['login']?></b>, должен будет подтвердить, что вы друзья.
<br />
<?=form_dropdown('toward', $data['toward'], 0, 'class="form"')?>
</div>

<div class="dotted">
<span class="red">При установке отношений пользователь должен будет подтвердить ваш выбор.</span>
<br />
<?=form_submit('submit', 'Добавить в друзья', 'class="form"')?>
</div>

<?=form_close()?> 

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('profile/index', 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>