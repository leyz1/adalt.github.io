<b>Друзья</b> | Входящая заявка в друзья

<?=br(2)?>

<?=validation_errors()?>
<?=error($data['error'])?>
<?=notice($data['notice'])?>

<div class="dotted">
<?=show_avatar($data['user_data'])?>
<br />
<b><?=$data['user_data']['login']?></b>, хочет добавить вас в список своих друзей.
</div>

<?=form_open(current_url())?> 

<div class="dotted">
<b><?=$data['user_data']['login']?></b>, и вы:
<br />
<?=form_dropdown('toward', $data['toward'], $data['friends_data']['toward'], 'class="form"')?>
<br />
<?=form_submit('submit', 'Подтвердить дружбу', 'class="form"')?>
</div>

<?=form_close()?> 

<?=form_open(current_url())?> 

<div class="dotted">
<?=form_submit('cencell', 'Отклонить заявку', 'class="form"')?>
</div>

<?=form_close()?> 

<div class="dotted">
<?=img('images/icons/back.png') . nbs() . anchor('page/profile/' . $data['user_data']['id'], 'Вернуться назад')?>
<br />
<?=img('images/icons/home.png') . nbs() . anchor(base_url(), 'Главная')?>
</div>